package io.flutter.plugin.platform;

/* loaded from: classes.dex */
public abstract /* synthetic */ class d0 {
}
