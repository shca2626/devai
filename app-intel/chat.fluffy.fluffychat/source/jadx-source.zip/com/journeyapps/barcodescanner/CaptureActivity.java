package com.journeyapps.barcodescanner;

import H3.k;
import H3.l;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;

/* loaded from: classes.dex */
public class CaptureActivity extends Activity {

    /* renamed from: l, reason: collision with root package name */
    public b f14882l;

    /* renamed from: m, reason: collision with root package name */
    public DecoratedBarcodeView f14883m;

    public DecoratedBarcodeView a() {
        setContentView(l.f3444b);
        return (DecoratedBarcodeView) findViewById(k.f3431a);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f14883m = a();
        b bVar = new b(this, this.f14883m);
        this.f14882l = bVar;
        bVar.p(getIntent(), bundle);
        this.f14882l.l();
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.f14882l.r();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i7, KeyEvent keyEvent) {
        return this.f14883m.onKeyDown(i7, keyEvent) || super.onKeyDown(i7, keyEvent);
    }

    @Override // android.app.Activity
    public void onPause() throws InterruptedException {
        super.onPause();
        this.f14882l.s();
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i7, String[] strArr, int[] iArr) {
        this.f14882l.t(i7, strArr, iArr);
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        this.f14882l.u();
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.f14882l.v(bundle);
    }
}
