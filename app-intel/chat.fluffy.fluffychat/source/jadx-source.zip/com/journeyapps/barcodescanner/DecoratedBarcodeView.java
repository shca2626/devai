package com.journeyapps.barcodescanner;

import D3.p;
import H3.f;
import H3.g;
import H3.k;
import H3.l;
import H3.o;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import k4.InterfaceC1284a;
import k4.j;
import k4.m;
import l4.i;

/* loaded from: classes.dex */
public class DecoratedBarcodeView extends FrameLayout {

    /* renamed from: l, reason: collision with root package name */
    public BarcodeView f14884l;

    /* renamed from: m, reason: collision with root package name */
    public ViewfinderView f14885m;

    /* renamed from: n, reason: collision with root package name */
    public TextView f14886n;

    public interface a {
    }

    public class b implements InterfaceC1284a {

        /* renamed from: a, reason: collision with root package name */
        public InterfaceC1284a f14887a;

        public b(InterfaceC1284a interfaceC1284a) {
            this.f14887a = interfaceC1284a;
        }

        @Override // k4.InterfaceC1284a
        public void a(k4.b bVar) {
            this.f14887a.a(bVar);
        }

        @Override // k4.InterfaceC1284a
        public void b(List list) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                DecoratedBarcodeView.this.f14885m.a((p) it.next());
            }
            this.f14887a.b(list);
        }
    }

    public DecoratedBarcodeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        c(attributeSet);
    }

    public void b(InterfaceC1284a interfaceC1284a) {
        this.f14884l.J(new b(interfaceC1284a));
    }

    public final void c(AttributeSet attributeSet) {
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, o.f3468t);
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(o.f3469u, l.f3443a);
        typedArrayObtainStyledAttributes.recycle();
        View.inflate(getContext(), resourceId, this);
        BarcodeView barcodeView = (BarcodeView) findViewById(k.f3432b);
        this.f14884l = barcodeView;
        if (barcodeView == null) {
            throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.BarcodeView on provided layout with the id \"zxing_barcode_surface\".");
        }
        barcodeView.q(attributeSet);
        ViewfinderView viewfinderView = (ViewfinderView) findViewById(k.f3442l);
        this.f14885m = viewfinderView;
        if (viewfinderView == null) {
            throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.ViewfinderView on provided layout with the id \"zxing_viewfinder_view\".");
        }
        viewfinderView.setCameraPreview(this.f14884l);
        this.f14886n = (TextView) findViewById(k.f3441k);
    }

    public void d(Intent intent) {
        int intExtra;
        Set setA = f.a(intent);
        Map mapA = g.a(intent);
        i iVar = new i();
        if (intent.hasExtra("SCAN_CAMERA_ID") && (intExtra = intent.getIntExtra("SCAN_CAMERA_ID", -1)) >= 0) {
            iVar.i(intExtra);
        }
        if (intent.hasExtra("TORCH_ENABLED") && intent.getBooleanExtra("TORCH_ENABLED", false)) {
            i();
        }
        String stringExtra = intent.getStringExtra("PROMPT_MESSAGE");
        if (stringExtra != null) {
            setStatusText(stringExtra);
        }
        int intExtra2 = intent.getIntExtra("SCAN_TYPE", 0);
        String stringExtra2 = intent.getStringExtra("CHARACTER_SET");
        new D3.i().e(mapA);
        this.f14884l.setCameraSettings(iVar);
        this.f14884l.setDecoderFactory(new m(setA, mapA, stringExtra2, intExtra2));
    }

    public void e() {
        this.f14884l.u();
    }

    public void f() throws InterruptedException {
        this.f14884l.v();
    }

    public void g() {
        this.f14884l.y();
    }

    public BarcodeView getBarcodeView() {
        return (BarcodeView) findViewById(k.f3432b);
    }

    public i getCameraSettings() {
        return this.f14884l.getCameraSettings();
    }

    public j getDecoderFactory() {
        return this.f14884l.getDecoderFactory();
    }

    public TextView getStatusView() {
        return this.f14886n;
    }

    public ViewfinderView getViewFinder() {
        return this.f14885m;
    }

    public void h() {
        this.f14884l.setTorch(false);
    }

    public void i() {
        this.f14884l.setTorch(true);
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i7, KeyEvent keyEvent) {
        if (i7 == 24) {
            i();
            return true;
        }
        if (i7 == 25) {
            h();
            return true;
        }
        if (i7 == 27 || i7 == 80) {
            return true;
        }
        return super.onKeyDown(i7, keyEvent);
    }

    public void setCameraSettings(i iVar) {
        this.f14884l.setCameraSettings(iVar);
    }

    public void setDecoderFactory(j jVar) {
        this.f14884l.setDecoderFactory(jVar);
    }

    public void setStatusText(String str) {
        TextView textView = this.f14886n;
        if (textView != null) {
            textView.setText(str);
        }
    }

    public void setTorchListener(a aVar) {
    }
}
