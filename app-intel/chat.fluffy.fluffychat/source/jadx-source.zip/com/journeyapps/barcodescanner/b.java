package com.journeyapps.barcodescanner;

import D3.o;
import H3.e;
import H3.h;
import H3.n;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.journeyapps.barcodescanner.a;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import k4.InterfaceC1284a;

/* loaded from: classes.dex */
public class b {

    /* renamed from: o, reason: collision with root package name */
    public static final String f14936o = "b";

    /* renamed from: p, reason: collision with root package name */
    public static int f14937p = 250;

    /* renamed from: a, reason: collision with root package name */
    public Activity f14938a;

    /* renamed from: b, reason: collision with root package name */
    public DecoratedBarcodeView f14939b;

    /* renamed from: h, reason: collision with root package name */
    public h f14945h;

    /* renamed from: i, reason: collision with root package name */
    public e f14946i;

    /* renamed from: j, reason: collision with root package name */
    public Handler f14947j;

    /* renamed from: m, reason: collision with root package name */
    public final a.f f14950m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f14951n;

    /* renamed from: c, reason: collision with root package name */
    public int f14940c = -1;

    /* renamed from: d, reason: collision with root package name */
    public boolean f14941d = false;

    /* renamed from: e, reason: collision with root package name */
    public boolean f14942e = true;

    /* renamed from: f, reason: collision with root package name */
    public String f14943f = "";

    /* renamed from: g, reason: collision with root package name */
    public boolean f14944g = false;

    /* renamed from: k, reason: collision with root package name */
    public boolean f14948k = false;

    /* renamed from: l, reason: collision with root package name */
    public InterfaceC1284a f14949l = new a();

    public class a implements InterfaceC1284a {
        public a() {
        }

        @Override // k4.InterfaceC1284a
        public void a(final k4.b bVar) {
            b.this.f14939b.e();
            b.this.f14946i.d();
            b.this.f14947j.post(new Runnable() { // from class: k4.h
                @Override // java.lang.Runnable
                public final void run() {
                    com.journeyapps.barcodescanner.b.this.y(bVar);
                }
            });
        }

        @Override // k4.InterfaceC1284a
        public void b(List list) {
        }
    }

    /* renamed from: com.journeyapps.barcodescanner.b$b, reason: collision with other inner class name */
    public class C0149b implements a.f {
        public C0149b() {
        }

        @Override // com.journeyapps.barcodescanner.a.f
        public void a() {
        }

        @Override // com.journeyapps.barcodescanner.a.f
        public void b(Exception exc) {
            b bVar = b.this;
            bVar.m(bVar.f14938a.getString(n.f3448c));
        }

        @Override // com.journeyapps.barcodescanner.a.f
        public void c() {
        }

        @Override // com.journeyapps.barcodescanner.a.f
        public void d() {
            if (b.this.f14948k) {
                Log.d(b.f14936o, "Camera closed; finishing activity");
                b.this.n();
            }
        }

        @Override // com.journeyapps.barcodescanner.a.f
        public void e() {
        }
    }

    public b(Activity activity, DecoratedBarcodeView decoratedBarcodeView) {
        C0149b c0149b = new C0149b();
        this.f14950m = c0149b;
        this.f14951n = false;
        this.f14938a = activity;
        this.f14939b = decoratedBarcodeView;
        decoratedBarcodeView.getBarcodeView().i(c0149b);
        this.f14947j = new Handler();
        this.f14945h = new h(activity, new Runnable() { // from class: k4.d
            @Override // java.lang.Runnable
            public final void run() {
                com.journeyapps.barcodescanner.b.c(this.f19065l);
            }
        });
        this.f14946i = new e(activity);
    }

    public static /* synthetic */ void c(b bVar) {
        bVar.getClass();
        Log.d(f14936o, "Finishing due to inactivity");
        bVar.n();
    }

    public static Intent x(k4.b bVar, String str) {
        Intent intent = new Intent("com.google.zxing.client.android.SCAN");
        intent.addFlags(524288);
        intent.putExtra("SCAN_RESULT", bVar.toString());
        intent.putExtra("SCAN_RESULT_FORMAT", bVar.a().toString());
        byte[] bArrC = bVar.c();
        if (bArrC != null && bArrC.length > 0) {
            intent.putExtra("SCAN_RESULT_BYTES", bArrC);
        }
        Map mapD = bVar.d();
        if (mapD != null) {
            o oVar = o.UPC_EAN_EXTENSION;
            if (mapD.containsKey(oVar)) {
                intent.putExtra("SCAN_RESULT_UPC_EAN_EXTENSION", mapD.get(oVar).toString());
            }
            Number number = (Number) mapD.get(o.ORIENTATION);
            if (number != null) {
                intent.putExtra("SCAN_RESULT_ORIENTATION", number.intValue());
            }
            String str2 = (String) mapD.get(o.ERROR_CORRECTION_LEVEL);
            if (str2 != null) {
                intent.putExtra("SCAN_RESULT_ERROR_CORRECTION_LEVEL", str2);
            }
            Iterable iterable = (Iterable) mapD.get(o.BYTE_SEGMENTS);
            if (iterable != null) {
                Iterator it = iterable.iterator();
                int i7 = 0;
                while (it.hasNext()) {
                    intent.putExtra("SCAN_RESULT_BYTE_SEGMENTS_" + i7, (byte[]) it.next());
                    i7++;
                }
            }
        }
        if (str != null) {
            intent.putExtra("SCAN_RESULT_IMAGE_PATH", str);
        }
        return intent;
    }

    public final void A() {
        Intent intent = new Intent("com.google.zxing.client.android.SCAN");
        intent.putExtra("MISSING_CAMERA_PERMISSION", true);
        this.f14938a.setResult(0, intent);
    }

    public void B(boolean z7, String str) {
        this.f14942e = z7;
        if (str == null) {
            str = "";
        }
        this.f14943f = str;
    }

    public void k() {
        if (this.f14939b.getBarcodeView().s()) {
            n();
        } else {
            this.f14948k = true;
        }
        this.f14939b.e();
        this.f14945h.d();
    }

    public void l() {
        this.f14939b.b(this.f14949l);
    }

    public void m(String str) {
        if (this.f14938a.isFinishing() || this.f14944g || this.f14948k) {
            return;
        }
        if (str.isEmpty()) {
            str = this.f14938a.getString(n.f3448c);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this.f14938a);
        builder.setTitle(this.f14938a.getString(n.f3446a));
        builder.setMessage(str);
        builder.setPositiveButton(n.f3447b, new DialogInterface.OnClickListener() { // from class: k4.f
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i7) {
                this.f19067l.n();
            }
        });
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: k4.g
            @Override // android.content.DialogInterface.OnCancelListener
            public final void onCancel(DialogInterface dialogInterface) {
                this.f19068l.n();
            }
        });
        builder.show();
    }

    public final void n() {
        this.f14938a.finish();
    }

    public final String o(k4.b bVar) throws IOException {
        if (!this.f14941d) {
            return null;
        }
        Bitmap bitmapB = bVar.b();
        try {
            File fileCreateTempFile = File.createTempFile("barcodeimage", ".jpg", this.f14938a.getCacheDir());
            FileOutputStream fileOutputStream = new FileOutputStream(fileCreateTempFile);
            bitmapB.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.close();
            return fileCreateTempFile.getAbsolutePath();
        } catch (IOException e7) {
            Log.w(f14936o, "Unable to create temporary file and store bitmap! " + e7);
            return null;
        }
    }

    public void p(Intent intent, Bundle bundle) {
        this.f14938a.getWindow().addFlags(128);
        if (bundle != null) {
            this.f14940c = bundle.getInt("SAVED_ORIENTATION_LOCK", -1);
        }
        if (intent != null) {
            if (intent.getBooleanExtra("SCAN_ORIENTATION_LOCKED", true)) {
                q();
            }
            if ("com.google.zxing.client.android.SCAN".equals(intent.getAction())) {
                this.f14939b.d(intent);
            }
            if (!intent.getBooleanExtra("BEEP_ENABLED", true)) {
                this.f14946i.e(false);
            }
            if (intent.hasExtra("SHOW_MISSING_CAMERA_PERMISSION_DIALOG")) {
                B(intent.getBooleanExtra("SHOW_MISSING_CAMERA_PERMISSION_DIALOG", true), intent.getStringExtra("MISSING_CAMERA_PERMISSION_DIALOG_MESSAGE"));
            }
            if (intent.hasExtra("TIMEOUT")) {
                this.f14947j.postDelayed(new Runnable() { // from class: k4.e
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f19066l.z();
                    }
                }, intent.getLongExtra("TIMEOUT", 0L));
            }
            if (intent.getBooleanExtra("BARCODE_IMAGE_ENABLED", false)) {
                this.f14941d = true;
            }
        }
    }

    public void q() {
        if (this.f14940c == -1) {
            int rotation = this.f14938a.getWindowManager().getDefaultDisplay().getRotation();
            int i7 = this.f14938a.getResources().getConfiguration().orientation;
            int i8 = 0;
            if (i7 == 2) {
                if (rotation != 0 && rotation != 1) {
                    i8 = 8;
                }
            } else if (i7 == 1) {
                i8 = (rotation == 0 || rotation == 3) ? 1 : 9;
            }
            this.f14940c = i8;
        }
        this.f14938a.setRequestedOrientation(this.f14940c);
    }

    public void r() {
        this.f14944g = true;
        this.f14945h.d();
        this.f14947j.removeCallbacksAndMessages(null);
    }

    public void s() throws InterruptedException {
        this.f14945h.d();
        this.f14939b.f();
    }

    public void t(int i7, String[] strArr, int[] iArr) {
        if (i7 == f14937p) {
            if (iArr.length > 0 && iArr[0] == 0) {
                this.f14939b.g();
                return;
            }
            A();
            if (this.f14942e) {
                m(this.f14943f);
            } else {
                k();
            }
        }
    }

    public void u() {
        w();
        this.f14945h.h();
    }

    public void v(Bundle bundle) {
        bundle.putInt("SAVED_ORIENTATION_LOCK", this.f14940c);
    }

    public final void w() {
        if (L.b.a(this.f14938a, "android.permission.CAMERA") == 0) {
            this.f14939b.g();
        } else {
            if (this.f14951n) {
                return;
            }
            K.b.r(this.f14938a, new String[]{"android.permission.CAMERA"}, f14937p);
            this.f14951n = true;
        }
    }

    public void y(k4.b bVar) {
        this.f14938a.setResult(-1, x(bVar, o(bVar)));
        k();
    }

    public void z() {
        Intent intent = new Intent("com.google.zxing.client.android.SCAN");
        intent.putExtra("TIMEOUT", true);
        this.f14938a.setResult(0, intent);
        k();
    }
}
