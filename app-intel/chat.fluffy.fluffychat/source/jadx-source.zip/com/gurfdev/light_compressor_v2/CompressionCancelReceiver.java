package com.gurfdev.light_compressor_v2;

import M5.m;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import d4.C0995e;

/* loaded from: classes.dex */
public final class CompressionCancelReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        m.e(context, "context");
        C0995e.e();
    }
}
