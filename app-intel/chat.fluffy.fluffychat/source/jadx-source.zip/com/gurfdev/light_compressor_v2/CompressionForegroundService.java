package com.gurfdev.light_compressor_v2;

import F2.AbstractC0341b;
import F2.AbstractC0342c;
import K.k;
import K.r;
import L.b;
import M5.g;
import M5.m;
import S5.e;
import android.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/* loaded from: classes.dex */
public final class CompressionForegroundService extends Service {

    /* renamed from: m, reason: collision with root package name */
    public static volatile String f14807m;

    /* renamed from: n, reason: collision with root package name */
    public static volatile String f14808n;

    /* renamed from: p, reason: collision with root package name */
    public static volatile long f14810p;

    /* renamed from: l, reason: collision with root package name */
    public static final a f14806l = new a(null);

    /* renamed from: o, reason: collision with root package name */
    public static volatile int f14809o = -1;

    public static final class a {
        public /* synthetic */ a(g gVar) {
            this();
        }

        public final Notification c(Context context, String str, String str2, Integer num) {
            k.e eVarA = new k.e(context, "light_compressor_compression").o(str).n(str2).J(R.drawable.stat_sys_download).C(true).D(true).E(-1).H(true).S(CompressionForegroundService.f14810p > 0 ? CompressionForegroundService.f14810p : System.currentTimeMillis()).P(true).a(R.drawable.ic_menu_close_clear_cancel, context.getString(R.string.cancel), d(context));
            m.d(eVarA, "addAction(...)");
            PendingIntent pendingIntentF = f(context);
            if (pendingIntentF != null) {
                eVarA.m(pendingIntentF);
            }
            if (num == null) {
                eVarA.F(0, 0, true);
            } else {
                int iJ = e.j(num.intValue(), 0, 100);
                eVarA.F(100, iJ, false);
                StringBuilder sb = new StringBuilder();
                sb.append(iJ);
                sb.append('%');
                eVarA.M(sb.toString());
            }
            Notification notificationD = eVarA.d();
            m.d(notificationD, "build(...)");
            return notificationD;
        }

        public final PendingIntent d(Context context) {
            PendingIntent broadcast = PendingIntent.getBroadcast(context, 1, new Intent(context, (Class<?>) CompressionCancelReceiver.class), g());
            m.d(broadcast, "getBroadcast(...)");
            return broadcast;
        }

        public final void e(Context context) {
            if (Build.VERSION.SDK_INT >= 26) {
                Object systemService = context.getSystemService("notification");
                m.c(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
                NotificationManager notificationManager = (NotificationManager) systemService;
                if (notificationManager.getNotificationChannel("light_compressor_compression") == null) {
                    AbstractC0342c.a();
                    notificationManager.createNotificationChannel(AbstractC0341b.a("light_compressor_compression", "Video compression", 2));
                }
            }
        }

        public final PendingIntent f(Context context) {
            Intent launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            if (launchIntentForPackage == null) {
                return null;
            }
            launchIntentForPackage.addFlags(268566528);
            return PendingIntent.getActivity(context, 0, launchIntentForPackage, g());
        }

        public final int g() {
            return 201326592;
        }

        public final void h(Context context, String str, String str2) {
            m.e(context, "context");
            m.e(str, "title");
            m.e(str2, "text");
            CompressionForegroundService.f14807m = str;
            CompressionForegroundService.f14808n = str2;
            CompressionForegroundService.f14809o = -1;
            CompressionForegroundService.f14810p = System.currentTimeMillis();
            Intent intent = new Intent(context, (Class<?>) CompressionForegroundService.class);
            intent.putExtra("title", str);
            intent.putExtra("text", str2);
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        }

        public final void i(Context context) {
            m.e(context, "context");
            CompressionForegroundService.f14807m = null;
            CompressionForegroundService.f14808n = null;
            CompressionForegroundService.f14809o = -1;
            CompressionForegroundService.f14810p = 0L;
            context.stopService(new Intent(context, (Class<?>) CompressionForegroundService.class));
        }

        public final void j(Context context, int i7, String str) {
            m.e(context, "context");
            String str2 = CompressionForegroundService.f14807m;
            if (str2 == null) {
                return;
            }
            int iJ = e.j(i7, 0, 100);
            if (str == null) {
                str = CompressionForegroundService.f14808n;
            }
            if (iJ == CompressionForegroundService.f14809o && m.a(str, CompressionForegroundService.f14808n)) {
                return;
            }
            CompressionForegroundService.f14809o = iJ;
            if (str != null) {
                CompressionForegroundService.f14808n = str;
            }
            if (Build.VERSION.SDK_INT < 33 || b.a(context, "android.permission.POST_NOTIFICATIONS") == 0) {
                r rVarG = r.g(context);
                String str3 = CompressionForegroundService.f14808n;
                if (str3 == null) {
                    str3 = "Video compression in progress…";
                }
                rVarG.k(12648430, c(context, str2, str3, Integer.valueOf(iJ)));
            }
        }

        public a() {
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i7, int i8) {
        String stringExtra;
        String stringExtra2;
        if (intent == null || (stringExtra = intent.getStringExtra("title")) == null) {
            stringExtra = "Compressing video";
        }
        if (intent == null || (stringExtra2 = intent.getStringExtra("text")) == null) {
            stringExtra2 = "Video compression in progress…";
        }
        f14807m = stringExtra;
        f14808n = stringExtra2;
        a aVar = f14806l;
        aVar.e(this);
        Notification notificationC = aVar.c(this, stringExtra, stringExtra2, null);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(12648430, notificationC, 1);
            return 2;
        }
        startForeground(12648430, notificationC);
        return 2;
    }
}
