package com.fasterxml.jackson.databind.node;

import com.fasterxml.jackson.databind.util.RawValue;
import java.math.BigDecimal;
import java.math.BigInteger;

/* loaded from: classes.dex */
public interface JsonNodeCreator {
    ArrayNode arrayNode();

    ArrayNode arrayNode(int i7);

    ValueNode binaryNode(byte[] bArr);

    ValueNode binaryNode(byte[] bArr, int i7, int i8);

    ValueNode booleanNode(boolean z7);

    ValueNode nullNode();

    ValueNode numberNode(byte b7);

    ValueNode numberNode(double d7);

    ValueNode numberNode(float f7);

    ValueNode numberNode(int i7);

    ValueNode numberNode(long j7);

    ValueNode numberNode(Byte b7);

    ValueNode numberNode(Double d7);

    ValueNode numberNode(Float f7);

    ValueNode numberNode(Integer num);

    ValueNode numberNode(Long l7);

    ValueNode numberNode(Short sh);

    ValueNode numberNode(BigDecimal bigDecimal);

    ValueNode numberNode(BigInteger bigInteger);

    ValueNode numberNode(short s7);

    ObjectNode objectNode();

    ValueNode pojoNode(Object obj);

    ValueNode rawValueNode(RawValue rawValue);

    ValueNode textNode(String str);
}
