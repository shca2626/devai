package com.fasterxml.jackson.databind.deser.std;

import com.fasterxml.jackson.core.Base64Variants;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import java.util.Arrays;
import java.util.UUID;

/* loaded from: classes.dex */
public class UUIDDeserializer extends FromStringDeserializer<UUID> {
    static final int[] HEX_DIGITS;
    private static final long serialVersionUID = 1;

    static {
        int[] iArr = new int[127];
        HEX_DIGITS = iArr;
        Arrays.fill(iArr, -1);
        for (int i7 = 0; i7 < 10; i7++) {
            HEX_DIGITS[i7 + 48] = i7;
        }
        for (int i8 = 0; i8 < 6; i8++) {
            int[] iArr2 = HEX_DIGITS;
            int i9 = i8 + 10;
            iArr2[i8 + 97] = i9;
            iArr2[i8 + 65] = i9;
        }
    }

    public UUIDDeserializer() {
        super(UUID.class);
    }

    private UUID _badFormat(String str, DeserializationContext deserializationContext) {
        return (UUID) deserializationContext.handleWeirdStringValue(handledType(), str, "UUID has to be represented by standard 36-char representation", new Object[0]);
    }

    private UUID _fromBytes(byte[] bArr, DeserializationContext deserializationContext) throws InvalidFormatException {
        if (bArr.length == 16) {
            return new UUID(_long(bArr, 0), _long(bArr, 8));
        }
        throw InvalidFormatException.from(deserializationContext.getParser(), "Can only construct UUIDs from byte[16]; got " + bArr.length + " bytes", bArr, handledType());
    }

    private static int _int(byte[] bArr, int i7) {
        return (bArr[i7 + 3] & 255) | (bArr[i7] << 24) | ((bArr[i7 + 1] & 255) << 16) | ((bArr[i7 + 2] & 255) << 8);
    }

    private static long _long(byte[] bArr, int i7) {
        return ((_int(bArr, i7 + 4) << 32) >>> 32) | (_int(bArr, i7) << 32);
    }

    public int _badChar(String str, int i7, DeserializationContext deserializationContext, char c7) throws JsonMappingException {
        throw deserializationContext.weirdStringException(str, handledType(), String.format("Non-hex character '%c' (value 0x%s), not valid for UUID String", Character.valueOf(c7), Integer.toHexString(c7)));
    }

    public int byteFromChars(String str, int i7, DeserializationContext deserializationContext) {
        char cCharAt = str.charAt(i7);
        int i8 = i7 + 1;
        char cCharAt2 = str.charAt(i8);
        if (cCharAt <= 127 && cCharAt2 <= 127) {
            int[] iArr = HEX_DIGITS;
            int i9 = iArr[cCharAt2] | (iArr[cCharAt] << 4);
            if (i9 >= 0) {
                return i9;
            }
        }
        return (cCharAt > 127 || HEX_DIGITS[cCharAt] < 0) ? _badChar(str, i7, deserializationContext, cCharAt) : _badChar(str, i8, deserializationContext, cCharAt2);
    }

    public int intFromChars(String str, int i7, DeserializationContext deserializationContext) {
        return (byteFromChars(str, i7, deserializationContext) << 24) + (byteFromChars(str, i7 + 2, deserializationContext) << 16) + (byteFromChars(str, i7 + 4, deserializationContext) << 8) + byteFromChars(str, i7 + 6, deserializationContext);
    }

    public int shortFromChars(String str, int i7, DeserializationContext deserializationContext) {
        return (byteFromChars(str, i7, deserializationContext) << 8) + byteFromChars(str, i7 + 2, deserializationContext);
    }

    @Override // com.fasterxml.jackson.databind.deser.std.FromStringDeserializer
    public UUID _deserialize(String str, DeserializationContext deserializationContext) {
        if (str.length() != 36) {
            return str.length() == 24 ? _fromBytes(Base64Variants.getDefaultVariant().decode(str), deserializationContext) : _badFormat(str, deserializationContext);
        }
        if (str.charAt(8) != '-' || str.charAt(13) != '-' || str.charAt(18) != '-' || str.charAt(23) != '-') {
            _badFormat(str, deserializationContext);
        }
        return new UUID((intFromChars(str, 0, deserializationContext) << 32) + ((shortFromChars(str, 9, deserializationContext) << 16) | shortFromChars(str, 14, deserializationContext)), ((intFromChars(str, 28, deserializationContext) << 32) >>> 32) | ((shortFromChars(str, 24, deserializationContext) | (shortFromChars(str, 19, deserializationContext) << 16)) << 32));
    }

    @Override // com.fasterxml.jackson.databind.deser.std.FromStringDeserializer
    public UUID _deserializeEmbedded(Object obj, DeserializationContext deserializationContext) throws MismatchedInputException {
        if (obj instanceof byte[]) {
            return _fromBytes((byte[]) obj, deserializationContext);
        }
        super._deserializeEmbedded(obj, deserializationContext);
        return null;
    }
}
