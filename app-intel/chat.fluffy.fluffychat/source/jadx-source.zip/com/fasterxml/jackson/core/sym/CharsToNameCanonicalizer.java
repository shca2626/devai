package com.fasterxml.jackson.core.sym;

import R0.AbstractC0571i;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.util.InternCache;
import java.util.Arrays;
import java.util.BitSet;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class CharsToNameCanonicalizer {
    private static final int DEFAULT_T_SIZE = 64;
    public static final int HASH_MULT = 33;
    static final int MAX_COLL_CHAIN_LENGTH = 100;
    static final int MAX_ENTRIES_FOR_REUSE = 12000;
    private static final int MAX_T_SIZE = 65536;
    private Bucket[] _buckets;
    private boolean _canonicalize;
    private final int _flags;
    private boolean _hashShared;
    private int _indexMask;
    private int _longestCollisionList;
    private BitSet _overflows;
    private final CharsToNameCanonicalizer _parent;
    private final int _seed;
    private int _size;
    private int _sizeThreshold;
    private String[] _symbols;
    private final AtomicReference<TableInfo> _tableInfo;

    public static final class Bucket {
        public final int length;
        public final Bucket next;
        public final String symbol;

        public Bucket(String str, Bucket bucket) {
            this.symbol = str;
            this.next = bucket;
            this.length = bucket != null ? 1 + bucket.length : 1;
        }

        public String has(char[] cArr, int i7, int i8) {
            if (this.symbol.length() != i8) {
                return null;
            }
            int i9 = 0;
            while (this.symbol.charAt(i9) == cArr[i7 + i9]) {
                i9++;
                if (i9 >= i8) {
                    return this.symbol;
                }
            }
            return null;
        }
    }

    private CharsToNameCanonicalizer(int i7) {
        this._parent = null;
        this._seed = i7;
        this._canonicalize = true;
        this._flags = -1;
        this._hashShared = false;
        this._longestCollisionList = 0;
        this._tableInfo = new AtomicReference<>(TableInfo.createInitial(64));
    }

    private String _addSymbol(char[] cArr, int i7, int i8, int i9, int i10) {
        if (this._hashShared) {
            copyArrays();
            this._hashShared = false;
        } else if (this._size >= this._sizeThreshold) {
            rehash();
            i10 = _hashToIndex(calcHash(cArr, i7, i8));
        }
        String str = new String(cArr, i7, i8);
        if (JsonFactory.Feature.INTERN_FIELD_NAMES.enabledIn(this._flags)) {
            str = InternCache.instance.intern(str);
        }
        this._size++;
        String[] strArr = this._symbols;
        if (strArr[i10] == null) {
            strArr[i10] = str;
            return str;
        }
        int i11 = i10 >> 1;
        Bucket bucket = new Bucket(str, this._buckets[i11]);
        int i12 = bucket.length;
        if (i12 > MAX_COLL_CHAIN_LENGTH) {
            _handleSpillOverflow(i11, bucket, i10);
            return str;
        }
        this._buckets[i11] = bucket;
        this._longestCollisionList = Math.max(i12, this._longestCollisionList);
        return str;
    }

    private String _findSymbol2(char[] cArr, int i7, int i8, Bucket bucket) {
        while (bucket != null) {
            String strHas = bucket.has(cArr, i7, i8);
            if (strHas != null) {
                return strHas;
            }
            bucket = bucket.next;
        }
        return null;
    }

    private void _handleSpillOverflow(int i7, Bucket bucket, int i8) {
        BitSet bitSet = this._overflows;
        if (bitSet == null) {
            BitSet bitSet2 = new BitSet();
            this._overflows = bitSet2;
            bitSet2.set(i7);
        } else if (bitSet.get(i7)) {
            if (JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW.enabledIn(this._flags)) {
                reportTooManyCollisions(MAX_COLL_CHAIN_LENGTH);
            }
            this._canonicalize = false;
        } else {
            this._overflows.set(i7);
        }
        this._symbols[i8] = bucket.symbol;
        this._buckets[i7] = null;
        this._size -= bucket.length;
        this._longestCollisionList = -1;
    }

    private static int _thresholdSize(int i7) {
        return i7 - (i7 >> 2);
    }

    private void copyArrays() {
        String[] strArr = this._symbols;
        this._symbols = (String[]) Arrays.copyOf(strArr, strArr.length);
        Bucket[] bucketArr = this._buckets;
        this._buckets = (Bucket[]) Arrays.copyOf(bucketArr, bucketArr.length);
    }

    public static CharsToNameCanonicalizer createRoot() {
        long jCurrentTimeMillis = System.currentTimeMillis();
        return createRoot((((int) jCurrentTimeMillis) + ((int) (jCurrentTimeMillis >>> 32))) | 1);
    }

    private void mergeChild(TableInfo tableInfo) {
        int i7 = tableInfo.size;
        TableInfo tableInfo2 = this._tableInfo.get();
        if (i7 == tableInfo2.size) {
            return;
        }
        if (i7 > MAX_ENTRIES_FOR_REUSE) {
            tableInfo = TableInfo.createInitial(64);
        }
        AbstractC0571i.a(this._tableInfo, tableInfo2, tableInfo);
    }

    private void rehash() {
        String[] strArr = this._symbols;
        int length = strArr.length;
        int i7 = length + length;
        if (i7 > MAX_T_SIZE) {
            this._size = 0;
            this._canonicalize = false;
            this._symbols = new String[64];
            this._buckets = new Bucket[32];
            this._indexMask = 63;
            this._hashShared = false;
            return;
        }
        Bucket[] bucketArr = this._buckets;
        this._symbols = new String[i7];
        this._buckets = new Bucket[i7 >> 1];
        this._indexMask = i7 - 1;
        this._sizeThreshold = _thresholdSize(i7);
        int i8 = 0;
        int iMax = 0;
        for (String str : strArr) {
            if (str != null) {
                i8++;
                int i_hashToIndex = _hashToIndex(calcHash(str));
                String[] strArr2 = this._symbols;
                if (strArr2[i_hashToIndex] == null) {
                    strArr2[i_hashToIndex] = str;
                } else {
                    int i9 = i_hashToIndex >> 1;
                    Bucket bucket = new Bucket(str, this._buckets[i9]);
                    this._buckets[i9] = bucket;
                    iMax = Math.max(iMax, bucket.length);
                }
            }
        }
        int i10 = length >> 1;
        for (int i11 = 0; i11 < i10; i11++) {
            for (Bucket bucket2 = bucketArr[i11]; bucket2 != null; bucket2 = bucket2.next) {
                i8++;
                String str2 = bucket2.symbol;
                int i_hashToIndex2 = _hashToIndex(calcHash(str2));
                String[] strArr3 = this._symbols;
                if (strArr3[i_hashToIndex2] == null) {
                    strArr3[i_hashToIndex2] = str2;
                } else {
                    int i12 = i_hashToIndex2 >> 1;
                    Bucket bucket3 = new Bucket(str2, this._buckets[i12]);
                    this._buckets[i12] = bucket3;
                    iMax = Math.max(iMax, bucket3.length);
                }
            }
        }
        this._longestCollisionList = iMax;
        this._overflows = null;
        if (i8 != this._size) {
            throw new IllegalStateException(String.format("Internal error on SymbolTable.rehash(): had %d entries; now have %d", Integer.valueOf(this._size), Integer.valueOf(i8)));
        }
    }

    public int _hashToIndex(int i7) {
        int i8 = i7 + (i7 >>> 15);
        int i9 = i8 ^ (i8 << 7);
        return (i9 + (i9 >>> 3)) & this._indexMask;
    }

    public int bucketCount() {
        return this._symbols.length;
    }

    public int calcHash(char[] cArr, int i7, int i8) {
        int i9 = this._seed;
        int i10 = i8 + i7;
        while (i7 < i10) {
            i9 = (i9 * 33) + cArr[i7];
            i7++;
        }
        if (i9 == 0) {
            return 1;
        }
        return i9;
    }

    public int collisionCount() {
        int i7 = 0;
        for (Bucket bucket : this._buckets) {
            if (bucket != null) {
                i7 += bucket.length;
            }
        }
        return i7;
    }

    public String findSymbol(char[] cArr, int i7, int i8, int i9) {
        if (i8 < 1) {
            return "";
        }
        if (!this._canonicalize) {
            return new String(cArr, i7, i8);
        }
        int i_hashToIndex = _hashToIndex(i9);
        String str = this._symbols[i_hashToIndex];
        if (str != null) {
            if (str.length() == i8) {
                int i10 = 0;
                while (str.charAt(i10) == cArr[i7 + i10]) {
                    i10++;
                    if (i10 == i8) {
                        return str;
                    }
                }
            }
            Bucket bucket = this._buckets[i_hashToIndex >> 1];
            if (bucket != null) {
                String strHas = bucket.has(cArr, i7, i8);
                if (strHas != null) {
                    return strHas;
                }
                String str_findSymbol2 = _findSymbol2(cArr, i7, i8, bucket.next);
                if (str_findSymbol2 != null) {
                    return str_findSymbol2;
                }
            }
        }
        return _addSymbol(cArr, i7, i8, i9, i_hashToIndex);
    }

    public int hashSeed() {
        return this._seed;
    }

    public CharsToNameCanonicalizer makeChild(int i7) {
        return new CharsToNameCanonicalizer(this, i7, this._seed, this._tableInfo.get());
    }

    public int maxCollisionLength() {
        return this._longestCollisionList;
    }

    public boolean maybeDirty() {
        return !this._hashShared;
    }

    public void release() {
        CharsToNameCanonicalizer charsToNameCanonicalizer;
        if (maybeDirty() && (charsToNameCanonicalizer = this._parent) != null && this._canonicalize) {
            charsToNameCanonicalizer.mergeChild(new TableInfo(this));
            this._hashShared = true;
        }
    }

    public void reportTooManyCollisions(int i7) {
        throw new IllegalStateException("Longest collision chain in symbol table (of size " + this._size + ") now exceeds maximum, " + i7 + " -- suspect a DoS attack based on hash collisions");
    }

    public int size() {
        AtomicReference<TableInfo> atomicReference = this._tableInfo;
        return atomicReference != null ? atomicReference.get().size : this._size;
    }

    public void verifyInternalConsistency() {
        int length = this._symbols.length;
        int i7 = 0;
        for (int i8 = 0; i8 < length; i8++) {
            if (this._symbols[i8] != null) {
                i7++;
            }
        }
        int i9 = length >> 1;
        for (int i10 = 0; i10 < i9; i10++) {
            for (Bucket bucket = this._buckets[i10]; bucket != null; bucket = bucket.next) {
                i7++;
            }
        }
        if (i7 != this._size) {
            throw new IllegalStateException(String.format("Internal error: expected internal size %d vs calculated count %d", Integer.valueOf(this._size), Integer.valueOf(i7)));
        }
    }

    public static CharsToNameCanonicalizer createRoot(int i7) {
        return new CharsToNameCanonicalizer(i7);
    }

    public int calcHash(String str) {
        int length = str.length();
        int iCharAt = this._seed;
        for (int i7 = 0; i7 < length; i7++) {
            iCharAt = (iCharAt * 33) + str.charAt(i7);
        }
        if (iCharAt == 0) {
            return 1;
        }
        return iCharAt;
    }

    public static final class TableInfo {
        final Bucket[] buckets;
        final int longestCollisionList;
        final int size;
        final String[] symbols;

        public TableInfo(int i7, int i8, String[] strArr, Bucket[] bucketArr) {
            this.size = i7;
            this.longestCollisionList = i8;
            this.symbols = strArr;
            this.buckets = bucketArr;
        }

        public static TableInfo createInitial(int i7) {
            return new TableInfo(0, 0, new String[i7], new Bucket[i7 >> 1]);
        }

        public TableInfo(CharsToNameCanonicalizer charsToNameCanonicalizer) {
            this.size = charsToNameCanonicalizer._size;
            this.longestCollisionList = charsToNameCanonicalizer._longestCollisionList;
            this.symbols = charsToNameCanonicalizer._symbols;
            this.buckets = charsToNameCanonicalizer._buckets;
        }
    }

    private CharsToNameCanonicalizer(CharsToNameCanonicalizer charsToNameCanonicalizer, int i7, int i8, TableInfo tableInfo) {
        this._parent = charsToNameCanonicalizer;
        this._seed = i8;
        this._tableInfo = null;
        this._flags = i7;
        this._canonicalize = JsonFactory.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(i7);
        String[] strArr = tableInfo.symbols;
        this._symbols = strArr;
        this._buckets = tableInfo.buckets;
        this._size = tableInfo.size;
        this._longestCollisionList = tableInfo.longestCollisionList;
        int length = strArr.length;
        this._sizeThreshold = _thresholdSize(length);
        this._indexMask = length - 1;
        this._hashShared = true;
    }
}
