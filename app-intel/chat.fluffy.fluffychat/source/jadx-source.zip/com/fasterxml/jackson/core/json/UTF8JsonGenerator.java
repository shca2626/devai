package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.Base64Variant;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonStreamContext;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.PrettyPrinter;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.io.CharacterEscapes;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.NumberOutput;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;

/* loaded from: classes.dex */
public class UTF8JsonGenerator extends JsonGeneratorImpl {
    private static final byte BYTE_0 = 48;
    private static final byte BYTE_BACKSLASH = 92;
    private static final byte BYTE_COLON = 58;
    private static final byte BYTE_COMMA = 44;
    private static final byte BYTE_LBRACKET = 91;
    private static final byte BYTE_LCURLY = 123;
    private static final byte BYTE_RBRACKET = 93;
    private static final byte BYTE_RCURLY = 125;
    private static final int MAX_BYTES_TO_BUFFER = 512;
    protected boolean _bufferRecyclable;
    protected char[] _charBuffer;
    protected final int _charBufferLength;
    protected byte[] _entityBuffer;
    protected byte[] _outputBuffer;
    protected final int _outputEnd;
    protected final int _outputMaxContiguous;
    protected final OutputStream _outputStream;
    protected int _outputTail;
    protected byte _quoteChar;
    private static final byte[] HEX_CHARS = CharTypes.copyHexBytes();
    private static final byte BYTE_u = 117;
    private static final byte[] NULL_BYTES = {110, BYTE_u, 108, 108};
    private static final byte[] TRUE_BYTES = {116, 114, BYTE_u, 101};
    private static final byte[] FALSE_BYTES = {102, 97, 108, 115, 101};

    public UTF8JsonGenerator(IOContext iOContext, int i7, ObjectCodec objectCodec, OutputStream outputStream, char c7) {
        super(iOContext, i7, objectCodec);
        this._outputStream = outputStream;
        this._quoteChar = (byte) c7;
        if (c7 != '\"') {
            this._outputEscapes = CharTypes.get7BitOutputEscapes(c7);
        }
        this._bufferRecyclable = true;
        byte[] bArrAllocWriteEncodingBuffer = iOContext.allocWriteEncodingBuffer();
        this._outputBuffer = bArrAllocWriteEncodingBuffer;
        int length = bArrAllocWriteEncodingBuffer.length;
        this._outputEnd = length;
        this._outputMaxContiguous = length >> 3;
        char[] cArrAllocConcatBuffer = iOContext.allocConcatBuffer();
        this._charBuffer = cArrAllocConcatBuffer;
        this._charBufferLength = cArrAllocConcatBuffer.length;
        if (isEnabled(JsonGenerator.Feature.ESCAPE_NON_ASCII)) {
            setHighestNonEscapedChar(127);
        }
    }

    private final int _handleLongCustomEscape(byte[] bArr, int i7, int i8, byte[] bArr2, int i9) throws IOException {
        int length = bArr2.length;
        if (i7 + length > i8) {
            this._outputTail = i7;
            _flushBuffer();
            i7 = this._outputTail;
            if (length > bArr.length) {
                this._outputStream.write(bArr2, 0, length);
                return i7;
            }
        }
        System.arraycopy(bArr2, 0, bArr, i7, length);
        int i10 = i7 + length;
        if ((i9 * 6) + i10 <= i8) {
            return i10;
        }
        this._outputTail = i10;
        _flushBuffer();
        return this._outputTail;
    }

    private final int _outputMultiByteChar(int i7, int i8) {
        byte[] bArr = this._outputBuffer;
        if (i7 < 55296 || i7 > 57343) {
            bArr[i8] = (byte) ((i7 >> 12) | 224);
            int i9 = i8 + 2;
            bArr[i8 + 1] = (byte) (((i7 >> 6) & 63) | 128);
            int i10 = i8 + 3;
            bArr[i9] = (byte) ((i7 & 63) | 128);
            return i10;
        }
        bArr[i8] = BYTE_BACKSLASH;
        bArr[i8 + 1] = BYTE_u;
        byte[] bArr2 = HEX_CHARS;
        bArr[i8 + 2] = bArr2[(i7 >> 12) & 15];
        bArr[i8 + 3] = bArr2[(i7 >> 8) & 15];
        int i11 = i8 + 5;
        bArr[i8 + 4] = bArr2[(i7 >> 4) & 15];
        int i12 = i8 + 6;
        bArr[i11] = bArr2[i7 & 15];
        return i12;
    }

    private final int _outputRawMultiByteChar(int i7, char[] cArr, int i8, int i9) throws IOException {
        if (i7 >= 55296 && i7 <= 57343) {
            if (i8 >= i9 || cArr == null) {
                _reportError(String.format("Split surrogate on writeRaw() input (last character): first character 0x%4x", Integer.valueOf(i7)));
            }
            _outputSurrogates(i7, cArr[i8]);
            return i8 + 1;
        }
        byte[] bArr = this._outputBuffer;
        int i10 = this._outputTail;
        int i11 = i10 + 1;
        this._outputTail = i11;
        bArr[i10] = (byte) ((i7 >> 12) | 224);
        int i12 = i10 + 2;
        this._outputTail = i12;
        bArr[i11] = (byte) (((i7 >> 6) & 63) | 128);
        this._outputTail = i10 + 3;
        bArr[i12] = (byte) ((i7 & 63) | 128);
        return i8;
    }

    private final int _readMore(InputStream inputStream, byte[] bArr, int i7, int i8, int i9) {
        int i10;
        int i11 = 0;
        while (i7 < i8) {
            bArr[i11] = bArr[i7];
            i11++;
            i7++;
        }
        int iMin = Math.min(i9, bArr.length);
        do {
            int i12 = iMin - i11;
            if (i12 == 0 || (i10 = inputStream.read(bArr, i11, i12)) < 0) {
                return i11;
            }
            i11 += i10;
        } while (i11 < 3);
        return i11;
    }

    private final void _writeBytes(byte[] bArr) throws IOException {
        int length = bArr.length;
        if (this._outputTail + length > this._outputEnd) {
            _flushBuffer();
            if (length > MAX_BYTES_TO_BUFFER) {
                this._outputStream.write(bArr, 0, length);
                return;
            }
        }
        System.arraycopy(bArr, 0, this._outputBuffer, this._outputTail, length);
        this._outputTail += length;
    }

    private final int _writeCustomEscape(byte[] bArr, int i7, SerializableString serializableString, int i8) {
        byte[] bArrAsUnquotedUTF8 = serializableString.asUnquotedUTF8();
        int length = bArrAsUnquotedUTF8.length;
        if (length > 6) {
            return _handleLongCustomEscape(bArr, i7, this._outputEnd, bArrAsUnquotedUTF8, i8);
        }
        System.arraycopy(bArrAsUnquotedUTF8, 0, bArr, i7, length);
        return i7 + length;
    }

    private final void _writeCustomStringSegment2(char[] cArr, int i7, int i8) throws IOException {
        if (this._outputTail + ((i8 - i7) * 6) > this._outputEnd) {
            _flushBuffer();
        }
        int i_outputMultiByteChar = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        int i9 = this._maximumNonEscapedChar;
        if (i9 <= 0) {
            i9 = 65535;
        }
        CharacterEscapes characterEscapes = this._characterEscapes;
        while (i7 < i8) {
            int i10 = i7 + 1;
            char c7 = cArr[i7];
            if (c7 <= 127) {
                int i11 = iArr[c7];
                if (i11 == 0) {
                    bArr[i_outputMultiByteChar] = (byte) c7;
                    i7 = i10;
                    i_outputMultiByteChar++;
                } else if (i11 > 0) {
                    int i12 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = BYTE_BACKSLASH;
                    i_outputMultiByteChar += 2;
                    bArr[i12] = (byte) i11;
                } else if (i11 == -2) {
                    SerializableString escapeSequence = characterEscapes.getEscapeSequence(c7);
                    if (escapeSequence == null) {
                        _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + Integer.toHexString(c7) + ", although was supposed to have one");
                    }
                    i_outputMultiByteChar = _writeCustomEscape(bArr, i_outputMultiByteChar, escapeSequence, i8 - i10);
                } else {
                    i_outputMultiByteChar = _writeGenericEscape(c7, i_outputMultiByteChar);
                }
            } else if (c7 > i9) {
                i_outputMultiByteChar = _writeGenericEscape(c7, i_outputMultiByteChar);
            } else {
                SerializableString escapeSequence2 = characterEscapes.getEscapeSequence(c7);
                if (escapeSequence2 != null) {
                    i_outputMultiByteChar = _writeCustomEscape(bArr, i_outputMultiByteChar, escapeSequence2, i8 - i10);
                } else if (c7 <= 2047) {
                    int i13 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = (byte) ((c7 >> 6) | 192);
                    i_outputMultiByteChar += 2;
                    bArr[i13] = (byte) ((c7 & '?') | 128);
                } else {
                    i_outputMultiByteChar = _outputMultiByteChar(c7, i_outputMultiByteChar);
                }
            }
            i7 = i10;
        }
        this._outputTail = i_outputMultiByteChar;
    }

    private int _writeGenericEscape(int i7, int i8) {
        int i9;
        byte[] bArr = this._outputBuffer;
        bArr[i8] = BYTE_BACKSLASH;
        int i10 = i8 + 2;
        bArr[i8 + 1] = BYTE_u;
        if (i7 > 255) {
            int i11 = i7 >> 8;
            int i12 = i8 + 3;
            byte[] bArr2 = HEX_CHARS;
            bArr[i10] = bArr2[(i11 & 255) >> 4];
            i9 = i8 + 4;
            bArr[i12] = bArr2[i11 & 15];
            i7 &= 255;
        } else {
            int i13 = i8 + 3;
            bArr[i10] = BYTE_0;
            i9 = i8 + 4;
            bArr[i13] = BYTE_0;
        }
        int i14 = i9 + 1;
        byte[] bArr3 = HEX_CHARS;
        bArr[i9] = bArr3[i7 >> 4];
        int i15 = i9 + 2;
        bArr[i14] = bArr3[i7 & 15];
        return i15;
    }

    private final void _writeNull() throws IOException {
        if (this._outputTail + 4 >= this._outputEnd) {
            _flushBuffer();
        }
        System.arraycopy(NULL_BYTES, 0, this._outputBuffer, this._outputTail, 4);
        this._outputTail += 4;
    }

    private final void _writeQuotedInt(int i7) throws IOException {
        if (this._outputTail + 13 >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i8 = this._outputTail;
        int i9 = i8 + 1;
        this._outputTail = i9;
        bArr[i8] = this._quoteChar;
        int iOutputInt = NumberOutput.outputInt(i7, bArr, i9);
        byte[] bArr2 = this._outputBuffer;
        this._outputTail = iOutputInt + 1;
        bArr2[iOutputInt] = this._quoteChar;
    }

    private final void _writeQuotedLong(long j7) throws IOException {
        if (this._outputTail + 23 >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        int i8 = i7 + 1;
        this._outputTail = i8;
        bArr[i7] = this._quoteChar;
        int iOutputLong = NumberOutput.outputLong(j7, bArr, i8);
        byte[] bArr2 = this._outputBuffer;
        this._outputTail = iOutputLong + 1;
        bArr2[iOutputLong] = this._quoteChar;
    }

    private final void _writeQuotedRaw(String str) throws IOException {
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = this._quoteChar;
        writeRaw(str);
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i8 = this._outputTail;
        this._outputTail = i8 + 1;
        bArr2[i8] = this._quoteChar;
    }

    private final void _writeQuotedShort(short s7) throws IOException {
        if (this._outputTail + 8 >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        int i8 = i7 + 1;
        this._outputTail = i8;
        bArr[i7] = this._quoteChar;
        int iOutputInt = NumberOutput.outputInt(s7, bArr, i8);
        byte[] bArr2 = this._outputBuffer;
        this._outputTail = iOutputInt + 1;
        bArr2[iOutputInt] = this._quoteChar;
    }

    private void _writeRawSegment(char[] cArr, int i7, int i8) throws IOException {
        while (i7 < i8) {
            do {
                char c7 = cArr[i7];
                if (c7 > 127) {
                    i7++;
                    if (c7 < 2048) {
                        byte[] bArr = this._outputBuffer;
                        int i9 = this._outputTail;
                        int i10 = i9 + 1;
                        this._outputTail = i10;
                        bArr[i9] = (byte) ((c7 >> 6) | 192);
                        this._outputTail = i9 + 2;
                        bArr[i10] = (byte) ((c7 & '?') | 128);
                    } else {
                        i7 = _outputRawMultiByteChar(c7, cArr, i7, i8);
                    }
                } else {
                    byte[] bArr2 = this._outputBuffer;
                    int i11 = this._outputTail;
                    this._outputTail = i11 + 1;
                    bArr2[i11] = (byte) c7;
                    i7++;
                }
            } while (i7 < i8);
            return;
        }
    }

    private final void _writeSegmentedRaw(char[] cArr, int i7, int i8) throws IOException {
        int i9 = this._outputEnd;
        byte[] bArr = this._outputBuffer;
        int i10 = i8 + i7;
        while (i7 < i10) {
            do {
                char c7 = cArr[i7];
                if (c7 >= 128) {
                    if (this._outputTail + 3 >= this._outputEnd) {
                        _flushBuffer();
                    }
                    int i11 = i7 + 1;
                    char c8 = cArr[i7];
                    if (c8 < 2048) {
                        int i12 = this._outputTail;
                        int i13 = i12 + 1;
                        this._outputTail = i13;
                        bArr[i12] = (byte) ((c8 >> 6) | 192);
                        this._outputTail = i12 + 2;
                        bArr[i13] = (byte) ((c8 & '?') | 128);
                        i7 = i11;
                    } else {
                        i7 = _outputRawMultiByteChar(c8, cArr, i11, i10);
                    }
                } else {
                    if (this._outputTail >= i9) {
                        _flushBuffer();
                    }
                    int i14 = this._outputTail;
                    this._outputTail = i14 + 1;
                    bArr[i14] = (byte) c7;
                    i7++;
                }
            } while (i7 < i10);
            return;
        }
    }

    private final void _writeStringSegment(char[] cArr, int i7, int i8) throws IOException {
        int i9 = i8 + i7;
        int i10 = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        while (i7 < i9) {
            char c7 = cArr[i7];
            if (c7 > 127 || iArr[c7] != 0) {
                break;
            }
            bArr[i10] = (byte) c7;
            i7++;
            i10++;
        }
        this._outputTail = i10;
        if (i7 < i9) {
            if (this._characterEscapes != null) {
                _writeCustomStringSegment2(cArr, i7, i9);
            } else if (this._maximumNonEscapedChar == 0) {
                _writeStringSegment2(cArr, i7, i9);
            } else {
                _writeStringSegmentASCII2(cArr, i7, i9);
            }
        }
    }

    private final void _writeStringSegment2(char[] cArr, int i7, int i8) throws IOException {
        if (this._outputTail + ((i8 - i7) * 6) > this._outputEnd) {
            _flushBuffer();
        }
        int i_outputMultiByteChar = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        while (i7 < i8) {
            int i9 = i7 + 1;
            char c7 = cArr[i7];
            if (c7 <= 127) {
                int i10 = iArr[c7];
                if (i10 == 0) {
                    bArr[i_outputMultiByteChar] = (byte) c7;
                    i7 = i9;
                    i_outputMultiByteChar++;
                } else if (i10 > 0) {
                    int i11 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = BYTE_BACKSLASH;
                    i_outputMultiByteChar += 2;
                    bArr[i11] = (byte) i10;
                } else {
                    i_outputMultiByteChar = _writeGenericEscape(c7, i_outputMultiByteChar);
                }
            } else if (c7 <= 2047) {
                int i12 = i_outputMultiByteChar + 1;
                bArr[i_outputMultiByteChar] = (byte) ((c7 >> 6) | 192);
                i_outputMultiByteChar += 2;
                bArr[i12] = (byte) ((c7 & '?') | 128);
            } else {
                i_outputMultiByteChar = _outputMultiByteChar(c7, i_outputMultiByteChar);
            }
            i7 = i9;
        }
        this._outputTail = i_outputMultiByteChar;
    }

    private final void _writeStringSegmentASCII2(char[] cArr, int i7, int i8) throws IOException {
        if (this._outputTail + ((i8 - i7) * 6) > this._outputEnd) {
            _flushBuffer();
        }
        int i_outputMultiByteChar = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        int i9 = this._maximumNonEscapedChar;
        while (i7 < i8) {
            int i10 = i7 + 1;
            char c7 = cArr[i7];
            if (c7 <= 127) {
                int i11 = iArr[c7];
                if (i11 == 0) {
                    bArr[i_outputMultiByteChar] = (byte) c7;
                    i7 = i10;
                    i_outputMultiByteChar++;
                } else if (i11 > 0) {
                    int i12 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = BYTE_BACKSLASH;
                    i_outputMultiByteChar += 2;
                    bArr[i12] = (byte) i11;
                } else {
                    i_outputMultiByteChar = _writeGenericEscape(c7, i_outputMultiByteChar);
                }
            } else if (c7 > i9) {
                i_outputMultiByteChar = _writeGenericEscape(c7, i_outputMultiByteChar);
            } else if (c7 <= 2047) {
                int i13 = i_outputMultiByteChar + 1;
                bArr[i_outputMultiByteChar] = (byte) ((c7 >> 6) | 192);
                i_outputMultiByteChar += 2;
                bArr[i13] = (byte) ((c7 & '?') | 128);
            } else {
                i_outputMultiByteChar = _outputMultiByteChar(c7, i_outputMultiByteChar);
            }
            i7 = i10;
        }
        this._outputTail = i_outputMultiByteChar;
    }

    private final void _writeStringSegments(String str, boolean z7) throws IOException {
        if (z7) {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr = this._outputBuffer;
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = this._quoteChar;
        }
        int length = str.length();
        int i8 = 0;
        while (length > 0) {
            int iMin = Math.min(this._outputMaxContiguous, length);
            if (this._outputTail + iMin > this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegment(str, i8, iMin);
            i8 += iMin;
            length -= iMin;
        }
        if (z7) {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr2 = this._outputBuffer;
            int i9 = this._outputTail;
            this._outputTail = i9 + 1;
            bArr2[i9] = this._quoteChar;
        }
    }

    private final void _writeUTF8Segment(byte[] bArr, int i7, int i8) throws IOException {
        int[] iArr = this._outputEscapes;
        int i9 = i7 + i8;
        int i10 = i7;
        while (i10 < i9) {
            int i11 = i10 + 1;
            byte b7 = bArr[i10];
            if (b7 >= 0 && iArr[b7] != 0) {
                _writeUTF8Segment2(bArr, i7, i8);
                return;
            }
            i10 = i11;
        }
        if (this._outputTail + i8 > this._outputEnd) {
            _flushBuffer();
        }
        System.arraycopy(bArr, i7, this._outputBuffer, this._outputTail, i8);
        this._outputTail += i8;
    }

    private final void _writeUTF8Segment2(byte[] bArr, int i7, int i8) throws IOException {
        int i9;
        int i_writeGenericEscape = this._outputTail;
        if ((i8 * 6) + i_writeGenericEscape > this._outputEnd) {
            _flushBuffer();
            i_writeGenericEscape = this._outputTail;
        }
        byte[] bArr2 = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        int i10 = i8 + i7;
        while (i7 < i10) {
            int i11 = i7 + 1;
            byte b7 = bArr[i7];
            if (b7 < 0 || (i9 = iArr[b7]) == 0) {
                bArr2[i_writeGenericEscape] = b7;
                i7 = i11;
                i_writeGenericEscape++;
            } else {
                if (i9 > 0) {
                    int i12 = i_writeGenericEscape + 1;
                    bArr2[i_writeGenericEscape] = BYTE_BACKSLASH;
                    i_writeGenericEscape += 2;
                    bArr2[i12] = (byte) i9;
                } else {
                    i_writeGenericEscape = _writeGenericEscape(b7, i_writeGenericEscape);
                }
                i7 = i11;
            }
        }
        this._outputTail = i_writeGenericEscape;
    }

    private final void _writeUTF8Segments(byte[] bArr, int i7, int i8) throws IOException {
        do {
            int iMin = Math.min(this._outputMaxContiguous, i8);
            _writeUTF8Segment(bArr, i7, iMin);
            i7 += iMin;
            i8 -= iMin;
        } while (i8 > 0);
    }

    private final void _writeUnq(SerializableString serializableString) throws IOException {
        int iAppendQuotedUTF8 = serializableString.appendQuotedUTF8(this._outputBuffer, this._outputTail);
        if (iAppendQuotedUTF8 < 0) {
            _writeBytes(serializableString.asQuotedUTF8());
        } else {
            this._outputTail += iAppendQuotedUTF8;
        }
    }

    public final void _flushBuffer() throws IOException {
        int i7 = this._outputTail;
        if (i7 > 0) {
            this._outputTail = 0;
            this._outputStream.write(this._outputBuffer, 0, i7);
        }
    }

    public final void _outputSurrogates(int i7, int i8) throws IOException {
        int i_decodeSurrogate = _decodeSurrogate(i7, i8);
        if (this._outputTail + 4 > this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i9 = this._outputTail;
        int i10 = i9 + 1;
        this._outputTail = i10;
        bArr[i9] = (byte) ((i_decodeSurrogate >> 18) | 240);
        int i11 = i9 + 2;
        this._outputTail = i11;
        bArr[i10] = (byte) (((i_decodeSurrogate >> 12) & 63) | 128);
        int i12 = i9 + 3;
        this._outputTail = i12;
        bArr[i11] = (byte) (((i_decodeSurrogate >> 6) & 63) | 128);
        this._outputTail = i9 + 4;
        bArr[i12] = (byte) ((i_decodeSurrogate & 63) | 128);
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase
    public void _releaseBuffers() {
        byte[] bArr = this._outputBuffer;
        if (bArr != null && this._bufferRecyclable) {
            this._outputBuffer = null;
            this._ioContext.releaseWriteEncodingBuffer(bArr);
        }
        char[] cArr = this._charBuffer;
        if (cArr != null) {
            this._charBuffer = null;
            this._ioContext.releaseConcatBuffer(cArr);
        }
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase
    public final void _verifyValueWrite(String str) throws IOException {
        byte b7;
        int iWriteValue = this._writeContext.writeValue();
        if (this._cfgPrettyPrinter != null) {
            _verifyPrettyValueWrite(str, iWriteValue);
            return;
        }
        if (iWriteValue == 1) {
            b7 = BYTE_COMMA;
        } else {
            if (iWriteValue != 2) {
                if (iWriteValue != 3) {
                    if (iWriteValue != 5) {
                        return;
                    }
                    _reportCantWriteValueExpectName(str);
                    return;
                }
                SerializableString serializableString = this._rootValueSeparator;
                if (serializableString != null) {
                    byte[] bArrAsUnquotedUTF8 = serializableString.asUnquotedUTF8();
                    if (bArrAsUnquotedUTF8.length > 0) {
                        _writeBytes(bArrAsUnquotedUTF8);
                        return;
                    }
                    return;
                }
                return;
            }
            b7 = BYTE_COLON;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = b7;
    }

    public final void _writeBinary(Base64Variant base64Variant, byte[] bArr, int i7, int i8) throws IOException {
        int iEncodeBase64Chunk;
        int i9 = i8 - 3;
        int i10 = this._outputEnd - 6;
        int maxLineLength = base64Variant.getMaxLineLength();
        loop0: while (true) {
            int i11 = maxLineLength >> 2;
            while (i7 <= i9) {
                if (this._outputTail > i10) {
                    _flushBuffer();
                }
                int i12 = i7 + 2;
                int i13 = ((bArr[i7 + 1] & 255) | (bArr[i7] << 8)) << 8;
                i7 += 3;
                iEncodeBase64Chunk = base64Variant.encodeBase64Chunk(i13 | (bArr[i12] & 255), this._outputBuffer, this._outputTail);
                this._outputTail = iEncodeBase64Chunk;
                i11--;
                if (i11 <= 0) {
                    break;
                }
            }
            byte[] bArr2 = this._outputBuffer;
            int i14 = iEncodeBase64Chunk + 1;
            this._outputTail = i14;
            bArr2[iEncodeBase64Chunk] = BYTE_BACKSLASH;
            this._outputTail = iEncodeBase64Chunk + 2;
            bArr2[i14] = 110;
            maxLineLength = base64Variant.getMaxLineLength();
        }
        int i15 = i8 - i7;
        if (i15 > 0) {
            if (this._outputTail > i10) {
                _flushBuffer();
            }
            int i16 = i7 + 1;
            int i17 = bArr[i7] << 16;
            if (i15 == 2) {
                i17 |= (bArr[i16] & 255) << 8;
            }
            this._outputTail = base64Variant.encodeBase64Partial(i17, i15, this._outputBuffer, this._outputTail);
        }
    }

    public final void _writePPFieldName(String str) throws IOException {
        int iWriteFieldName = this._writeContext.writeFieldName(str);
        if (iWriteFieldName == 4) {
            _reportError("Can not write a field name, expecting a value");
        }
        if (iWriteFieldName == 1) {
            this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
        } else {
            this._cfgPrettyPrinter.beforeObjectEntries(this);
        }
        if (this._cfgUnqNames) {
            _writeStringSegments(str, false);
            return;
        }
        int length = str.length();
        if (length > this._charBufferLength) {
            _writeStringSegments(str, true);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = this._quoteChar;
        str.getChars(0, length, this._charBuffer, 0);
        if (length <= this._outputMaxContiguous) {
            if (this._outputTail + length > this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegment(this._charBuffer, 0, length);
        } else {
            _writeStringSegments(this._charBuffer, 0, length);
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i8 = this._outputTail;
        this._outputTail = i8 + 1;
        bArr2[i8] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        super.close();
        if (this._outputBuffer != null && isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
            while (true) {
                JsonStreamContext outputContext = getOutputContext();
                if (!outputContext.inArray()) {
                    if (!outputContext.inObject()) {
                        break;
                    } else {
                        writeEndObject();
                    }
                } else {
                    writeEndArray();
                }
            }
        }
        _flushBuffer();
        this._outputTail = 0;
        if (this._outputStream != null) {
            if (this._ioContext.isResourceManaged() || isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
                this._outputStream.close();
            } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
                this._outputStream.flush();
            }
        }
        _releaseBuffers();
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator, java.io.Flushable
    public void flush() throws IOException {
        _flushBuffer();
        if (this._outputStream == null || !isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
            return;
        }
        this._outputStream.flush();
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public int getOutputBuffered() {
        return this._outputTail;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public Object getOutputTarget() {
        return this._outputStream;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeBinary(Base64Variant base64Variant, byte[] bArr, int i7, int i8) throws IOException {
        _verifyValueWrite("write a binary value");
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i9 = this._outputTail;
        this._outputTail = i9 + 1;
        bArr2[i9] = this._quoteChar;
        _writeBinary(base64Variant, bArr, i7, i8 + i7);
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr3 = this._outputBuffer;
        int i10 = this._outputTail;
        this._outputTail = i10 + 1;
        bArr3[i10] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeBoolean(boolean z7) throws IOException {
        _verifyValueWrite("write a boolean value");
        if (this._outputTail + 5 >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = z7 ? TRUE_BYTES : FALSE_BYTES;
        int length = bArr.length;
        System.arraycopy(bArr, 0, this._outputBuffer, this._outputTail, length);
        this._outputTail += length;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public final void writeEndArray() throws IOException {
        if (!this._writeContext.inArray()) {
            _reportError("Current context not Array but " + this._writeContext.typeDesc());
        }
        PrettyPrinter prettyPrinter = this._cfgPrettyPrinter;
        if (prettyPrinter != null) {
            prettyPrinter.writeEndArray(this, this._writeContext.getEntryCount());
        } else {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr = this._outputBuffer;
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = BYTE_RBRACKET;
        }
        this._writeContext = this._writeContext.clearAndGetParent();
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public final void writeEndObject() throws IOException {
        if (!this._writeContext.inObject()) {
            _reportError("Current context not Object but " + this._writeContext.typeDesc());
        }
        PrettyPrinter prettyPrinter = this._cfgPrettyPrinter;
        if (prettyPrinter != null) {
            prettyPrinter.writeEndObject(this, this._writeContext.getEntryCount());
        } else {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr = this._outputBuffer;
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = BYTE_RCURLY;
        }
        this._writeContext = this._writeContext.clearAndGetParent();
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeFieldName(String str) throws IOException {
        if (this._cfgPrettyPrinter != null) {
            _writePPFieldName(str);
            return;
        }
        int iWriteFieldName = this._writeContext.writeFieldName(str);
        if (iWriteFieldName == 4) {
            _reportError("Can not write a field name, expecting a value");
        }
        if (iWriteFieldName == 1) {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr = this._outputBuffer;
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = BYTE_COMMA;
        }
        if (this._cfgUnqNames) {
            _writeStringSegments(str, false);
            return;
        }
        int length = str.length();
        if (length > this._charBufferLength) {
            _writeStringSegments(str, true);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i8 = this._outputTail;
        int i9 = i8 + 1;
        this._outputTail = i9;
        bArr2[i8] = this._quoteChar;
        if (length <= this._outputMaxContiguous) {
            if (i9 + length > this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegment(str, 0, length);
        } else {
            _writeStringSegments(str, 0, length);
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr3 = this._outputBuffer;
        int i10 = this._outputTail;
        this._outputTail = i10 + 1;
        bArr3[i10] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNull() throws IOException {
        _verifyValueWrite("write a null");
        _writeNull();
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(short s7) throws IOException {
        _verifyValueWrite("write a number");
        if (this._outputTail + 6 >= this._outputEnd) {
            _flushBuffer();
        }
        if (this._cfgNumbersAsStrings) {
            _writeQuotedShort(s7);
        } else {
            this._outputTail = NumberOutput.outputInt(s7, this._outputBuffer, this._outputTail);
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeRaw(String str) throws IOException {
        int length = str.length();
        char[] cArr = this._charBuffer;
        if (length > cArr.length) {
            writeRaw(str, 0, length);
        } else {
            str.getChars(0, length, cArr, 0);
            writeRaw(cArr, 0, length);
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeRawUTF8String(byte[] bArr, int i7, int i8) throws IOException {
        _verifyValueWrite("write a string");
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i9 = this._outputTail;
        this._outputTail = i9 + 1;
        bArr2[i9] = this._quoteChar;
        _writeBytes(bArr, i7, i8);
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr3 = this._outputBuffer;
        int i10 = this._outputTail;
        this._outputTail = i10 + 1;
        bArr3[i10] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator
    public void writeRawValue(SerializableString serializableString) throws IOException {
        _verifyValueWrite("write a raw (unencoded) value");
        int iAppendUnquotedUTF8 = serializableString.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
        if (iAppendUnquotedUTF8 < 0) {
            _writeBytes(serializableString.asUnquotedUTF8());
        } else {
            this._outputTail += iAppendUnquotedUTF8;
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public final void writeStartArray() throws IOException {
        _verifyValueWrite("start an array");
        this._writeContext = this._writeContext.createChildArrayContext();
        PrettyPrinter prettyPrinter = this._cfgPrettyPrinter;
        if (prettyPrinter != null) {
            prettyPrinter.writeStartArray(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = BYTE_LBRACKET;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public final void writeStartObject() throws IOException {
        _verifyValueWrite("start an object");
        this._writeContext = this._writeContext.createChildObjectContext();
        PrettyPrinter prettyPrinter = this._cfgPrettyPrinter;
        if (prettyPrinter != null) {
            prettyPrinter.writeStartObject(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = BYTE_LCURLY;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeString(String str) throws IOException {
        _verifyValueWrite("write a string");
        if (str == null) {
            _writeNull();
            return;
        }
        int length = str.length();
        if (length > this._outputMaxContiguous) {
            _writeStringSegments(str, true);
            return;
        }
        if (this._outputTail + length >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = this._quoteChar;
        _writeStringSegment(str, 0, length);
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i8 = this._outputTail;
        this._outputTail = i8 + 1;
        bArr2[i8] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeUTF8String(byte[] bArr, int i7, int i8) throws IOException {
        _verifyValueWrite("write a string");
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i9 = this._outputTail;
        this._outputTail = i9 + 1;
        bArr2[i9] = this._quoteChar;
        if (i8 <= this._outputMaxContiguous) {
            _writeUTF8Segment(bArr, i7, i8);
        } else {
            _writeUTF8Segments(bArr, i7, i8);
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr3 = this._outputBuffer;
        int i10 = this._outputTail;
        this._outputTail = i10 + 1;
        bArr3[i10] = this._quoteChar;
    }

    private final void _writeBytes(byte[] bArr, int i7, int i8) throws IOException {
        if (this._outputTail + i8 > this._outputEnd) {
            _flushBuffer();
            if (i8 > MAX_BYTES_TO_BUFFER) {
                this._outputStream.write(bArr, i7, i8);
                return;
            }
        }
        System.arraycopy(bArr, i7, this._outputBuffer, this._outputTail, i8);
        this._outputTail += i8;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(int i7) throws IOException {
        _verifyValueWrite("write a number");
        if (this._outputTail + 11 >= this._outputEnd) {
            _flushBuffer();
        }
        if (this._cfgNumbersAsStrings) {
            _writeQuotedInt(i7);
        } else {
            this._outputTail = NumberOutput.outputInt(i7, this._outputBuffer, this._outputTail);
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeRaw(String str, int i7, int i8) throws IOException {
        char c7;
        char[] cArr = this._charBuffer;
        int length = cArr.length;
        if (i8 <= length) {
            str.getChars(i7, i7 + i8, cArr, 0);
            writeRaw(cArr, 0, i8);
            return;
        }
        int i9 = this._outputEnd;
        int iMin = Math.min(length, (i9 >> 2) + (i9 >> 4));
        int i10 = iMin * 3;
        while (i8 > 0) {
            int iMin2 = Math.min(iMin, i8);
            str.getChars(i7, i7 + iMin2, cArr, 0);
            if (this._outputTail + i10 > this._outputEnd) {
                _flushBuffer();
            }
            if (iMin2 > 1 && (c7 = cArr[iMin2 - 1]) >= 55296 && c7 <= 56319) {
                iMin2--;
            }
            _writeRawSegment(cArr, 0, iMin2);
            i7 += iMin2;
            i8 -= iMin2;
        }
    }

    private void _writeQuotedRaw(char[] cArr, int i7, int i8) throws IOException {
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i9 = this._outputTail;
        this._outputTail = i9 + 1;
        bArr[i9] = this._quoteChar;
        writeRaw(cArr, i7, i8);
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i10 = this._outputTail;
        this._outputTail = i10 + 1;
        bArr2[i10] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeStartArray(int i7) throws IOException {
        _verifyValueWrite("start an array");
        this._writeContext = this._writeContext.createChildArrayContext();
        PrettyPrinter prettyPrinter = this._cfgPrettyPrinter;
        if (prettyPrinter != null) {
            prettyPrinter.writeStartArray(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i8 = this._outputTail;
        this._outputTail = i8 + 1;
        bArr[i8] = BYTE_LBRACKET;
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator
    public void writeStartObject(Object obj) throws IOException {
        _verifyValueWrite("start an object");
        this._writeContext = this._writeContext.createChildObjectContext(obj);
        PrettyPrinter prettyPrinter = this._cfgPrettyPrinter;
        if (prettyPrinter != null) {
            prettyPrinter.writeStartObject(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        this._outputTail = i7 + 1;
        bArr[i7] = BYTE_LCURLY;
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator
    public int writeBinary(Base64Variant base64Variant, InputStream inputStream, int i7) throws IOException {
        _verifyValueWrite("write a binary value");
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i8 = this._outputTail;
        this._outputTail = i8 + 1;
        bArr[i8] = this._quoteChar;
        byte[] bArrAllocBase64Buffer = this._ioContext.allocBase64Buffer();
        try {
            if (i7 < 0) {
                i7 = _writeBinary(base64Variant, inputStream, bArrAllocBase64Buffer);
            } else {
                int i_writeBinary = _writeBinary(base64Variant, inputStream, bArrAllocBase64Buffer, i7);
                if (i_writeBinary > 0) {
                    _reportError("Too few bytes available: missing " + i_writeBinary + " bytes (out of " + i7 + ")");
                }
            }
            this._ioContext.releaseBase64Buffer(bArrAllocBase64Buffer);
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr2 = this._outputBuffer;
            int i9 = this._outputTail;
            this._outputTail = i9 + 1;
            bArr2[i9] = this._quoteChar;
            return i7;
        } catch (Throwable th) {
            this._ioContext.releaseBase64Buffer(bArrAllocBase64Buffer);
            throw th;
        }
    }

    private final void _writeStringSegments(char[] cArr, int i7, int i8) throws IOException {
        do {
            int iMin = Math.min(this._outputMaxContiguous, i8);
            if (this._outputTail + iMin > this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegment(cArr, i7, iMin);
            i7 += iMin;
            i8 -= iMin;
        } while (i8 > 0);
    }

    public UTF8JsonGenerator(IOContext iOContext, int i7, ObjectCodec objectCodec, OutputStream outputStream, char c7, byte[] bArr, int i8, boolean z7) {
        super(iOContext, i7, objectCodec);
        this._outputStream = outputStream;
        this._quoteChar = (byte) c7;
        if (c7 != '\"') {
            this._outputEscapes = CharTypes.get7BitOutputEscapes(c7);
        }
        this._bufferRecyclable = z7;
        this._outputTail = i8;
        this._outputBuffer = bArr;
        int length = bArr.length;
        this._outputEnd = length;
        this._outputMaxContiguous = length >> 3;
        char[] cArrAllocConcatBuffer = iOContext.allocConcatBuffer();
        this._charBuffer = cArrAllocConcatBuffer;
        this._charBufferLength = cArrAllocConcatBuffer.length;
    }

    private final void _writeStringSegment(String str, int i7, int i8) throws IOException {
        int i9 = i8 + i7;
        int i10 = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        while (i7 < i9) {
            char cCharAt = str.charAt(i7);
            if (cCharAt > 127 || iArr[cCharAt] != 0) {
                break;
            }
            bArr[i10] = (byte) cCharAt;
            i7++;
            i10++;
        }
        this._outputTail = i10;
        if (i7 < i9) {
            if (this._characterEscapes != null) {
                _writeCustomStringSegment2(str, i7, i9);
            } else if (this._maximumNonEscapedChar == 0) {
                _writeStringSegment2(str, i7, i9);
            } else {
                _writeStringSegmentASCII2(str, i7, i9);
            }
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(long j7) throws IOException {
        _verifyValueWrite("write a number");
        if (this._cfgNumbersAsStrings) {
            _writeQuotedLong(j7);
            return;
        }
        if (this._outputTail + 21 >= this._outputEnd) {
            _flushBuffer();
        }
        this._outputTail = NumberOutput.outputLong(j7, this._outputBuffer, this._outputTail);
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeString(Reader reader, int i7) throws IOException {
        _verifyValueWrite("write a string");
        if (reader == null) {
            _reportError("null reader");
        }
        int i8 = i7 >= 0 ? i7 : Integer.MAX_VALUE;
        char[] cArr = this._charBuffer;
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i9 = this._outputTail;
        this._outputTail = i9 + 1;
        bArr[i9] = this._quoteChar;
        while (i8 > 0) {
            int i10 = reader.read(cArr, 0, Math.min(i8, cArr.length));
            if (i10 <= 0) {
                break;
            }
            if (this._outputTail + i7 >= this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegments(cArr, 0, i10);
            i8 -= i10;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i11 = this._outputTail;
        this._outputTail = i11 + 1;
        bArr2[i11] = this._quoteChar;
        if (i8 <= 0 || i7 < 0) {
            return;
        }
        _reportError("Didn't read enough from reader");
    }

    private final void _writeStringSegment2(String str, int i7, int i8) throws IOException {
        if (this._outputTail + ((i8 - i7) * 6) > this._outputEnd) {
            _flushBuffer();
        }
        int i_outputMultiByteChar = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        while (i7 < i8) {
            int i9 = i7 + 1;
            char cCharAt = str.charAt(i7);
            if (cCharAt <= 127) {
                int i10 = iArr[cCharAt];
                if (i10 == 0) {
                    bArr[i_outputMultiByteChar] = (byte) cCharAt;
                    i7 = i9;
                    i_outputMultiByteChar++;
                } else if (i10 > 0) {
                    int i11 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = BYTE_BACKSLASH;
                    i_outputMultiByteChar += 2;
                    bArr[i11] = (byte) i10;
                } else {
                    i_outputMultiByteChar = _writeGenericEscape(cCharAt, i_outputMultiByteChar);
                }
            } else if (cCharAt <= 2047) {
                int i12 = i_outputMultiByteChar + 1;
                bArr[i_outputMultiByteChar] = (byte) ((cCharAt >> 6) | 192);
                i_outputMultiByteChar += 2;
                bArr[i12] = (byte) ((cCharAt & '?') | 128);
            } else {
                i_outputMultiByteChar = _outputMultiByteChar(cCharAt, i_outputMultiByteChar);
            }
            i7 = i9;
        }
        this._outputTail = i_outputMultiByteChar;
    }

    private final void _writeStringSegments(String str, int i7, int i8) throws IOException {
        do {
            int iMin = Math.min(this._outputMaxContiguous, i8);
            if (this._outputTail + iMin > this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegment(str, i7, iMin);
            i7 += iMin;
            i8 -= iMin;
        } while (i8 > 0);
    }

    public final int _writeBinary(Base64Variant base64Variant, InputStream inputStream, byte[] bArr, int i7) throws IOException {
        int i_readMore;
        int i8 = this._outputEnd - 6;
        int i9 = 2;
        int maxLineLength = base64Variant.getMaxLineLength() >> 2;
        int i10 = -3;
        int i11 = i7;
        int i12 = 0;
        int i_readMore2 = 0;
        while (true) {
            if (i11 <= 2) {
                break;
            }
            if (i12 > i10) {
                i_readMore2 = _readMore(inputStream, bArr, i12, i_readMore2, i11);
                if (i_readMore2 < 3) {
                    i12 = 0;
                    break;
                }
                i10 = i_readMore2 - 3;
                i12 = 0;
            }
            if (this._outputTail > i8) {
                _flushBuffer();
            }
            int i13 = i12 + 2;
            int i14 = ((bArr[i12 + 1] & 255) | (bArr[i12] << 8)) << 8;
            i12 += 3;
            i11 -= 3;
            int iEncodeBase64Chunk = base64Variant.encodeBase64Chunk(i14 | (bArr[i13] & 255), this._outputBuffer, this._outputTail);
            this._outputTail = iEncodeBase64Chunk;
            maxLineLength--;
            if (maxLineLength <= 0) {
                byte[] bArr2 = this._outputBuffer;
                int i15 = iEncodeBase64Chunk + 1;
                this._outputTail = i15;
                bArr2[iEncodeBase64Chunk] = BYTE_BACKSLASH;
                this._outputTail = iEncodeBase64Chunk + 2;
                bArr2[i15] = 110;
                maxLineLength = base64Variant.getMaxLineLength() >> 2;
            }
        }
        if (i11 <= 0 || (i_readMore = _readMore(inputStream, bArr, i12, i_readMore2, i11)) <= 0) {
            return i11;
        }
        if (this._outputTail > i8) {
            _flushBuffer();
        }
        int i16 = bArr[0] << 16;
        if (1 < i_readMore) {
            i16 |= (bArr[1] & 255) << 8;
        } else {
            i9 = 1;
        }
        this._outputTail = base64Variant.encodeBase64Partial(i16, i9, this._outputBuffer, this._outputTail);
        return i11 - i9;
    }

    private final void _writeStringSegmentASCII2(String str, int i7, int i8) throws IOException {
        if (this._outputTail + ((i8 - i7) * 6) > this._outputEnd) {
            _flushBuffer();
        }
        int i_outputMultiByteChar = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        int i9 = this._maximumNonEscapedChar;
        while (i7 < i8) {
            int i10 = i7 + 1;
            char cCharAt = str.charAt(i7);
            if (cCharAt <= 127) {
                int i11 = iArr[cCharAt];
                if (i11 == 0) {
                    bArr[i_outputMultiByteChar] = (byte) cCharAt;
                    i7 = i10;
                    i_outputMultiByteChar++;
                } else if (i11 > 0) {
                    int i12 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = BYTE_BACKSLASH;
                    i_outputMultiByteChar += 2;
                    bArr[i12] = (byte) i11;
                } else {
                    i_outputMultiByteChar = _writeGenericEscape(cCharAt, i_outputMultiByteChar);
                }
            } else if (cCharAt > i9) {
                i_outputMultiByteChar = _writeGenericEscape(cCharAt, i_outputMultiByteChar);
            } else if (cCharAt <= 2047) {
                int i13 = i_outputMultiByteChar + 1;
                bArr[i_outputMultiByteChar] = (byte) ((cCharAt >> 6) | 192);
                i_outputMultiByteChar += 2;
                bArr[i13] = (byte) ((cCharAt & '?') | 128);
            } else {
                i_outputMultiByteChar = _outputMultiByteChar(cCharAt, i_outputMultiByteChar);
            }
            i7 = i10;
        }
        this._outputTail = i_outputMultiByteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeRaw(SerializableString serializableString) throws IOException {
        int iAppendUnquotedUTF8 = serializableString.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
        if (iAppendUnquotedUTF8 < 0) {
            _writeBytes(serializableString.asUnquotedUTF8());
        } else {
            this._outputTail += iAppendUnquotedUTF8;
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(BigInteger bigInteger) throws IOException {
        _verifyValueWrite("write a number");
        if (bigInteger == null) {
            _writeNull();
        } else if (this._cfgNumbersAsStrings) {
            _writeQuotedRaw(bigInteger.toString());
        } else {
            writeRaw(bigInteger.toString());
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public final void writeRaw(char[] cArr, int i7, int i8) throws IOException {
        int i9 = i8 + i8 + i8;
        int i10 = this._outputTail + i9;
        int i11 = this._outputEnd;
        if (i10 > i11) {
            if (i11 < i9) {
                _writeSegmentedRaw(cArr, i7, i8);
                return;
            }
            _flushBuffer();
        }
        int i12 = i8 + i7;
        while (i7 < i12) {
            do {
                char c7 = cArr[i7];
                if (c7 > 127) {
                    i7++;
                    if (c7 < 2048) {
                        byte[] bArr = this._outputBuffer;
                        int i13 = this._outputTail;
                        int i14 = i13 + 1;
                        this._outputTail = i14;
                        bArr[i13] = (byte) ((c7 >> 6) | 192);
                        this._outputTail = i13 + 2;
                        bArr[i14] = (byte) ((c7 & '?') | 128);
                    } else {
                        i7 = _outputRawMultiByteChar(c7, cArr, i7, i12);
                    }
                } else {
                    byte[] bArr2 = this._outputBuffer;
                    int i15 = this._outputTail;
                    this._outputTail = i15 + 1;
                    bArr2[i15] = (byte) c7;
                    i7++;
                }
            } while (i7 < i12);
            return;
        }
    }

    public final void _writePPFieldName(SerializableString serializableString) throws IOException {
        int iWriteFieldName = this._writeContext.writeFieldName(serializableString.getValue());
        if (iWriteFieldName == 4) {
            _reportError("Can not write a field name, expecting a value");
        }
        if (iWriteFieldName == 1) {
            this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
        } else {
            this._cfgPrettyPrinter.beforeObjectEntries(this);
        }
        boolean z7 = this._cfgUnqNames;
        if (!z7) {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr = this._outputBuffer;
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = this._quoteChar;
        }
        int iAppendQuotedUTF8 = serializableString.appendQuotedUTF8(this._outputBuffer, this._outputTail);
        if (iAppendQuotedUTF8 < 0) {
            _writeBytes(serializableString.asQuotedUTF8());
        } else {
            this._outputTail += iAppendQuotedUTF8;
        }
        if (z7) {
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i8 = this._outputTail;
        this._outputTail = i8 + 1;
        bArr2[i8] = this._quoteChar;
    }

    @Deprecated
    public UTF8JsonGenerator(IOContext iOContext, int i7, ObjectCodec objectCodec, OutputStream outputStream) {
        this(iOContext, i7, objectCodec, outputStream, JsonFactory.DEFAULT_QUOTE_CHAR);
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator
    public void writeFieldName(SerializableString serializableString) throws IOException {
        if (this._cfgPrettyPrinter != null) {
            _writePPFieldName(serializableString);
            return;
        }
        int iWriteFieldName = this._writeContext.writeFieldName(serializableString.getValue());
        if (iWriteFieldName == 4) {
            _reportError("Can not write a field name, expecting a value");
        }
        if (iWriteFieldName == 1) {
            if (this._outputTail >= this._outputEnd) {
                _flushBuffer();
            }
            byte[] bArr = this._outputBuffer;
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = BYTE_COMMA;
        }
        if (this._cfgUnqNames) {
            _writeUnq(serializableString);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i8 = this._outputTail;
        int i9 = i8 + 1;
        this._outputTail = i9;
        bArr2[i8] = this._quoteChar;
        int iAppendQuotedUTF8 = serializableString.appendQuotedUTF8(bArr2, i9);
        if (iAppendQuotedUTF8 < 0) {
            _writeBytes(serializableString.asQuotedUTF8());
        } else {
            this._outputTail += iAppendQuotedUTF8;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr3 = this._outputBuffer;
        int i10 = this._outputTail;
        this._outputTail = i10 + 1;
        bArr3[i10] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(double d7) throws IOException {
        if (!this._cfgNumbersAsStrings && (!NumberOutput.notFinite(d7) || !JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS.enabledIn(this._features))) {
            _verifyValueWrite("write a number");
            writeRaw(String.valueOf(d7));
        } else {
            writeString(String.valueOf(d7));
        }
    }

    @Deprecated
    public UTF8JsonGenerator(IOContext iOContext, int i7, ObjectCodec objectCodec, OutputStream outputStream, byte[] bArr, int i8, boolean z7) {
        this(iOContext, i7, objectCodec, outputStream, JsonFactory.DEFAULT_QUOTE_CHAR, bArr, i8, z7);
    }

    private final void _writeCustomStringSegment2(String str, int i7, int i8) throws IOException {
        if (this._outputTail + ((i8 - i7) * 6) > this._outputEnd) {
            _flushBuffer();
        }
        int i_outputMultiByteChar = this._outputTail;
        byte[] bArr = this._outputBuffer;
        int[] iArr = this._outputEscapes;
        int i9 = this._maximumNonEscapedChar;
        if (i9 <= 0) {
            i9 = 65535;
        }
        CharacterEscapes characterEscapes = this._characterEscapes;
        while (i7 < i8) {
            int i10 = i7 + 1;
            char cCharAt = str.charAt(i7);
            if (cCharAt <= 127) {
                int i11 = iArr[cCharAt];
                if (i11 == 0) {
                    bArr[i_outputMultiByteChar] = (byte) cCharAt;
                    i7 = i10;
                    i_outputMultiByteChar++;
                } else if (i11 > 0) {
                    int i12 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = BYTE_BACKSLASH;
                    i_outputMultiByteChar += 2;
                    bArr[i12] = (byte) i11;
                } else if (i11 == -2) {
                    SerializableString escapeSequence = characterEscapes.getEscapeSequence(cCharAt);
                    if (escapeSequence == null) {
                        _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + Integer.toHexString(cCharAt) + ", although was supposed to have one");
                    }
                    i_outputMultiByteChar = _writeCustomEscape(bArr, i_outputMultiByteChar, escapeSequence, i8 - i10);
                } else {
                    i_outputMultiByteChar = _writeGenericEscape(cCharAt, i_outputMultiByteChar);
                }
            } else if (cCharAt > i9) {
                i_outputMultiByteChar = _writeGenericEscape(cCharAt, i_outputMultiByteChar);
            } else {
                SerializableString escapeSequence2 = characterEscapes.getEscapeSequence(cCharAt);
                if (escapeSequence2 != null) {
                    i_outputMultiByteChar = _writeCustomEscape(bArr, i_outputMultiByteChar, escapeSequence2, i8 - i10);
                } else if (cCharAt <= 2047) {
                    int i13 = i_outputMultiByteChar + 1;
                    bArr[i_outputMultiByteChar] = (byte) ((cCharAt >> 6) | 192);
                    i_outputMultiByteChar += 2;
                    bArr[i13] = (byte) ((cCharAt & '?') | 128);
                } else {
                    i_outputMultiByteChar = _outputMultiByteChar(cCharAt, i_outputMultiByteChar);
                }
            }
            i7 = i10;
        }
        this._outputTail = i_outputMultiByteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeString(char[] cArr, int i7, int i8) throws IOException {
        _verifyValueWrite("write a string");
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i9 = this._outputTail;
        int i10 = i9 + 1;
        this._outputTail = i10;
        bArr[i9] = this._quoteChar;
        if (i8 <= this._outputMaxContiguous) {
            if (i10 + i8 > this._outputEnd) {
                _flushBuffer();
            }
            _writeStringSegment(cArr, i7, i8);
        } else {
            _writeStringSegments(cArr, i7, i8);
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i11 = this._outputTail;
        this._outputTail = i11 + 1;
        bArr2[i11] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeRaw(char c7) throws IOException {
        if (this._outputTail + 3 >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        if (c7 <= 127) {
            int i7 = this._outputTail;
            this._outputTail = i7 + 1;
            bArr[i7] = (byte) c7;
        } else {
            if (c7 < 2048) {
                int i8 = this._outputTail;
                int i9 = i8 + 1;
                this._outputTail = i9;
                bArr[i8] = (byte) ((c7 >> 6) | 192);
                this._outputTail = i8 + 2;
                bArr[i9] = (byte) ((c7 & '?') | 128);
                return;
            }
            _outputRawMultiByteChar(c7, null, 0, 0);
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(float f7) throws IOException {
        if (!this._cfgNumbersAsStrings && (!NumberOutput.notFinite(f7) || !JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS.enabledIn(this._features))) {
            _verifyValueWrite("write a number");
            writeRaw(String.valueOf(f7));
        } else {
            writeString(String.valueOf(f7));
        }
    }

    public final int _writeBinary(Base64Variant base64Variant, InputStream inputStream, byte[] bArr) throws IOException {
        byte[] bArr2 = bArr;
        int i7 = this._outputEnd - 6;
        int i8 = 2;
        int i9 = -3;
        int maxLineLength = base64Variant.getMaxLineLength() >> 2;
        int i10 = 0;
        int i_readMore = 0;
        int i11 = 0;
        while (true) {
            if (i10 > i9) {
                i_readMore = _readMore(inputStream, bArr2, i10, i_readMore, bArr2.length);
                if (i_readMore < 3) {
                    break;
                }
                i9 = i_readMore - 3;
                i10 = 0;
            }
            if (this._outputTail > i7) {
                _flushBuffer();
            }
            int i12 = i10 + 2;
            int i13 = ((bArr[i10 + 1] & 255) | (bArr[i10] << 8)) << 8;
            i10 += 3;
            i11 += 3;
            int iEncodeBase64Chunk = base64Variant.encodeBase64Chunk(i13 | (bArr[i12] & 255), this._outputBuffer, this._outputTail);
            this._outputTail = iEncodeBase64Chunk;
            maxLineLength--;
            if (maxLineLength <= 0) {
                byte[] bArr3 = this._outputBuffer;
                int i14 = iEncodeBase64Chunk + 1;
                this._outputTail = i14;
                bArr3[iEncodeBase64Chunk] = BYTE_BACKSLASH;
                this._outputTail = iEncodeBase64Chunk + 2;
                bArr3[i14] = 110;
                maxLineLength = base64Variant.getMaxLineLength() >> 2;
            }
            bArr2 = bArr;
        }
        if (i_readMore <= 0) {
            return i11;
        }
        if (this._outputTail > i7) {
            _flushBuffer();
        }
        int i15 = bArr[0] << 16;
        if (1 < i_readMore) {
            i15 |= (bArr[1] & 255) << 8;
        } else {
            i8 = 1;
        }
        int i16 = i11 + i8;
        this._outputTail = base64Variant.encodeBase64Partial(i15, i8, this._outputBuffer, this._outputTail);
        return i16;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(BigDecimal bigDecimal) throws IOException {
        _verifyValueWrite("write a number");
        if (bigDecimal == null) {
            _writeNull();
        } else if (this._cfgNumbersAsStrings) {
            _writeQuotedRaw(_asString(bigDecimal));
        } else {
            writeRaw(_asString(bigDecimal));
        }
    }

    @Override // com.fasterxml.jackson.core.base.GeneratorBase, com.fasterxml.jackson.core.JsonGenerator
    public final void writeString(SerializableString serializableString) throws IOException {
        _verifyValueWrite("write a string");
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr = this._outputBuffer;
        int i7 = this._outputTail;
        int i8 = i7 + 1;
        this._outputTail = i8;
        bArr[i7] = this._quoteChar;
        int iAppendQuotedUTF8 = serializableString.appendQuotedUTF8(bArr, i8);
        if (iAppendQuotedUTF8 < 0) {
            _writeBytes(serializableString.asQuotedUTF8());
        } else {
            this._outputTail += iAppendQuotedUTF8;
        }
        if (this._outputTail >= this._outputEnd) {
            _flushBuffer();
        }
        byte[] bArr2 = this._outputBuffer;
        int i9 = this._outputTail;
        this._outputTail = i9 + 1;
        bArr2[i9] = this._quoteChar;
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(String str) throws IOException {
        _verifyValueWrite("write a number");
        if (this._cfgNumbersAsStrings) {
            _writeQuotedRaw(str);
        } else {
            writeRaw(str);
        }
    }

    @Override // com.fasterxml.jackson.core.JsonGenerator
    public void writeNumber(char[] cArr, int i7, int i8) throws IOException {
        _verifyValueWrite("write a number");
        if (this._cfgNumbersAsStrings) {
            _writeQuotedRaw(cArr, i7, i8);
        } else {
            writeRaw(cArr, i7, i8);
        }
    }
}
