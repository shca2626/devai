package com.fasterxml.jackson.core.sym;

import R0.AbstractC0571i;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.util.InternCache;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class ByteQuadsCanonicalizer {
    private static final int DEFAULT_T_SIZE = 64;
    static final int MAX_ENTRIES_FOR_REUSE = 6000;
    private static final int MAX_T_SIZE = 65536;
    private static final int MIN_HASH_SIZE = 16;
    private static final int MULT = 33;
    private static final int MULT2 = 65599;
    private static final int MULT3 = 31;
    private int _count;
    private final boolean _failOnDoS;
    private int[] _hashArea;
    private boolean _hashShared;
    private int _hashSize;
    private boolean _intern;
    private int _longNameOffset;
    private String[] _names;
    private final ByteQuadsCanonicalizer _parent;
    private int _secondaryStart;
    private final int _seed;
    private int _spilloverEnd;
    private final AtomicReference<TableInfo> _tableInfo;
    private int _tertiaryShift;
    private int _tertiaryStart;

    private ByteQuadsCanonicalizer(int i7, boolean z7, int i8, boolean z8) {
        this._parent = null;
        this._seed = i8;
        this._intern = z7;
        this._failOnDoS = z8;
        int i9 = 16;
        if (i7 < 16) {
            i7 = i9;
        } else if (((i7 - 1) & i7) != 0) {
            while (i9 < i7) {
                i9 += i9;
            }
            i7 = i9;
        }
        this._tableInfo = new AtomicReference<>(TableInfo.createInitial(i7));
    }

    private int _appendLongName(int[] iArr, int i7) {
        int i8 = this._longNameOffset;
        int i9 = i8 + i7;
        int[] iArr2 = this._hashArea;
        if (i9 > iArr2.length) {
            this._hashArea = Arrays.copyOf(this._hashArea, this._hashArea.length + Math.max(i9 - iArr2.length, Math.min(4096, this._hashSize)));
        }
        System.arraycopy(iArr, 0, this._hashArea, i8, i7);
        this._longNameOffset += i7;
        return i8;
    }

    private final int _calcOffset(int i7) {
        return (i7 & (this._hashSize - 1)) << 2;
    }

    public static int _calcTertiaryShift(int i7) {
        int i8 = i7 >> 2;
        if (i8 < 64) {
            return 4;
        }
        if (i8 <= 256) {
            return 5;
        }
        return i8 <= 1024 ? 6 : 7;
    }

    private boolean _checkNeedForRehash() {
        if (this._count <= (this._hashSize >> 1)) {
            return false;
        }
        int i_spilloverStart = (this._spilloverEnd - _spilloverStart()) >> 2;
        int i7 = this._count;
        return i_spilloverStart > ((i7 + 1) >> 7) || ((double) i7) > ((double) this._hashSize) * 0.8d;
    }

    private int _findOffsetForAdd(int i7) {
        int i_calcOffset = _calcOffset(i7);
        int[] iArr = this._hashArea;
        if (iArr[i_calcOffset + 3] == 0) {
            return i_calcOffset;
        }
        if (_checkNeedForRehash()) {
            return _resizeAndFindOffsetForAdd(i7);
        }
        int i8 = this._secondaryStart + ((i_calcOffset >> 3) << 2);
        if (iArr[i8 + 3] == 0) {
            return i8;
        }
        int i9 = this._tertiaryStart;
        int i10 = this._tertiaryShift;
        int i11 = i9 + ((i_calcOffset >> (i10 + 2)) << i10);
        int i12 = (1 << i10) + i11;
        while (i11 < i12) {
            if (iArr[i11 + 3] == 0) {
                return i11;
            }
            i11 += 4;
        }
        int i13 = this._spilloverEnd;
        int i14 = i13 + 4;
        this._spilloverEnd = i14;
        if (i14 < (this._hashSize << 3)) {
            return i13;
        }
        if (this._failOnDoS) {
            _reportTooManyCollisions();
        }
        return _resizeAndFindOffsetForAdd(i7);
    }

    private String _findSecondary(int i7, int i8) {
        int i9 = this._tertiaryStart;
        int i10 = this._tertiaryShift;
        int i11 = i9 + ((i7 >> (i10 + 2)) << i10);
        int[] iArr = this._hashArea;
        int i12 = (1 << i10) + i11;
        while (i11 < i12) {
            int i13 = iArr[i11 + 3];
            if (i8 == iArr[i11] && 1 == i13) {
                return this._names[i11 >> 2];
            }
            if (i13 == 0) {
                return null;
            }
            i11 += 4;
        }
        for (int i_spilloverStart = _spilloverStart(); i_spilloverStart < this._spilloverEnd; i_spilloverStart += 4) {
            if (i8 == iArr[i_spilloverStart] && 1 == iArr[i_spilloverStart + 3]) {
                return this._names[i_spilloverStart >> 2];
            }
        }
        return null;
    }

    private int _resizeAndFindOffsetForAdd(int i7) {
        rehash();
        int i_calcOffset = _calcOffset(i7);
        int[] iArr = this._hashArea;
        if (iArr[i_calcOffset + 3] == 0) {
            return i_calcOffset;
        }
        int i8 = this._secondaryStart + ((i_calcOffset >> 3) << 2);
        if (iArr[i8 + 3] == 0) {
            return i8;
        }
        int i9 = this._tertiaryStart;
        int i10 = this._tertiaryShift;
        int i11 = i9 + ((i_calcOffset >> (i10 + 2)) << i10);
        int i12 = (1 << i10) + i11;
        while (i11 < i12) {
            if (iArr[i11 + 3] == 0) {
                return i11;
            }
            i11 += 4;
        }
        int i13 = this._spilloverEnd;
        this._spilloverEnd = i13 + 4;
        return i13;
    }

    private final int _spilloverStart() {
        int i7 = this._hashSize;
        return (i7 << 3) - i7;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0023 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0031 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x003f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0040  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004d A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x004e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean _verifyLongName(int[] r8, int r9, int r10) {
        /*
            r7 = this;
            int[] r0 = r7._hashArea
            r1 = 1
            r2 = 0
            switch(r9) {
                case 4: goto L42;
                case 5: goto L34;
                case 6: goto L26;
                case 7: goto L18;
                case 8: goto Lc;
                default: goto L7;
            }
        L7:
            boolean r8 = r7._verifyLongName2(r8, r9, r10)
            return r8
        Lc:
            r9 = r8[r2]
            int r3 = r10 + 1
            r10 = r0[r10]
            if (r9 == r10) goto L15
            return r2
        L15:
            r9 = r1
            r10 = r3
            goto L19
        L18:
            r9 = r2
        L19:
            int r3 = r9 + 1
            r9 = r8[r9]
            int r4 = r10 + 1
            r10 = r0[r10]
            if (r9 == r10) goto L24
            return r2
        L24:
            r10 = r4
            goto L27
        L26:
            r3 = r2
        L27:
            int r9 = r3 + 1
            r3 = r8[r3]
            int r4 = r10 + 1
            r10 = r0[r10]
            if (r3 == r10) goto L32
            return r2
        L32:
            r10 = r4
            goto L35
        L34:
            r9 = r2
        L35:
            int r3 = r9 + 1
            r9 = r8[r9]
            int r4 = r10 + 1
            r10 = r0[r10]
            if (r9 == r10) goto L40
            return r2
        L40:
            r10 = r4
            goto L43
        L42:
            r3 = r2
        L43:
            int r9 = r3 + 1
            r4 = r8[r3]
            int r5 = r10 + 1
            r6 = r0[r10]
            if (r4 == r6) goto L4e
            return r2
        L4e:
            int r4 = r3 + 2
            r9 = r8[r9]
            int r6 = r10 + 2
            r5 = r0[r5]
            if (r9 == r5) goto L59
            return r2
        L59:
            int r3 = r3 + 3
            r9 = r8[r4]
            int r10 = r10 + 3
            r4 = r0[r6]
            if (r9 == r4) goto L64
            return r2
        L64:
            r8 = r8[r3]
            r9 = r0[r10]
            if (r8 == r9) goto L6b
            return r2
        L6b:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer._verifyLongName(int[], int, int):boolean");
    }

    private boolean _verifyLongName2(int[] iArr, int i7, int i8) {
        int i9 = 0;
        while (true) {
            int i10 = i9 + 1;
            int i11 = i8 + 1;
            if (iArr[i9] != this._hashArea[i8]) {
                return false;
            }
            if (i10 >= i7) {
                return true;
            }
            i9 = i10;
            i8 = i11;
        }
    }

    private void _verifySharing() {
        if (this._hashShared) {
            int[] iArr = this._hashArea;
            this._hashArea = Arrays.copyOf(iArr, iArr.length);
            String[] strArr = this._names;
            this._names = (String[]) Arrays.copyOf(strArr, strArr.length);
            this._hashShared = false;
        }
    }

    public static ByteQuadsCanonicalizer createRoot() {
        long jCurrentTimeMillis = System.currentTimeMillis();
        return createRoot((((int) jCurrentTimeMillis) + ((int) (jCurrentTimeMillis >>> 32))) | 1);
    }

    private void mergeChild(TableInfo tableInfo) {
        int i7 = tableInfo.count;
        TableInfo tableInfo2 = this._tableInfo.get();
        if (i7 == tableInfo2.count) {
            return;
        }
        if (i7 > MAX_ENTRIES_FOR_REUSE) {
            tableInfo = TableInfo.createInitial(64);
        }
        AbstractC0571i.a(this._tableInfo, tableInfo2, tableInfo);
    }

    private void nukeSymbols(boolean z7) {
        this._count = 0;
        this._spilloverEnd = _spilloverStart();
        this._longNameOffset = this._hashSize << 3;
        if (z7) {
            Arrays.fill(this._hashArea, 0);
            Arrays.fill(this._names, (Object) null);
        }
    }

    private void rehash() {
        this._hashShared = false;
        int[] iArr = this._hashArea;
        String[] strArr = this._names;
        int i7 = this._hashSize;
        int i8 = this._count;
        int i9 = i7 + i7;
        int i10 = this._spilloverEnd;
        if (i9 > MAX_T_SIZE) {
            nukeSymbols(true);
            return;
        }
        this._hashArea = new int[iArr.length + (i7 << 3)];
        this._hashSize = i9;
        int i11 = i9 << 2;
        this._secondaryStart = i11;
        this._tertiaryStart = i11 + (i11 >> 1);
        this._tertiaryShift = _calcTertiaryShift(i9);
        this._names = new String[strArr.length << 1];
        nukeSymbols(false);
        int[] iArr2 = new int[16];
        int i12 = 0;
        for (int i13 = 0; i13 < i10; i13 += 4) {
            int i14 = iArr[i13 + 3];
            if (i14 != 0) {
                i12++;
                String str = strArr[i13 >> 2];
                if (i14 == 1) {
                    iArr2[0] = iArr[i13];
                    addName(str, iArr2, 1);
                } else if (i14 == 2) {
                    iArr2[0] = iArr[i13];
                    iArr2[1] = iArr[i13 + 1];
                    addName(str, iArr2, 2);
                } else if (i14 != 3) {
                    if (i14 > iArr2.length) {
                        iArr2 = new int[i14];
                    }
                    System.arraycopy(iArr, iArr[i13 + 1], iArr2, 0, i14);
                    addName(str, iArr2, i14);
                } else {
                    iArr2[0] = iArr[i13];
                    iArr2[1] = iArr[i13 + 1];
                    iArr2[2] = iArr[i13 + 2];
                    addName(str, iArr2, 3);
                }
            }
        }
        if (i12 == i8) {
            return;
        }
        throw new IllegalStateException("Failed rehash(): old count=" + i8 + ", copyCount=" + i12);
    }

    public void _reportTooManyCollisions() {
        if (this._hashSize <= 1024) {
            return;
        }
        throw new IllegalStateException("Spill-over slots in symbol table with " + this._count + " entries, hash area of " + this._hashSize + " slots is now full (all " + (this._hashSize >> 3) + " slots -- suspect a DoS attack based on hash collisions. You can disable the check via `JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW`");
    }

    public String addName(String str, int i7) {
        _verifySharing();
        if (this._intern) {
            str = InternCache.instance.intern(str);
        }
        int i_findOffsetForAdd = _findOffsetForAdd(calcHash(i7));
        int[] iArr = this._hashArea;
        iArr[i_findOffsetForAdd] = i7;
        iArr[i_findOffsetForAdd + 3] = 1;
        this._names[i_findOffsetForAdd >> 2] = str;
        this._count++;
        return str;
    }

    public int bucketCount() {
        return this._hashSize;
    }

    public int calcHash(int i7) {
        int i8 = i7 ^ this._seed;
        int i9 = i8 + (i8 >>> 16);
        int i10 = i9 ^ (i9 << 3);
        return i10 + (i10 >>> 12);
    }

    public String findName(int i7) {
        int i_calcOffset = _calcOffset(calcHash(i7));
        int[] iArr = this._hashArea;
        int i8 = iArr[i_calcOffset + 3];
        if (i8 == 1) {
            if (iArr[i_calcOffset] == i7) {
                return this._names[i_calcOffset >> 2];
            }
        } else if (i8 == 0) {
            return null;
        }
        int i9 = this._secondaryStart + ((i_calcOffset >> 3) << 2);
        int i10 = iArr[i9 + 3];
        if (i10 == 1) {
            if (iArr[i9] == i7) {
                return this._names[i9 >> 2];
            }
        } else if (i10 == 0) {
            return null;
        }
        return _findSecondary(i_calcOffset, i7);
    }

    public int hashSeed() {
        return this._seed;
    }

    public ByteQuadsCanonicalizer makeChild(int i7) {
        return new ByteQuadsCanonicalizer(this, JsonFactory.Feature.INTERN_FIELD_NAMES.enabledIn(i7), this._seed, JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW.enabledIn(i7), this._tableInfo.get());
    }

    public boolean maybeDirty() {
        return !this._hashShared;
    }

    public int primaryCount() {
        int i7 = this._secondaryStart;
        int i8 = 0;
        for (int i9 = 3; i9 < i7; i9 += 4) {
            if (this._hashArea[i9] != 0) {
                i8++;
            }
        }
        return i8;
    }

    public void release() {
        if (this._parent == null || !maybeDirty()) {
            return;
        }
        this._parent.mergeChild(new TableInfo(this));
        this._hashShared = true;
    }

    public int secondaryCount() {
        int i7 = this._tertiaryStart;
        int i8 = 0;
        for (int i9 = this._secondaryStart + 3; i9 < i7; i9 += 4) {
            if (this._hashArea[i9] != 0) {
                i8++;
            }
        }
        return i8;
    }

    public int size() {
        AtomicReference<TableInfo> atomicReference = this._tableInfo;
        return atomicReference != null ? atomicReference.get().count : this._count;
    }

    public int spilloverCount() {
        return (this._spilloverEnd - _spilloverStart()) >> 2;
    }

    public int tertiaryCount() {
        int i7 = this._tertiaryStart + 3;
        int i8 = this._hashSize + i7;
        int i9 = 0;
        while (i7 < i8) {
            if (this._hashArea[i7] != 0) {
                i9++;
            }
            i7 += 4;
        }
        return i9;
    }

    public String toString() {
        int iPrimaryCount = primaryCount();
        int iSecondaryCount = secondaryCount();
        int iTertiaryCount = tertiaryCount();
        int iSpilloverCount = spilloverCount();
        return String.format("[%s: size=%d, hashSize=%d, %d/%d/%d/%d pri/sec/ter/spill (=%s), total:%d]", ByteQuadsCanonicalizer.class.getName(), Integer.valueOf(this._count), Integer.valueOf(this._hashSize), Integer.valueOf(iPrimaryCount), Integer.valueOf(iSecondaryCount), Integer.valueOf(iTertiaryCount), Integer.valueOf(iSpilloverCount), Integer.valueOf(iPrimaryCount + iSecondaryCount + iTertiaryCount + iSpilloverCount), Integer.valueOf(totalCount()));
    }

    public int totalCount() {
        int i7 = this._hashSize << 3;
        int i8 = 0;
        for (int i9 = 3; i9 < i7; i9 += 4) {
            if (this._hashArea[i9] != 0) {
                i8++;
            }
        }
        return i8;
    }

    public int calcHash(int i7, int i8) {
        int i9 = i7 + (i7 >>> 15);
        int i10 = ((i9 ^ (i9 >>> 9)) + (i8 * 33)) ^ this._seed;
        int i11 = i10 + (i10 >>> 16);
        int i12 = i11 ^ (i11 >>> 4);
        return i12 + (i12 << 3);
    }

    public static ByteQuadsCanonicalizer createRoot(int i7) {
        return new ByteQuadsCanonicalizer(64, true, i7, true);
    }

    public int calcHash(int i7, int i8, int i9) {
        int i10 = i7 ^ this._seed;
        int i11 = (((i10 + (i10 >>> 9)) * MULT3) + i8) * 33;
        int i12 = (i11 + (i11 >>> 15)) ^ i9;
        int i13 = i12 + (i12 >>> 4);
        int i14 = i13 + (i13 >>> 15);
        return i14 ^ (i14 << 9);
    }

    public int calcHash(int[] iArr, int i7) {
        if (i7 >= 4) {
            int i8 = iArr[0] ^ this._seed;
            int i9 = i8 + (i8 >>> 9) + iArr[1];
            int i10 = ((i9 + (i9 >>> 15)) * 33) ^ iArr[2];
            int i11 = i10 + (i10 >>> 4);
            for (int i12 = 3; i12 < i7; i12++) {
                int i13 = iArr[i12];
                i11 += i13 ^ (i13 >> 21);
            }
            int i14 = i11 * MULT2;
            int i15 = i14 + (i14 >>> 19);
            return (i15 << 5) ^ i15;
        }
        throw new IllegalArgumentException();
    }

    private ByteQuadsCanonicalizer(ByteQuadsCanonicalizer byteQuadsCanonicalizer, boolean z7, int i7, boolean z8, TableInfo tableInfo) {
        this._parent = byteQuadsCanonicalizer;
        this._seed = i7;
        this._intern = z7;
        this._failOnDoS = z8;
        this._tableInfo = null;
        this._count = tableInfo.count;
        int i8 = tableInfo.size;
        this._hashSize = i8;
        int i9 = i8 << 2;
        this._secondaryStart = i9;
        this._tertiaryStart = i9 + (i9 >> 1);
        this._tertiaryShift = tableInfo.tertiaryShift;
        this._hashArea = tableInfo.mainHash;
        this._names = tableInfo.names;
        this._spilloverEnd = tableInfo.spilloverEnd;
        this._longNameOffset = tableInfo.longNameOffset;
        this._hashShared = true;
    }

    public static final class TableInfo {
        public final int count;
        public final int longNameOffset;
        public final int[] mainHash;
        public final String[] names;
        public final int size;
        public final int spilloverEnd;
        public final int tertiaryShift;

        public TableInfo(int i7, int i8, int i9, int[] iArr, String[] strArr, int i10, int i11) {
            this.size = i7;
            this.count = i8;
            this.tertiaryShift = i9;
            this.mainHash = iArr;
            this.names = strArr;
            this.spilloverEnd = i10;
            this.longNameOffset = i11;
        }

        public static TableInfo createInitial(int i7) {
            int i8 = i7 << 3;
            return new TableInfo(i7, 0, ByteQuadsCanonicalizer._calcTertiaryShift(i7), new int[i8], new String[i7 << 1], i8 - i7, i8);
        }

        public TableInfo(ByteQuadsCanonicalizer byteQuadsCanonicalizer) {
            this.size = byteQuadsCanonicalizer._hashSize;
            this.count = byteQuadsCanonicalizer._count;
            this.tertiaryShift = byteQuadsCanonicalizer._tertiaryShift;
            this.mainHash = byteQuadsCanonicalizer._hashArea;
            this.names = byteQuadsCanonicalizer._names;
            this.spilloverEnd = byteQuadsCanonicalizer._spilloverEnd;
            this.longNameOffset = byteQuadsCanonicalizer._longNameOffset;
        }
    }

    private String _findSecondary(int i7, int i8, int i9) {
        int i10 = this._tertiaryStart;
        int i11 = this._tertiaryShift;
        int i12 = i10 + ((i7 >> (i11 + 2)) << i11);
        int[] iArr = this._hashArea;
        int i13 = (1 << i11) + i12;
        while (i12 < i13) {
            int i14 = iArr[i12 + 3];
            if (i8 == iArr[i12] && i9 == iArr[i12 + 1] && 2 == i14) {
                return this._names[i12 >> 2];
            }
            if (i14 == 0) {
                return null;
            }
            i12 += 4;
        }
        for (int i_spilloverStart = _spilloverStart(); i_spilloverStart < this._spilloverEnd; i_spilloverStart += 4) {
            if (i8 == iArr[i_spilloverStart] && i9 == iArr[i_spilloverStart + 1] && 2 == iArr[i_spilloverStart + 3]) {
                return this._names[i_spilloverStart >> 2];
            }
        }
        return null;
    }

    public String addName(String str, int i7, int i8) {
        _verifySharing();
        if (this._intern) {
            str = InternCache.instance.intern(str);
        }
        int i_findOffsetForAdd = _findOffsetForAdd(i8 == 0 ? calcHash(i7) : calcHash(i7, i8));
        int[] iArr = this._hashArea;
        iArr[i_findOffsetForAdd] = i7;
        iArr[i_findOffsetForAdd + 1] = i8;
        iArr[i_findOffsetForAdd + 3] = 2;
        this._names[i_findOffsetForAdd >> 2] = str;
        this._count++;
        return str;
    }

    public String findName(int i7, int i8) {
        int i_calcOffset = _calcOffset(calcHash(i7, i8));
        int[] iArr = this._hashArea;
        int i9 = iArr[i_calcOffset + 3];
        if (i9 == 2) {
            if (i7 == iArr[i_calcOffset] && i8 == iArr[i_calcOffset + 1]) {
                return this._names[i_calcOffset >> 2];
            }
        } else if (i9 == 0) {
            return null;
        }
        int i10 = this._secondaryStart + ((i_calcOffset >> 3) << 2);
        int i11 = iArr[i10 + 3];
        if (i11 == 2) {
            if (i7 == iArr[i10] && i8 == iArr[i10 + 1]) {
                return this._names[i10 >> 2];
            }
        } else if (i11 == 0) {
            return null;
        }
        return _findSecondary(i_calcOffset, i7, i8);
    }

    private String _findSecondary(int i7, int i8, int i9, int i10) {
        int i11 = this._tertiaryStart;
        int i12 = this._tertiaryShift;
        int i13 = i11 + ((i7 >> (i12 + 2)) << i12);
        int[] iArr = this._hashArea;
        int i14 = (1 << i12) + i13;
        while (i13 < i14) {
            int i15 = iArr[i13 + 3];
            if (i8 == iArr[i13] && i9 == iArr[i13 + 1] && i10 == iArr[i13 + 2] && 3 == i15) {
                return this._names[i13 >> 2];
            }
            if (i15 == 0) {
                return null;
            }
            i13 += 4;
        }
        for (int i_spilloverStart = _spilloverStart(); i_spilloverStart < this._spilloverEnd; i_spilloverStart += 4) {
            if (i8 == iArr[i_spilloverStart] && i9 == iArr[i_spilloverStart + 1] && i10 == iArr[i_spilloverStart + 2] && 3 == iArr[i_spilloverStart + 3]) {
                return this._names[i_spilloverStart >> 2];
            }
        }
        return null;
    }

    public String addName(String str, int i7, int i8, int i9) {
        _verifySharing();
        if (this._intern) {
            str = InternCache.instance.intern(str);
        }
        int i_findOffsetForAdd = _findOffsetForAdd(calcHash(i7, i8, i9));
        int[] iArr = this._hashArea;
        iArr[i_findOffsetForAdd] = i7;
        iArr[i_findOffsetForAdd + 1] = i8;
        iArr[i_findOffsetForAdd + 2] = i9;
        iArr[i_findOffsetForAdd + 3] = 3;
        this._names[i_findOffsetForAdd >> 2] = str;
        this._count++;
        return str;
    }

    public String findName(int i7, int i8, int i9) {
        int i_calcOffset = _calcOffset(calcHash(i7, i8, i9));
        int[] iArr = this._hashArea;
        int i10 = iArr[i_calcOffset + 3];
        if (i10 == 3) {
            if (i7 == iArr[i_calcOffset] && iArr[i_calcOffset + 1] == i8 && iArr[i_calcOffset + 2] == i9) {
                return this._names[i_calcOffset >> 2];
            }
        } else if (i10 == 0) {
            return null;
        }
        int i11 = this._secondaryStart + ((i_calcOffset >> 3) << 2);
        int i12 = iArr[i11 + 3];
        if (i12 == 3) {
            if (i7 == iArr[i11] && iArr[i11 + 1] == i8 && iArr[i11 + 2] == i9) {
                return this._names[i11 >> 2];
            }
        } else if (i12 == 0) {
            return null;
        }
        return _findSecondary(i_calcOffset, i7, i8, i9);
    }

    private String _findSecondary(int i7, int i8, int[] iArr, int i9) {
        int i10 = this._tertiaryStart;
        int i11 = this._tertiaryShift;
        int i12 = i10 + ((i7 >> (i11 + 2)) << i11);
        int[] iArr2 = this._hashArea;
        int i13 = (1 << i11) + i12;
        while (i12 < i13) {
            int i14 = iArr2[i12 + 3];
            if (i8 == iArr2[i12] && i9 == i14 && _verifyLongName(iArr, i9, iArr2[i12 + 1])) {
                return this._names[i12 >> 2];
            }
            if (i14 == 0) {
                return null;
            }
            i12 += 4;
        }
        for (int i_spilloverStart = _spilloverStart(); i_spilloverStart < this._spilloverEnd; i_spilloverStart += 4) {
            if (i8 == iArr2[i_spilloverStart] && i9 == iArr2[i_spilloverStart + 3] && _verifyLongName(iArr, i9, iArr2[i_spilloverStart + 1])) {
                return this._names[i_spilloverStart >> 2];
            }
        }
        return null;
    }

    public String addName(String str, int[] iArr, int i7) {
        int i_findOffsetForAdd;
        _verifySharing();
        if (this._intern) {
            str = InternCache.instance.intern(str);
        }
        if (i7 == 1) {
            i_findOffsetForAdd = _findOffsetForAdd(calcHash(iArr[0]));
            int[] iArr2 = this._hashArea;
            iArr2[i_findOffsetForAdd] = iArr[0];
            iArr2[i_findOffsetForAdd + 3] = 1;
        } else if (i7 == 2) {
            i_findOffsetForAdd = _findOffsetForAdd(calcHash(iArr[0], iArr[1]));
            int[] iArr3 = this._hashArea;
            iArr3[i_findOffsetForAdd] = iArr[0];
            iArr3[i_findOffsetForAdd + 1] = iArr[1];
            iArr3[i_findOffsetForAdd + 3] = 2;
        } else if (i7 != 3) {
            int iCalcHash = calcHash(iArr, i7);
            i_findOffsetForAdd = _findOffsetForAdd(iCalcHash);
            this._hashArea[i_findOffsetForAdd] = iCalcHash;
            int i_appendLongName = _appendLongName(iArr, i7);
            int[] iArr4 = this._hashArea;
            iArr4[i_findOffsetForAdd + 1] = i_appendLongName;
            iArr4[i_findOffsetForAdd + 3] = i7;
        } else {
            int i_findOffsetForAdd2 = _findOffsetForAdd(calcHash(iArr[0], iArr[1], iArr[2]));
            int[] iArr5 = this._hashArea;
            iArr5[i_findOffsetForAdd2] = iArr[0];
            iArr5[i_findOffsetForAdd2 + 1] = iArr[1];
            iArr5[i_findOffsetForAdd2 + 2] = iArr[2];
            iArr5[i_findOffsetForAdd2 + 3] = 3;
            i_findOffsetForAdd = i_findOffsetForAdd2;
        }
        this._names[i_findOffsetForAdd >> 2] = str;
        this._count++;
        return str;
    }

    public String findName(int[] iArr, int i7) {
        if (i7 < 4) {
            if (i7 == 1) {
                return findName(iArr[0]);
            }
            if (i7 == 2) {
                return findName(iArr[0], iArr[1]);
            }
            if (i7 != 3) {
                return "";
            }
            return findName(iArr[0], iArr[1], iArr[2]);
        }
        int iCalcHash = calcHash(iArr, i7);
        int i_calcOffset = _calcOffset(iCalcHash);
        int[] iArr2 = this._hashArea;
        int i8 = iArr2[i_calcOffset + 3];
        if (iCalcHash == iArr2[i_calcOffset] && i8 == i7 && _verifyLongName(iArr, i7, iArr2[i_calcOffset + 1])) {
            return this._names[i_calcOffset >> 2];
        }
        if (i8 == 0) {
            return null;
        }
        int i9 = this._secondaryStart + ((i_calcOffset >> 3) << 2);
        int i10 = iArr2[i9 + 3];
        if (iCalcHash == iArr2[i9] && i10 == i7 && _verifyLongName(iArr, i7, iArr2[i9 + 1])) {
            return this._names[i9 >> 2];
        }
        return _findSecondary(i_calcOffset, iCalcHash, iArr, i7);
    }
}
