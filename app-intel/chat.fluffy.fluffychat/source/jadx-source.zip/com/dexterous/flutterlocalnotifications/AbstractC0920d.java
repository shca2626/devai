package com.dexterous.flutterlocalnotifications;

/* renamed from: com.dexterous.flutterlocalnotifications.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0920d {
}
