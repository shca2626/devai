package com.dexterous.flutterlocalnotifications;

/* loaded from: classes.dex */
public abstract /* synthetic */ class y {
}
