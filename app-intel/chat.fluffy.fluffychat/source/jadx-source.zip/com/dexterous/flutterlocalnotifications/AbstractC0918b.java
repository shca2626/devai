package com.dexterous.flutterlocalnotifications;

/* renamed from: com.dexterous.flutterlocalnotifications.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0918b {
}
