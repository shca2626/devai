package com.baseflow.geolocator;

import F2.C0344e;
import F2.E;
import F2.g;
import F2.h;
import F2.l;
import F2.y;
import F2.z;
import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import h5.c;

/* loaded from: classes.dex */
public class GeolocatorLocationService extends Service {

    /* renamed from: t, reason: collision with root package name */
    public l f14055t;

    /* renamed from: l, reason: collision with root package name */
    public final String f14047l = "GeolocatorLocationService:Wakelock";

    /* renamed from: m, reason: collision with root package name */
    public final String f14048m = "GeolocatorLocationService:WifiLock";

    /* renamed from: n, reason: collision with root package name */
    public final a f14049n = new a(this);

    /* renamed from: o, reason: collision with root package name */
    public boolean f14050o = false;

    /* renamed from: p, reason: collision with root package name */
    public int f14051p = 0;

    /* renamed from: q, reason: collision with root package name */
    public int f14052q = 0;

    /* renamed from: r, reason: collision with root package name */
    public Activity f14053r = null;

    /* renamed from: s, reason: collision with root package name */
    public h f14054s = null;

    /* renamed from: u, reason: collision with root package name */
    public PowerManager.WakeLock f14056u = null;

    /* renamed from: v, reason: collision with root package name */
    public WifiManager.WifiLock f14057v = null;

    /* renamed from: w, reason: collision with root package name */
    public C0344e f14058w = null;

    public class a extends Binder {

        /* renamed from: c, reason: collision with root package name */
        public final GeolocatorLocationService f14059c;

        public a(GeolocatorLocationService geolocatorLocationService) {
            this.f14059c = geolocatorLocationService;
        }

        public GeolocatorLocationService a() {
            return this.f14059c;
        }
    }

    public boolean c(boolean z7) {
        return z7 ? this.f14052q == 1 : this.f14051p == 0;
    }

    public void d(g gVar) {
        C0344e c0344e = this.f14058w;
        if (c0344e != null) {
            c0344e.f(gVar, this.f14050o);
            j(gVar);
        }
    }

    public void e() {
        if (this.f14050o) {
            Log.d("FlutterGeolocator", "Stop service in foreground.");
            stopForeground(1);
            k();
            this.f14050o = false;
            this.f14058w = null;
        }
    }

    public void f(g gVar) {
        if (this.f14058w != null) {
            Log.d("FlutterGeolocator", "Service already in foreground mode.");
            d(gVar);
        } else {
            Log.d("FlutterGeolocator", "Start service in foreground mode.");
            C0344e c0344e = new C0344e(getApplicationContext(), "geolocator_channel_01", 75415, gVar);
            this.f14058w = c0344e;
            c0344e.d(gVar.b());
            startForeground(75415, this.f14058w.a());
            this.f14050o = true;
        }
        j(gVar);
    }

    public void g() {
        this.f14051p++;
        Log.d("FlutterGeolocator", "Flutter engine connected. Connected engine count " + this.f14051p);
    }

    public void h() {
        this.f14051p--;
        Log.d("FlutterGeolocator", "Flutter engine disconnected. Connected engine count " + this.f14051p);
    }

    public final int i() {
        return Build.VERSION.SDK_INT < 29 ? 3 : 4;
    }

    public final void j(g gVar) {
        WifiManager wifiManager;
        PowerManager powerManager;
        k();
        if (gVar.f() && (powerManager = (PowerManager) getApplicationContext().getSystemService("power")) != null) {
            PowerManager.WakeLock wakeLockNewWakeLock = powerManager.newWakeLock(1, "GeolocatorLocationService:Wakelock");
            this.f14056u = wakeLockNewWakeLock;
            wakeLockNewWakeLock.setReferenceCounted(false);
            this.f14056u.acquire();
        }
        if (!gVar.g() || (wifiManager = (WifiManager) getApplicationContext().getSystemService("wifi")) == null) {
            return;
        }
        WifiManager.WifiLock wifiLockCreateWifiLock = wifiManager.createWifiLock(i(), "GeolocatorLocationService:WifiLock");
        this.f14057v = wifiLockCreateWifiLock;
        wifiLockCreateWifiLock.setReferenceCounted(false);
        this.f14057v.acquire();
    }

    public final void k() {
        PowerManager.WakeLock wakeLock = this.f14056u;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.f14056u.release();
            this.f14056u = null;
        }
        WifiManager.WifiLock wifiLock = this.f14057v;
        if (wifiLock == null || !wifiLock.isHeld()) {
            return;
        }
        this.f14057v.release();
        this.f14057v = null;
    }

    public void l(Activity activity) {
        this.f14053r = activity;
    }

    public void m(h hVar) {
        this.f14054s = hVar;
    }

    public void n(boolean z7, z zVar, final c.b bVar) {
        this.f14052q++;
        h hVar = this.f14054s;
        if (hVar != null) {
            l lVarA = hVar.a(getApplicationContext(), Boolean.TRUE.equals(Boolean.valueOf(z7)), zVar);
            this.f14055t = lVarA;
            this.f14054s.e(lVarA, this.f14053r, new E() { // from class: D2.a
                @Override // F2.E
                public final void a(Location location) {
                    bVar.success(y.c(location));
                }
            }, new E2.a() { // from class: D2.b
                @Override // E2.a
                public final void a(E2.b bVar2) {
                    bVar.error(bVar2.toString(), bVar2.d(), null);
                }
            });
        }
    }

    public void o() {
        h hVar;
        this.f14052q--;
        Log.d("FlutterGeolocator", "Stopping location service.");
        l lVar = this.f14055t;
        if (lVar == null || (hVar = this.f14054s) == null) {
            return;
        }
        hVar.f(lVar);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Log.d("FlutterGeolocator", "Binding to location service.");
        return this.f14049n;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Log.d("FlutterGeolocator", "Creating service.");
    }

    @Override // android.app.Service
    public void onDestroy() {
        Log.d("FlutterGeolocator", "Destroying location service.");
        o();
        e();
        this.f14054s = null;
        this.f14058w = null;
        Log.d("FlutterGeolocator", "Destroyed location service.");
        super.onDestroy();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i7, int i8) {
        return 1;
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        Log.d("FlutterGeolocator", "Unbinding from location service.");
        return super.onUnbind(intent);
    }
}
