package com.google.android.material.bottomappbar;

import O2.a;
import O2.i;
import Z.W;
import android.content.Context;
import android.graphics.Rect;
import android.support.v4.media.session.b;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public abstract class BottomAppBar extends Toolbar {

    /* renamed from: h0, reason: collision with root package name */
    public static final int f14237h0 = i.f6906f;

    /* renamed from: i0, reason: collision with root package name */
    public static final int f14238i0 = a.f6761x;

    /* renamed from: j0, reason: collision with root package name */
    public static final int f14239j0 = a.f6762y;

    public static /* synthetic */ void S(BottomAppBar bottomAppBar) {
        throw null;
    }

    public static /* synthetic */ View T(BottomAppBar bottomAppBar) {
        throw null;
    }

    public static void W(BottomAppBar bottomAppBar, View view) {
        ((CoordinatorLayout.e) view.getLayoutParams()).f11871d = 17;
        throw null;
    }

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* renamed from: f, reason: collision with root package name */
        public final Rect f14240f;

        /* renamed from: g, reason: collision with root package name */
        public WeakReference f14241g;

        /* renamed from: h, reason: collision with root package name */
        public int f14242h;

        /* renamed from: i, reason: collision with root package name */
        public final View.OnLayoutChangeListener f14243i;

        public class a implements View.OnLayoutChangeListener {
            public a() {
            }

            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14) {
                b.a(Behavior.this.f14241g.get());
                view.removeOnLayoutChangeListener(this);
            }
        }

        public Behavior() {
            this.f14243i = new a();
            this.f14240f = new Rect();
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.b
        public /* bridge */ /* synthetic */ boolean A(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i7, int i8) {
            b.a(view);
            return P(coordinatorLayout, null, view2, view3, i7, i8);
        }

        public boolean O(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, int i7) {
            this.f14241g = new WeakReference(bottomAppBar);
            View viewT = BottomAppBar.T(bottomAppBar);
            if (viewT != null && !W.Q(viewT)) {
                BottomAppBar.W(bottomAppBar, viewT);
                this.f14242h = ((ViewGroup.MarginLayoutParams) ((CoordinatorLayout.e) viewT.getLayoutParams())).bottomMargin;
                viewT.addOnLayoutChangeListener(this.f14243i);
                BottomAppBar.S(bottomAppBar);
            }
            coordinatorLayout.G(bottomAppBar, i7);
            return super.l(coordinatorLayout, bottomAppBar, i7);
        }

        public boolean P(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, View view, View view2, int i7, int i8) {
            throw null;
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.b
        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, View view, int i7) {
            b.a(view);
            return O(coordinatorLayout, null, i7);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f14243i = new a();
            this.f14240f = new Rect();
        }
    }
}
