package com.google.android.material.datepicker;

import java.util.LinkedHashSet;
import r0.ComponentCallbacksC1549q;

/* loaded from: classes.dex */
public abstract class o extends ComponentCallbacksC1549q {

    /* renamed from: q0, reason: collision with root package name */
    public final LinkedHashSet f14571q0 = new LinkedHashSet();

    public boolean h2(n nVar) {
        return this.f14571q0.add(nVar);
    }

    public void i2() {
        this.f14571q0.clear();
    }
}
