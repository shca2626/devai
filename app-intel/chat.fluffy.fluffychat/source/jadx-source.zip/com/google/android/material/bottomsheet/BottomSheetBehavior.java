package com.google.android.material.bottomsheet;

import O2.i;
import O2.j;
import Z.W;
import a0.InterfaceC0743A;
import a0.x;
import a3.l;
import android.R;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import c3.AbstractC0903c;
import e0.AbstractC1008a;
import f0.C1049c;
import f3.k;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.b {

    /* renamed from: e0, reason: collision with root package name */
    public static final int f14245e0 = i.f6903c;

    /* renamed from: A, reason: collision with root package name */
    public ValueAnimator f14246A;

    /* renamed from: B, reason: collision with root package name */
    public int f14247B;

    /* renamed from: C, reason: collision with root package name */
    public int f14248C;

    /* renamed from: D, reason: collision with root package name */
    public int f14249D;

    /* renamed from: E, reason: collision with root package name */
    public float f14250E;

    /* renamed from: F, reason: collision with root package name */
    public int f14251F;

    /* renamed from: G, reason: collision with root package name */
    public float f14252G;

    /* renamed from: H, reason: collision with root package name */
    public boolean f14253H;

    /* renamed from: I, reason: collision with root package name */
    public boolean f14254I;

    /* renamed from: J, reason: collision with root package name */
    public boolean f14255J;

    /* renamed from: K, reason: collision with root package name */
    public int f14256K;

    /* renamed from: L, reason: collision with root package name */
    public int f14257L;

    /* renamed from: M, reason: collision with root package name */
    public C1049c f14258M;

    /* renamed from: N, reason: collision with root package name */
    public boolean f14259N;

    /* renamed from: O, reason: collision with root package name */
    public int f14260O;

    /* renamed from: P, reason: collision with root package name */
    public boolean f14261P;

    /* renamed from: Q, reason: collision with root package name */
    public float f14262Q;

    /* renamed from: R, reason: collision with root package name */
    public int f14263R;

    /* renamed from: S, reason: collision with root package name */
    public int f14264S;

    /* renamed from: T, reason: collision with root package name */
    public int f14265T;

    /* renamed from: U, reason: collision with root package name */
    public WeakReference f14266U;

    /* renamed from: V, reason: collision with root package name */
    public WeakReference f14267V;

    /* renamed from: W, reason: collision with root package name */
    public final ArrayList f14268W;

    /* renamed from: X, reason: collision with root package name */
    public VelocityTracker f14269X;

    /* renamed from: Y, reason: collision with root package name */
    public int f14270Y;

    /* renamed from: Z, reason: collision with root package name */
    public int f14271Z;

    /* renamed from: a, reason: collision with root package name */
    public int f14272a;

    /* renamed from: a0, reason: collision with root package name */
    public boolean f14273a0;

    /* renamed from: b, reason: collision with root package name */
    public boolean f14274b;

    /* renamed from: b0, reason: collision with root package name */
    public Map f14275b0;

    /* renamed from: c, reason: collision with root package name */
    public boolean f14276c;

    /* renamed from: c0, reason: collision with root package name */
    public int f14277c0;

    /* renamed from: d, reason: collision with root package name */
    public float f14278d;

    /* renamed from: d0, reason: collision with root package name */
    public final C1049c.AbstractC0166c f14279d0;

    /* renamed from: e, reason: collision with root package name */
    public int f14280e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f14281f;

    /* renamed from: g, reason: collision with root package name */
    public int f14282g;

    /* renamed from: h, reason: collision with root package name */
    public int f14283h;

    /* renamed from: i, reason: collision with root package name */
    public f3.g f14284i;

    /* renamed from: j, reason: collision with root package name */
    public ColorStateList f14285j;

    /* renamed from: k, reason: collision with root package name */
    public int f14286k;

    /* renamed from: l, reason: collision with root package name */
    public int f14287l;

    /* renamed from: m, reason: collision with root package name */
    public int f14288m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f14289n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f14290o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f14291p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f14292q;

    /* renamed from: r, reason: collision with root package name */
    public boolean f14293r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f14294s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f14295t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f14296u;

    /* renamed from: v, reason: collision with root package name */
    public int f14297v;

    /* renamed from: w, reason: collision with root package name */
    public int f14298w;

    /* renamed from: x, reason: collision with root package name */
    public k f14299x;

    /* renamed from: y, reason: collision with root package name */
    public boolean f14300y;

    /* renamed from: z, reason: collision with root package name */
    public final h f14301z;

    public class a implements Runnable {

        /* renamed from: l, reason: collision with root package name */
        public final /* synthetic */ View f14302l;

        /* renamed from: m, reason: collision with root package name */
        public final /* synthetic */ int f14303m;

        public a(View view, int i7) {
            this.f14302l = view;
            this.f14303m = i7;
        }

        @Override // java.lang.Runnable
        public void run() {
            BottomSheetBehavior.this.J0(this.f14302l, this.f14303m, false);
        }
    }

    public class b implements ValueAnimator.AnimatorUpdateListener {
        public b() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            if (BottomSheetBehavior.this.f14284i != null) {
                BottomSheetBehavior.this.f14284i.V(fFloatValue);
            }
        }
    }

    public class c implements l.d {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ boolean f14306a;

        public c(boolean z7) {
            this.f14306a = z7;
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0080  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x00a3  */
        @Override // a3.l.d
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public Z.C0701j0 a(android.view.View r11, Z.C0701j0 r12, a3.l.e r13) {
            /*
                r10 = this;
                int r0 = Z.C0701j0.s.h()
                O.b r0 = r12.g(r0)
                int r1 = Z.C0701j0.s.e()
                O.b r1 = r12.g(r1)
                com.google.android.material.bottomsheet.BottomSheetBehavior r2 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r3 = r0.f6453b
                com.google.android.material.bottomsheet.BottomSheetBehavior.N(r2, r3)
                boolean r2 = a3.l.e(r11)
                int r3 = r11.getPaddingBottom()
                int r4 = r11.getPaddingLeft()
                int r5 = r11.getPaddingRight()
                com.google.android.material.bottomsheet.BottomSheetBehavior r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.O(r6)
                if (r6 == 0) goto L41
                com.google.android.material.bottomsheet.BottomSheetBehavior r3 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r6 = r12.i()
                com.google.android.material.bottomsheet.BottomSheetBehavior.Q(r3, r6)
                int r3 = r13.f10776d
                com.google.android.material.bottomsheet.BottomSheetBehavior r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.P(r6)
                int r3 = r3 + r6
            L41:
                com.google.android.material.bottomsheet.BottomSheetBehavior r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.R(r6)
                if (r6 == 0) goto L53
                if (r2 == 0) goto L4e
                int r4 = r13.f10775c
                goto L50
            L4e:
                int r4 = r13.f10773a
            L50:
                int r6 = r0.f6452a
                int r4 = r4 + r6
            L53:
                com.google.android.material.bottomsheet.BottomSheetBehavior r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.S(r6)
                if (r6 == 0) goto L66
                if (r2 == 0) goto L60
                int r13 = r13.f10773a
                goto L62
            L60:
                int r13 = r13.f10775c
            L62:
                int r2 = r0.f6454c
                int r5 = r13 + r2
            L66:
                android.view.ViewGroup$LayoutParams r13 = r11.getLayoutParams()
                android.view.ViewGroup$MarginLayoutParams r13 = (android.view.ViewGroup.MarginLayoutParams) r13
                com.google.android.material.bottomsheet.BottomSheetBehavior r2 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r2 = com.google.android.material.bottomsheet.BottomSheetBehavior.T(r2)
                r6 = 0
                r7 = 1
                if (r2 == 0) goto L80
                int r2 = r13.leftMargin
                int r8 = r0.f6452a
                if (r2 == r8) goto L80
                r13.leftMargin = r8
                r2 = r7
                goto L81
            L80:
                r2 = r6
            L81:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.U(r8)
                if (r8 == 0) goto L92
                int r8 = r13.rightMargin
                int r9 = r0.f6454c
                if (r8 == r9) goto L92
                r13.rightMargin = r9
                r2 = r7
            L92:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.F(r8)
                if (r8 == 0) goto La3
                int r8 = r13.topMargin
                int r0 = r0.f6453b
                if (r8 == r0) goto La3
                r13.topMargin = r0
                goto La4
            La3:
                r7 = r2
            La4:
                if (r7 == 0) goto La9
                r11.setLayoutParams(r13)
            La9:
                int r13 = r11.getPaddingTop()
                r11.setPadding(r4, r13, r5, r3)
                boolean r11 = r10.f14306a
                if (r11 == 0) goto Lbb
                com.google.android.material.bottomsheet.BottomSheetBehavior r11 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r13 = r1.f6455d
                com.google.android.material.bottomsheet.BottomSheetBehavior.G(r11, r13)
            Lbb:
                com.google.android.material.bottomsheet.BottomSheetBehavior r11 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r11 = com.google.android.material.bottomsheet.BottomSheetBehavior.O(r11)
                if (r11 != 0) goto Lc9
                boolean r11 = r10.f14306a
                if (r11 == 0) goto Lc8
                goto Lc9
            Lc8:
                return r12
            Lc9:
                com.google.android.material.bottomsheet.BottomSheetBehavior r11 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                com.google.android.material.bottomsheet.BottomSheetBehavior.H(r11, r6)
                return r12
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.c.a(android.view.View, Z.j0, a3.l$e):Z.j0");
        }
    }

    public class d extends C1049c.AbstractC0166c {

        /* renamed from: a, reason: collision with root package name */
        public long f14308a;

        public d() {
        }

        @Override // f0.C1049c.AbstractC0166c
        public int a(View view, int i7, int i8) {
            return view.getLeft();
        }

        @Override // f0.C1049c.AbstractC0166c
        public int b(View view, int i7, int i8) {
            int iF0 = BottomSheetBehavior.this.f0();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return T.a.b(i7, iF0, bottomSheetBehavior.f14253H ? bottomSheetBehavior.f14265T : bottomSheetBehavior.f14251F);
        }

        @Override // f0.C1049c.AbstractC0166c
        public int e(View view) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return bottomSheetBehavior.f14253H ? bottomSheetBehavior.f14265T : bottomSheetBehavior.f14251F;
        }

        @Override // f0.C1049c.AbstractC0166c
        public void j(int i7) {
            if (i7 == 1 && BottomSheetBehavior.this.f14255J) {
                BottomSheetBehavior.this.C0(1);
            }
        }

        @Override // f0.C1049c.AbstractC0166c
        public void k(View view, int i7, int i8, int i9, int i10) {
            BottomSheetBehavior.this.c0(i8);
        }

        /* JADX WARN: Removed duplicated region for block: B:39:0x00a7  */
        /* JADX WARN: Removed duplicated region for block: B:6:0x0010  */
        @Override // f0.C1049c.AbstractC0166c
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void l(android.view.View r8, float r9, float r10) {
            /*
                Method dump skipped, instructions count: 302
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.d.l(android.view.View, float, float):void");
        }

        @Override // f0.C1049c.AbstractC0166c
        public boolean m(View view, int i7) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            int i8 = bottomSheetBehavior.f14256K;
            if (i8 == 1 || bottomSheetBehavior.f14273a0) {
                return false;
            }
            if (i8 == 3 && bottomSheetBehavior.f14270Y == i7) {
                WeakReference weakReference = bottomSheetBehavior.f14267V;
                View view2 = weakReference != null ? (View) weakReference.get() : null;
                if (view2 != null && view2.canScrollVertically(-1)) {
                    return false;
                }
            }
            this.f14308a = System.currentTimeMillis();
            WeakReference weakReference2 = BottomSheetBehavior.this.f14266U;
            return weakReference2 != null && weakReference2.get() == view;
        }

        public final boolean n(View view) {
            int top = view.getTop();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return top > (bottomSheetBehavior.f14265T + bottomSheetBehavior.f0()) / 2;
        }
    }

    public class e implements InterfaceC0743A {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f14310a;

        public e(int i7) {
            this.f14310a = i7;
        }

        @Override // a0.InterfaceC0743A
        public boolean a(View view, InterfaceC0743A.a aVar) {
            BottomSheetBehavior.this.B0(this.f14310a);
            return true;
        }
    }

    public static abstract class f {
        public void a(View view) {
        }

        public abstract void b(View view, float f7);

        public abstract void c(View view, int i7);
    }

    public BottomSheetBehavior() {
        this.f14272a = 0;
        this.f14274b = true;
        this.f14276c = false;
        this.f14286k = -1;
        this.f14287l = -1;
        this.f14301z = new h(this, null);
        this.f14250E = 0.5f;
        this.f14252G = -1.0f;
        this.f14255J = true;
        this.f14256K = 4;
        this.f14257L = 4;
        this.f14262Q = 0.1f;
        this.f14268W = new ArrayList();
        this.f14277c0 = -1;
        this.f14279d0 = new d();
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public boolean A(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i7, int i8) {
        this.f14260O = 0;
        this.f14261P = false;
        return (i7 & 2) != 0;
    }

    public void A0(boolean z7) {
        this.f14254I = z7;
    }

    public void B0(int i7) {
        if (i7 == 1 || i7 == 2) {
            StringBuilder sb = new StringBuilder();
            sb.append("STATE_");
            sb.append(i7 == 1 ? "DRAGGING" : "SETTLING");
            sb.append(" should not be set externally.");
            throw new IllegalArgumentException(sb.toString());
        }
        if (!this.f14253H && i7 == 5) {
            Log.w("BottomSheetBehavior", "Cannot set state: " + i7);
            return;
        }
        int i8 = (i7 == 6 && this.f14274b && g0(i7) <= this.f14248C) ? 3 : i7;
        WeakReference weakReference = this.f14266U;
        if (weakReference == null || weakReference.get() == null) {
            C0(i7);
        } else {
            View view = (View) this.f14266U.get();
            o0(view, new a(view, i8));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00a9  */
    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void C(androidx.coordinatorlayout.widget.CoordinatorLayout r3, android.view.View r4, android.view.View r5, int r6) {
        /*
            r2 = this;
            int r3 = r4.getTop()
            int r6 = r2.f0()
            r0 = 3
            if (r3 != r6) goto Lf
            r2.C0(r0)
            return
        Lf:
            boolean r3 = r2.k0()
            if (r3 == 0) goto L24
            java.lang.ref.WeakReference r3 = r2.f14267V
            if (r3 == 0) goto L23
            java.lang.Object r3 = r3.get()
            if (r5 != r3) goto L23
            boolean r3 = r2.f14261P
            if (r3 != 0) goto L24
        L23:
            return
        L24:
            int r3 = r2.f14260O
            r5 = 6
            if (r3 <= 0) goto L39
            boolean r3 = r2.f14274b
            if (r3 == 0) goto L2f
            goto Laa
        L2f:
            int r3 = r4.getTop()
            int r6 = r2.f14249D
            if (r3 <= r6) goto Laa
            goto La9
        L39:
            boolean r3 = r2.f14253H
            if (r3 == 0) goto L49
            float r3 = r2.h0()
            boolean r3 = r2.G0(r4, r3)
            if (r3 == 0) goto L49
            r0 = 5
            goto Laa
        L49:
            int r3 = r2.f14260O
            r6 = 4
            if (r3 != 0) goto L8e
            int r3 = r4.getTop()
            boolean r1 = r2.f14274b
            if (r1 == 0) goto L68
            int r5 = r2.f14248C
            int r5 = r3 - r5
            int r5 = java.lang.Math.abs(r5)
            int r1 = r2.f14251F
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r5 >= r3) goto L92
            goto Laa
        L68:
            int r1 = r2.f14249D
            if (r3 >= r1) goto L7e
            int r1 = r2.f14251F
            int r1 = r3 - r1
            int r1 = java.lang.Math.abs(r1)
            if (r3 >= r1) goto L77
            goto Laa
        L77:
            boolean r3 = r2.H0()
            if (r3 == 0) goto La9
            goto L92
        L7e:
            int r0 = r3 - r1
            int r0 = java.lang.Math.abs(r0)
            int r1 = r2.f14251F
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r0 >= r3) goto L92
            goto La9
        L8e:
            boolean r3 = r2.f14274b
            if (r3 == 0) goto L94
        L92:
            r0 = r6
            goto Laa
        L94:
            int r3 = r4.getTop()
            int r0 = r2.f14249D
            int r0 = r3 - r0
            int r0 = java.lang.Math.abs(r0)
            int r1 = r2.f14251F
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r0 >= r3) goto L92
        La9:
            r0 = r5
        Laa:
            r3 = 0
            r2.J0(r4, r0, r3)
            r2.f14261P = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.C(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.View, int):void");
    }

    public void C0(int i7) {
        View view;
        if (this.f14256K == i7) {
            return;
        }
        this.f14256K = i7;
        if (i7 == 4 || i7 == 3 || i7 == 6 || (this.f14253H && i7 == 5)) {
            this.f14257L = i7;
        }
        WeakReference weakReference = this.f14266U;
        if (weakReference == null || (view = (View) weakReference.get()) == null) {
            return;
        }
        if (i7 == 3) {
            M0(true);
        } else if (i7 == 6 || i7 == 5 || i7 == 4) {
            M0(false);
        }
        L0(i7);
        for (int i8 = 0; i8 < this.f14268W.size(); i8++) {
            ((f) this.f14268W.get(i8)).c(view, i7);
        }
        K0();
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public boolean D(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        if (!view.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f14256K == 1 && actionMasked == 0) {
            return true;
        }
        if (F0()) {
            this.f14258M.z(motionEvent);
        }
        if (actionMasked == 0) {
            m0();
        }
        if (this.f14269X == null) {
            this.f14269X = VelocityTracker.obtain();
        }
        this.f14269X.addMovement(motionEvent);
        if (F0() && actionMasked == 2 && !this.f14259N && Math.abs(this.f14271Z - motionEvent.getY()) > this.f14258M.u()) {
            this.f14258M.b(view, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        return !this.f14259N;
    }

    public final void D0(View view) {
        boolean z7 = (Build.VERSION.SDK_INT < 29 || i0() || this.f14281f) ? false : true;
        if (this.f14290o || this.f14291p || this.f14292q || this.f14294s || this.f14295t || this.f14296u || z7) {
            l.a(view, new c(z7));
        }
    }

    public boolean E0(long j7, float f7) {
        return false;
    }

    public final boolean F0() {
        if (this.f14258M != null) {
            return this.f14255J || this.f14256K == 1;
        }
        return false;
    }

    public boolean G0(View view, float f7) {
        if (this.f14254I) {
            return true;
        }
        if (view.getTop() < this.f14251F) {
            return false;
        }
        return Math.abs((((float) view.getTop()) + (f7 * this.f14262Q)) - ((float) this.f14251F)) / ((float) Y()) > 0.5f;
    }

    public boolean H0() {
        return false;
    }

    public boolean I0() {
        return true;
    }

    public final void J0(View view, int i7, boolean z7) {
        int iG0 = g0(i7);
        C1049c c1049c = this.f14258M;
        if (c1049c == null || (!z7 ? c1049c.H(view, view.getLeft(), iG0) : c1049c.F(view.getLeft(), iG0))) {
            C0(i7);
            return;
        }
        C0(2);
        L0(i7);
        this.f14301z.c(i7);
    }

    public final void K0() {
        View view;
        WeakReference weakReference = this.f14266U;
        if (weakReference == null || (view = (View) weakReference.get()) == null) {
            return;
        }
        W.f0(view, 524288);
        W.f0(view, 262144);
        W.f0(view, 1048576);
        int i7 = this.f14277c0;
        if (i7 != -1) {
            W.f0(view, i7);
        }
        if (!this.f14274b && this.f14256K != 6) {
            this.f14277c0 = V(view, O2.h.f6882a, 6);
        }
        if (this.f14253H && this.f14256K != 5) {
            l0(view, x.a.f10530y, 5);
        }
        int i8 = this.f14256K;
        if (i8 == 3) {
            l0(view, x.a.f10529x, this.f14274b ? 4 : 6);
            return;
        }
        if (i8 == 4) {
            l0(view, x.a.f10528w, this.f14274b ? 3 : 6);
        } else {
            if (i8 != 6) {
                return;
            }
            l0(view, x.a.f10529x, 4);
            l0(view, x.a.f10528w, 3);
        }
    }

    public final void L0(int i7) {
        ValueAnimator valueAnimator;
        if (i7 == 2) {
            return;
        }
        boolean z7 = i7 == 3;
        if (this.f14300y != z7) {
            this.f14300y = z7;
            if (this.f14284i == null || (valueAnimator = this.f14246A) == null) {
                return;
            }
            if (valueAnimator.isRunning()) {
                this.f14246A.reverse();
                return;
            }
            float f7 = z7 ? 0.0f : 1.0f;
            this.f14246A.setFloatValues(1.0f - f7, f7);
            this.f14246A.start();
        }
    }

    public final void M0(boolean z7) {
        Map map;
        WeakReference weakReference = this.f14266U;
        if (weakReference == null) {
            return;
        }
        ViewParent parent = ((View) weakReference.get()).getParent();
        if (parent instanceof CoordinatorLayout) {
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
            int childCount = coordinatorLayout.getChildCount();
            if (z7) {
                if (this.f14275b0 != null) {
                    return;
                } else {
                    this.f14275b0 = new HashMap(childCount);
                }
            }
            for (int i7 = 0; i7 < childCount; i7++) {
                View childAt = coordinatorLayout.getChildAt(i7);
                if (childAt != this.f14266U.get()) {
                    if (z7) {
                        this.f14275b0.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                        if (this.f14276c) {
                            W.v0(childAt, 4);
                        }
                    } else if (this.f14276c && (map = this.f14275b0) != null && map.containsKey(childAt)) {
                        W.v0(childAt, ((Integer) this.f14275b0.get(childAt)).intValue());
                    }
                }
            }
            if (!z7) {
                this.f14275b0 = null;
            } else if (this.f14276c) {
                ((View) this.f14266U.get()).sendAccessibilityEvent(8);
            }
        }
    }

    public final void N0(boolean z7) {
        View view;
        if (this.f14266U != null) {
            W();
            if (this.f14256K != 4 || (view = (View) this.f14266U.get()) == null) {
                return;
            }
            if (z7) {
                B0(4);
            } else {
                view.requestLayout();
            }
        }
    }

    public final int V(View view, int i7, int i8) {
        return W.c(view, view.getResources().getString(i7), Z(i8));
    }

    public final void W() {
        int iY = Y();
        if (this.f14274b) {
            this.f14251F = Math.max(this.f14265T - iY, this.f14248C);
        } else {
            this.f14251F = this.f14265T - iY;
        }
    }

    public final void X() {
        this.f14249D = (int) (this.f14265T * (1.0f - this.f14250E));
    }

    public final int Y() {
        int i7;
        return this.f14281f ? Math.min(Math.max(this.f14282g, this.f14265T - ((this.f14264S * 9) / 16)), this.f14263R) + this.f14297v : (this.f14289n || this.f14290o || (i7 = this.f14288m) <= 0) ? this.f14280e + this.f14297v : Math.max(this.f14280e, i7 + this.f14283h);
    }

    public final InterfaceC0743A Z(int i7) {
        return new e(i7);
    }

    public final void a0(Context context) {
        if (this.f14299x == null) {
            return;
        }
        f3.g gVar = new f3.g(this.f14299x);
        this.f14284i = gVar;
        gVar.K(context);
        ColorStateList colorStateList = this.f14285j;
        if (colorStateList != null) {
            this.f14284i.U(colorStateList);
            return;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.colorBackground, typedValue, true);
        this.f14284i.setTint(typedValue.data);
    }

    public final void b0() {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f14246A = valueAnimatorOfFloat;
        valueAnimatorOfFloat.setDuration(500L);
        this.f14246A.addUpdateListener(new b());
    }

    public void c0(int i7) {
        float f7;
        float fF0;
        View view = (View) this.f14266U.get();
        if (view == null || this.f14268W.isEmpty()) {
            return;
        }
        int i8 = this.f14251F;
        if (i7 > i8 || i8 == f0()) {
            int i9 = this.f14251F;
            f7 = i9 - i7;
            fF0 = this.f14265T - i9;
        } else {
            int i10 = this.f14251F;
            f7 = i10 - i7;
            fF0 = i10 - f0();
        }
        float f8 = f7 / fF0;
        for (int i11 = 0; i11 < this.f14268W.size(); i11++) {
            ((f) this.f14268W.get(i11)).b(view, f8);
        }
    }

    public View d0(View view) {
        if (view.getVisibility() != 0) {
            return null;
        }
        if (W.R(view)) {
            return view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i7 = 0; i7 < childCount; i7++) {
                View viewD0 = d0(viewGroup.getChildAt(i7));
                if (viewD0 != null) {
                    return viewD0;
                }
            }
        }
        return null;
    }

    public final int e0(int i7, int i8, int i9, int i10) {
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i7, i8, i10);
        if (i9 == -1) {
            return childMeasureSpec;
        }
        int mode = View.MeasureSpec.getMode(childMeasureSpec);
        int size = View.MeasureSpec.getSize(childMeasureSpec);
        if (mode == 1073741824) {
            return View.MeasureSpec.makeMeasureSpec(Math.min(size, i9), 1073741824);
        }
        if (size != 0) {
            i9 = Math.min(size, i9);
        }
        return View.MeasureSpec.makeMeasureSpec(i9, Integer.MIN_VALUE);
    }

    public int f0() {
        if (this.f14274b) {
            return this.f14248C;
        }
        return Math.max(this.f14247B, this.f14293r ? 0 : this.f14298w);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public void g(CoordinatorLayout.e eVar) {
        super.g(eVar);
        this.f14266U = null;
        this.f14258M = null;
    }

    public final int g0(int i7) {
        if (i7 == 3) {
            return f0();
        }
        if (i7 == 4) {
            return this.f14251F;
        }
        if (i7 == 5) {
            return this.f14265T;
        }
        if (i7 == 6) {
            return this.f14249D;
        }
        throw new IllegalArgumentException("Invalid state to get top offset: " + i7);
    }

    public final float h0() {
        VelocityTracker velocityTracker = this.f14269X;
        if (velocityTracker == null) {
            return 0.0f;
        }
        velocityTracker.computeCurrentVelocity(1000, this.f14278d);
        return this.f14269X.getYVelocity(this.f14270Y);
    }

    public boolean i0() {
        return this.f14289n;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public void j() {
        super.j();
        this.f14266U = null;
        this.f14258M = null;
    }

    public final boolean j0(View view) {
        ViewParent parent = view.getParent();
        return parent != null && parent.isLayoutRequested() && W.P(view);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public boolean k(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        C1049c c1049c;
        if (!view.isShown() || !this.f14255J) {
            this.f14259N = true;
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            m0();
        }
        if (this.f14269X == null) {
            this.f14269X = VelocityTracker.obtain();
        }
        this.f14269X.addMovement(motionEvent);
        if (actionMasked == 0) {
            int x7 = (int) motionEvent.getX();
            this.f14271Z = (int) motionEvent.getY();
            if (this.f14256K != 2) {
                WeakReference weakReference = this.f14267V;
                View view2 = weakReference != null ? (View) weakReference.get() : null;
                if (view2 != null && coordinatorLayout.z(view2, x7, this.f14271Z)) {
                    this.f14270Y = motionEvent.getPointerId(motionEvent.getActionIndex());
                    this.f14273a0 = true;
                }
            }
            this.f14259N = this.f14270Y == -1 && !coordinatorLayout.z(view, x7, this.f14271Z);
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f14273a0 = false;
            this.f14270Y = -1;
            if (this.f14259N) {
                this.f14259N = false;
                return false;
            }
        }
        if (!this.f14259N && (c1049c = this.f14258M) != null && c1049c.G(motionEvent)) {
            return true;
        }
        WeakReference weakReference2 = this.f14267V;
        View view3 = weakReference2 != null ? (View) weakReference2.get() : null;
        return (actionMasked != 2 || view3 == null || this.f14259N || this.f14256K == 1 || coordinatorLayout.z(view3, (int) motionEvent.getX(), (int) motionEvent.getY()) || this.f14258M == null || Math.abs(((float) this.f14271Z) - motionEvent.getY()) <= ((float) this.f14258M.u())) ? false : true;
    }

    public boolean k0() {
        return true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public boolean l(CoordinatorLayout coordinatorLayout, View view, int i7) {
        if (W.x(coordinatorLayout) && !W.x(view)) {
            view.setFitsSystemWindows(true);
        }
        if (this.f14266U == null) {
            this.f14282g = coordinatorLayout.getResources().getDimensionPixelSize(O2.c.f6785a);
            D0(view);
            this.f14266U = new WeakReference(view);
            f3.g gVar = this.f14284i;
            if (gVar != null) {
                W.p0(view, gVar);
                f3.g gVar2 = this.f14284i;
                float fV = this.f14252G;
                if (fV == -1.0f) {
                    fV = W.v(view);
                }
                gVar2.T(fV);
                boolean z7 = this.f14256K == 3;
                this.f14300y = z7;
                this.f14284i.V(z7 ? 0.0f : 1.0f);
            } else {
                ColorStateList colorStateList = this.f14285j;
                if (colorStateList != null) {
                    W.q0(view, colorStateList);
                }
            }
            K0();
            if (W.y(view) == 0) {
                W.v0(view, 1);
            }
        }
        if (this.f14258M == null) {
            this.f14258M = C1049c.m(coordinatorLayout, this.f14279d0);
        }
        int top = view.getTop();
        coordinatorLayout.G(view, i7);
        this.f14264S = coordinatorLayout.getWidth();
        this.f14265T = coordinatorLayout.getHeight();
        int height = view.getHeight();
        this.f14263R = height;
        int i8 = this.f14265T;
        int i9 = i8 - height;
        int i10 = this.f14298w;
        if (i9 < i10) {
            if (this.f14293r) {
                this.f14263R = i8;
            } else {
                this.f14263R = i8 - i10;
            }
        }
        this.f14248C = Math.max(0, i8 - this.f14263R);
        X();
        W();
        int i11 = this.f14256K;
        if (i11 == 3) {
            W.W(view, f0());
        } else if (i11 == 6) {
            W.W(view, this.f14249D);
        } else if (this.f14253H && i11 == 5) {
            W.W(view, this.f14265T);
        } else if (i11 == 4) {
            W.W(view, this.f14251F);
        } else if (i11 == 1 || i11 == 2) {
            W.W(view, top - view.getTop());
        }
        this.f14267V = new WeakReference(d0(view));
        for (int i12 = 0; i12 < this.f14268W.size(); i12++) {
            ((f) this.f14268W.get(i12)).a(view);
        }
        return true;
    }

    public final void l0(View view, x.a aVar, int i7) {
        W.h0(view, aVar, null, Z(i7));
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public boolean m(CoordinatorLayout coordinatorLayout, View view, int i7, int i8, int i9, int i10) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(e0(i7, coordinatorLayout.getPaddingLeft() + coordinatorLayout.getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i8, this.f14286k, marginLayoutParams.width), e0(i9, coordinatorLayout.getPaddingTop() + coordinatorLayout.getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i10, this.f14287l, marginLayoutParams.height));
        return true;
    }

    public final void m0() {
        this.f14270Y = -1;
        VelocityTracker velocityTracker = this.f14269X;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f14269X = null;
        }
    }

    public final void n0(g gVar) {
        int i7 = this.f14272a;
        if (i7 == 0) {
            return;
        }
        if (i7 == -1 || (i7 & 1) == 1) {
            this.f14280e = gVar.f14313o;
        }
        if (i7 == -1 || (i7 & 2) == 2) {
            this.f14274b = gVar.f14314p;
        }
        if (i7 == -1 || (i7 & 4) == 4) {
            this.f14253H = gVar.f14315q;
        }
        if (i7 == -1 || (i7 & 8) == 8) {
            this.f14254I = gVar.f14316r;
        }
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public boolean o(CoordinatorLayout coordinatorLayout, View view, View view2, float f7, float f8) {
        WeakReference weakReference;
        return k0() && (weakReference = this.f14267V) != null && view2 == weakReference.get() && (this.f14256K != 3 || super.o(coordinatorLayout, view, view2, f7, f8));
    }

    public final void o0(View view, Runnable runnable) {
        if (j0(view)) {
            view.post(runnable);
        } else {
            runnable.run();
        }
    }

    public void p0(boolean z7) {
        this.f14255J = z7;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public void q(CoordinatorLayout coordinatorLayout, View view, View view2, int i7, int i8, int[] iArr, int i9) {
        if (i9 == 1) {
            return;
        }
        WeakReference weakReference = this.f14267V;
        View view3 = weakReference != null ? (View) weakReference.get() : null;
        if (!k0() || view2 == view3) {
            int top = view.getTop();
            int i10 = top - i8;
            if (i8 > 0) {
                if (i10 < f0()) {
                    int iF0 = top - f0();
                    iArr[1] = iF0;
                    W.W(view, -iF0);
                    C0(3);
                } else {
                    if (!this.f14255J) {
                        return;
                    }
                    iArr[1] = i8;
                    W.W(view, -i8);
                    C0(1);
                }
            } else if (i8 < 0 && !view2.canScrollVertically(-1)) {
                int i11 = this.f14251F;
                if (i10 > i11 && !this.f14253H) {
                    int i12 = top - i11;
                    iArr[1] = i12;
                    W.W(view, -i12);
                    C0(4);
                } else {
                    if (!this.f14255J) {
                        return;
                    }
                    iArr[1] = i8;
                    W.W(view, -i8);
                    C0(1);
                }
            }
            c0(view.getTop());
            this.f14260O = i8;
            this.f14261P = true;
        }
    }

    public void q0(int i7) {
        if (i7 < 0) {
            throw new IllegalArgumentException("offset must be greater than or equal to 0");
        }
        this.f14247B = i7;
    }

    public void r0(boolean z7) {
        if (this.f14274b == z7) {
            return;
        }
        this.f14274b = z7;
        if (this.f14266U != null) {
            W();
        }
        C0((this.f14274b && this.f14256K == 6) ? 3 : this.f14256K);
        K0();
    }

    public void s0(boolean z7) {
        this.f14289n = z7;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public void t(CoordinatorLayout coordinatorLayout, View view, View view2, int i7, int i8, int i9, int i10, int i11, int[] iArr) {
    }

    public void t0(float f7) {
        if (f7 <= 0.0f || f7 >= 1.0f) {
            throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
        }
        this.f14250E = f7;
        if (this.f14266U != null) {
            X();
        }
    }

    public void u0(boolean z7) {
        if (this.f14253H != z7) {
            this.f14253H = z7;
            if (!z7 && this.f14256K == 5) {
                B0(4);
            }
            K0();
        }
    }

    public void v0(int i7) {
        this.f14287l = i7;
    }

    public void w0(int i7) {
        this.f14286k = i7;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public void x(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
        g gVar = (g) parcelable;
        super.x(coordinatorLayout, view, gVar.b());
        n0(gVar);
        int i7 = gVar.f14312n;
        if (i7 == 1 || i7 == 2) {
            this.f14256K = 4;
            this.f14257L = 4;
        } else {
            this.f14256K = i7;
            this.f14257L = i7;
        }
    }

    public void x0(int i7) {
        y0(i7, false);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public Parcelable y(CoordinatorLayout coordinatorLayout, View view) {
        return new g(super.y(coordinatorLayout, view), this);
    }

    public final void y0(int i7, boolean z7) {
        if (i7 == -1) {
            if (this.f14281f) {
                return;
            } else {
                this.f14281f = true;
            }
        } else {
            if (!this.f14281f && this.f14280e == i7) {
                return;
            }
            this.f14281f = false;
            this.f14280e = Math.max(0, i7);
        }
        N0(z7);
    }

    public void z0(int i7) {
        this.f14272a = i7;
    }

    public class h {

        /* renamed from: a, reason: collision with root package name */
        public int f14317a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f14318b;

        /* renamed from: c, reason: collision with root package name */
        public final Runnable f14319c;

        public class a implements Runnable {
            public a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                h.this.f14318b = false;
                C1049c c1049c = BottomSheetBehavior.this.f14258M;
                if (c1049c != null && c1049c.k(true)) {
                    h hVar = h.this;
                    hVar.c(hVar.f14317a);
                    return;
                }
                h hVar2 = h.this;
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
                if (bottomSheetBehavior.f14256K == 2) {
                    bottomSheetBehavior.C0(hVar2.f14317a);
                }
            }
        }

        public h() {
            this.f14319c = new a();
        }

        public void c(int i7) {
            WeakReference weakReference = BottomSheetBehavior.this.f14266U;
            if (weakReference == null || weakReference.get() == null) {
                return;
            }
            this.f14317a = i7;
            if (this.f14318b) {
                return;
            }
            W.d0((View) BottomSheetBehavior.this.f14266U.get(), this.f14319c);
            this.f14318b = true;
        }

        public /* synthetic */ h(BottomSheetBehavior bottomSheetBehavior, a aVar) {
            this();
        }
    }

    public static class g extends AbstractC1008a {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: n, reason: collision with root package name */
        public final int f14312n;

        /* renamed from: o, reason: collision with root package name */
        public int f14313o;

        /* renamed from: p, reason: collision with root package name */
        public boolean f14314p;

        /* renamed from: q, reason: collision with root package name */
        public boolean f14315q;

        /* renamed from: r, reason: collision with root package name */
        public boolean f14316r;

        public class a implements Parcelable.ClassLoaderCreator {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, (ClassLoader) null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public g[] newArray(int i7) {
                return new g[i7];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f14312n = parcel.readInt();
            this.f14313o = parcel.readInt();
            this.f14314p = parcel.readInt() == 1;
            this.f14315q = parcel.readInt() == 1;
            this.f14316r = parcel.readInt() == 1;
        }

        @Override // e0.AbstractC1008a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i7) {
            super.writeToParcel(parcel, i7);
            parcel.writeInt(this.f14312n);
            parcel.writeInt(this.f14313o);
            parcel.writeInt(this.f14314p ? 1 : 0);
            parcel.writeInt(this.f14315q ? 1 : 0);
            parcel.writeInt(this.f14316r ? 1 : 0);
        }

        public g(Parcelable parcelable, BottomSheetBehavior bottomSheetBehavior) {
            super(parcelable);
            this.f14312n = bottomSheetBehavior.f14256K;
            this.f14313o = bottomSheetBehavior.f14280e;
            this.f14314p = bottomSheetBehavior.f14274b;
            this.f14315q = bottomSheetBehavior.f14253H;
            this.f14316r = bottomSheetBehavior.f14254I;
        }
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        int i7;
        super(context, attributeSet);
        this.f14272a = 0;
        this.f14274b = true;
        this.f14276c = false;
        this.f14286k = -1;
        this.f14287l = -1;
        this.f14301z = new h(this, null);
        this.f14250E = 0.5f;
        this.f14252G = -1.0f;
        this.f14255J = true;
        this.f14256K = 4;
        this.f14257L = 4;
        this.f14262Q = 0.1f;
        this.f14268W = new ArrayList();
        this.f14277c0 = -1;
        this.f14279d0 = new d();
        this.f14283h = context.getResources().getDimensionPixelSize(O2.c.f6778I);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.f7276x);
        if (typedArrayObtainStyledAttributes.hasValue(j.f6921B)) {
            this.f14285j = AbstractC0903c.a(context, typedArrayObtainStyledAttributes, j.f6921B);
        }
        if (typedArrayObtainStyledAttributes.hasValue(j.f7040S)) {
            this.f14299x = k.e(context, attributeSet, O2.a.f6739b, f14245e0).m();
        }
        a0(context);
        b0();
        this.f14252G = typedArrayObtainStyledAttributes.getDimension(j.f6914A, -1.0f);
        if (typedArrayObtainStyledAttributes.hasValue(j.f7283y)) {
            w0(typedArrayObtainStyledAttributes.getDimensionPixelSize(j.f7283y, -1));
        }
        if (typedArrayObtainStyledAttributes.hasValue(j.f7290z)) {
            v0(typedArrayObtainStyledAttributes.getDimensionPixelSize(j.f7290z, -1));
        }
        TypedValue typedValuePeekValue = typedArrayObtainStyledAttributes.peekValue(j.f6963H);
        if (typedValuePeekValue != null && (i7 = typedValuePeekValue.data) == -1) {
            x0(i7);
        } else {
            x0(typedArrayObtainStyledAttributes.getDimensionPixelSize(j.f6963H, -1));
        }
        u0(typedArrayObtainStyledAttributes.getBoolean(j.f6956G, false));
        s0(typedArrayObtainStyledAttributes.getBoolean(j.f6984K, false));
        r0(typedArrayObtainStyledAttributes.getBoolean(j.f6942E, true));
        A0(typedArrayObtainStyledAttributes.getBoolean(j.f6977J, false));
        p0(typedArrayObtainStyledAttributes.getBoolean(j.f6928C, true));
        z0(typedArrayObtainStyledAttributes.getInt(j.f6970I, 0));
        t0(typedArrayObtainStyledAttributes.getFloat(j.f6949F, 0.5f));
        TypedValue typedValuePeekValue2 = typedArrayObtainStyledAttributes.peekValue(j.f6935D);
        if (typedValuePeekValue2 != null && typedValuePeekValue2.type == 16) {
            q0(typedValuePeekValue2.data);
        } else {
            q0(typedArrayObtainStyledAttributes.getDimensionPixelOffset(j.f6935D, 0));
        }
        this.f14290o = typedArrayObtainStyledAttributes.getBoolean(j.f7012O, false);
        this.f14291p = typedArrayObtainStyledAttributes.getBoolean(j.f7019P, false);
        this.f14292q = typedArrayObtainStyledAttributes.getBoolean(j.f7026Q, false);
        this.f14293r = typedArrayObtainStyledAttributes.getBoolean(j.f7033R, true);
        this.f14294s = typedArrayObtainStyledAttributes.getBoolean(j.f6991L, false);
        this.f14295t = typedArrayObtainStyledAttributes.getBoolean(j.f6998M, false);
        this.f14296u = typedArrayObtainStyledAttributes.getBoolean(j.f7005N, false);
        typedArrayObtainStyledAttributes.recycle();
        this.f14278d = ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }
}
