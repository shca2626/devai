package com.google.android.material.button;

import O2.i;
import O2.j;
import Z.W;
import a3.l;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import c0.AbstractC0896h;
import c3.AbstractC0903c;
import e0.AbstractC1008a;
import f3.h;
import f3.k;
import f3.n;
import i3.AbstractC1152a;
import java.util.Iterator;
import java.util.LinkedHashSet;
import k.AbstractC1244a;
import q.C1468e;

/* loaded from: classes.dex */
public class MaterialButton extends C1468e implements Checkable, n {

    /* renamed from: B, reason: collision with root package name */
    public static final int[] f14322B = {R.attr.state_checkable};

    /* renamed from: C, reason: collision with root package name */
    public static final int[] f14323C = {R.attr.state_checked};

    /* renamed from: D, reason: collision with root package name */
    public static final int f14324D = i.f6907g;

    /* renamed from: A, reason: collision with root package name */
    public int f14325A;

    /* renamed from: o, reason: collision with root package name */
    public final R2.a f14326o;

    /* renamed from: p, reason: collision with root package name */
    public final LinkedHashSet f14327p;

    /* renamed from: q, reason: collision with root package name */
    public a f14328q;

    /* renamed from: r, reason: collision with root package name */
    public PorterDuff.Mode f14329r;

    /* renamed from: s, reason: collision with root package name */
    public ColorStateList f14330s;

    /* renamed from: t, reason: collision with root package name */
    public Drawable f14331t;

    /* renamed from: u, reason: collision with root package name */
    public int f14332u;

    /* renamed from: v, reason: collision with root package name */
    public int f14333v;

    /* renamed from: w, reason: collision with root package name */
    public int f14334w;

    /* renamed from: x, reason: collision with root package name */
    public int f14335x;

    /* renamed from: y, reason: collision with root package name */
    public boolean f14336y;

    /* renamed from: z, reason: collision with root package name */
    public boolean f14337z;

    public interface a {
        void a(MaterialButton materialButton, boolean z7);
    }

    public static class b extends AbstractC1008a {
        public static final Parcelable.Creator<b> CREATOR = new a();

        /* renamed from: n, reason: collision with root package name */
        public boolean f14338n;

        public class a implements Parcelable.ClassLoaderCreator {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public b createFromParcel(Parcel parcel) {
                return new b(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public b createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new b(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public b[] newArray(int i7) {
                return new b[i7];
            }
        }

        public b(Parcelable parcelable) {
            super(parcelable);
        }

        public final void c(Parcel parcel) {
            this.f14338n = parcel.readInt() == 1;
        }

        @Override // e0.AbstractC1008a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i7) {
            super.writeToParcel(parcel, i7);
            parcel.writeInt(this.f14338n ? 1 : 0);
        }

        public b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                getClass().getClassLoader();
            }
            c(parcel);
        }
    }

    public MaterialButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, O2.a.f6756s);
    }

    private String getA11yClassName() {
        return (c() ? CompoundButton.class : Button.class).getName();
    }

    private Layout.Alignment getActualTextAlignment() {
        int textAlignment = getTextAlignment();
        return textAlignment != 1 ? (textAlignment == 6 || textAlignment == 3) ? Layout.Alignment.ALIGN_OPPOSITE : textAlignment != 4 ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER : getGravityTextAlignment();
    }

    private Layout.Alignment getGravityTextAlignment() {
        int gravity = getGravity() & 8388615;
        return gravity != 1 ? (gravity == 5 || gravity == 8388613) ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER;
    }

    private int getTextHeight() {
        if (getLineCount() > 1) {
            return getLayout().getHeight();
        }
        TextPaint paint = getPaint();
        String string = getText().toString();
        if (getTransformationMethod() != null) {
            string = getTransformationMethod().getTransformation(string, this).toString();
        }
        Rect rect = new Rect();
        paint.getTextBounds(string, 0, string.length(), rect);
        return Math.min(rect.height(), getLayout().getHeight());
    }

    private int getTextLayoutWidth() {
        int lineCount = getLineCount();
        int iMax = 0;
        for (int i7 = 0; i7 < lineCount; i7++) {
            iMax = Math.max(iMax, b(a(i7)));
        }
        return iMax;
    }

    public final CharSequence a(int i7) {
        return getText().subSequence(getLayout().getLineStart(i7), getLayout().getLineEnd(i7));
    }

    public final int b(CharSequence charSequence) {
        TextPaint paint = getPaint();
        String string = charSequence.toString();
        if (getTransformationMethod() != null) {
            string = getTransformationMethod().getTransformation(string, this).toString();
        }
        return Math.min((int) paint.measureText(string), getLayout().getEllipsizedWidth());
    }

    public boolean c() {
        R2.a aVar = this.f14326o;
        return aVar != null && aVar.p();
    }

    public final boolean d() {
        int i7 = this.f14325A;
        return i7 == 3 || i7 == 4;
    }

    public final boolean e() {
        int i7 = this.f14325A;
        return i7 == 1 || i7 == 2;
    }

    public final boolean f() {
        int i7 = this.f14325A;
        return i7 == 16 || i7 == 32;
    }

    public final boolean g() {
        return W.A(this) == 1;
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (h()) {
            return this.f14326o.b();
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.f14331t;
    }

    public int getIconGravity() {
        return this.f14325A;
    }

    public int getIconPadding() {
        return this.f14335x;
    }

    public int getIconSize() {
        return this.f14332u;
    }

    public ColorStateList getIconTint() {
        return this.f14330s;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f14329r;
    }

    public int getInsetBottom() {
        return this.f14326o.c();
    }

    public int getInsetTop() {
        return this.f14326o.d();
    }

    public ColorStateList getRippleColor() {
        if (h()) {
            return this.f14326o.h();
        }
        return null;
    }

    public k getShapeAppearanceModel() {
        if (h()) {
            return this.f14326o.i();
        }
        throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
    }

    public ColorStateList getStrokeColor() {
        if (h()) {
            return this.f14326o.j();
        }
        return null;
    }

    public int getStrokeWidth() {
        if (h()) {
            return this.f14326o.k();
        }
        return 0;
    }

    @Override // q.C1468e
    public ColorStateList getSupportBackgroundTintList() {
        return h() ? this.f14326o.l() : super.getSupportBackgroundTintList();
    }

    @Override // q.C1468e
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return h() ? this.f14326o.m() : super.getSupportBackgroundTintMode();
    }

    public final boolean h() {
        R2.a aVar = this.f14326o;
        return (aVar == null || aVar.o()) ? false : true;
    }

    public final void i() {
        if (e()) {
            AbstractC0896h.i(this, this.f14331t, null, null, null);
        } else if (d()) {
            AbstractC0896h.i(this, null, null, this.f14331t, null);
        } else if (f()) {
            AbstractC0896h.i(this, null, this.f14331t, null, null);
        }
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.f14336y;
    }

    public final void j(boolean z7) {
        Drawable drawable = this.f14331t;
        if (drawable != null) {
            Drawable drawableMutate = P.a.r(drawable).mutate();
            this.f14331t = drawableMutate;
            P.a.o(drawableMutate, this.f14330s);
            PorterDuff.Mode mode = this.f14329r;
            if (mode != null) {
                P.a.p(this.f14331t, mode);
            }
            int intrinsicWidth = this.f14332u;
            if (intrinsicWidth == 0) {
                intrinsicWidth = this.f14331t.getIntrinsicWidth();
            }
            int intrinsicHeight = this.f14332u;
            if (intrinsicHeight == 0) {
                intrinsicHeight = this.f14331t.getIntrinsicHeight();
            }
            Drawable drawable2 = this.f14331t;
            int i7 = this.f14333v;
            int i8 = this.f14334w;
            drawable2.setBounds(i7, i8, intrinsicWidth + i7, intrinsicHeight + i8);
            this.f14331t.setVisible(true, z7);
        }
        if (z7) {
            i();
            return;
        }
        Drawable[] drawableArrA = AbstractC0896h.a(this);
        Drawable drawable3 = drawableArrA[0];
        Drawable drawable4 = drawableArrA[1];
        Drawable drawable5 = drawableArrA[2];
        if ((!e() || drawable3 == this.f14331t) && ((!d() || drawable5 == this.f14331t) && (!f() || drawable4 == this.f14331t))) {
            return;
        }
        i();
    }

    public final void k(int i7, int i8) {
        if (this.f14331t == null || getLayout() == null) {
            return;
        }
        if (!e() && !d()) {
            if (f()) {
                this.f14333v = 0;
                if (this.f14325A == 16) {
                    this.f14334w = 0;
                    j(false);
                    return;
                }
                int intrinsicHeight = this.f14332u;
                if (intrinsicHeight == 0) {
                    intrinsicHeight = this.f14331t.getIntrinsicHeight();
                }
                int iMax = Math.max(0, (((((i8 - getTextHeight()) - getPaddingTop()) - intrinsicHeight) - this.f14335x) - getPaddingBottom()) / 2);
                if (this.f14334w != iMax) {
                    this.f14334w = iMax;
                    j(false);
                    return;
                }
                return;
            }
            return;
        }
        this.f14334w = 0;
        Layout.Alignment actualTextAlignment = getActualTextAlignment();
        int i9 = this.f14325A;
        if (i9 == 1 || i9 == 3 || ((i9 == 2 && actualTextAlignment == Layout.Alignment.ALIGN_NORMAL) || (i9 == 4 && actualTextAlignment == Layout.Alignment.ALIGN_OPPOSITE))) {
            this.f14333v = 0;
            j(false);
            return;
        }
        int intrinsicWidth = this.f14332u;
        if (intrinsicWidth == 0) {
            intrinsicWidth = this.f14331t.getIntrinsicWidth();
        }
        int textLayoutWidth = ((((i7 - getTextLayoutWidth()) - W.E(this)) - intrinsicWidth) - this.f14335x) - W.F(this);
        if (actualTextAlignment == Layout.Alignment.ALIGN_CENTER) {
            textLayoutWidth /= 2;
        }
        if (g() != (this.f14325A == 4)) {
            textLayoutWidth = -textLayoutWidth;
        }
        if (this.f14333v != textLayoutWidth) {
            this.f14333v = textLayoutWidth;
            j(false);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (h()) {
            h.d(this, this.f14326o.f());
        }
    }

    @Override // android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i7) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i7 + 2);
        if (c()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f14322B);
        }
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f14323C);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // q.C1468e, android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(isChecked());
    }

    @Override // q.C1468e, android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        accessibilityNodeInfo.setCheckable(c());
        accessibilityNodeInfo.setChecked(isChecked());
        accessibilityNodeInfo.setClickable(isClickable());
    }

    @Override // q.C1468e, android.widget.TextView, android.view.View
    public void onLayout(boolean z7, int i7, int i8, int i9, int i10) {
        super.onLayout(z7, i7, i8, i9, i10);
        k(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b bVar = (b) parcelable;
        super.onRestoreInstanceState(bVar.b());
        setChecked(bVar.f14338n);
    }

    @Override // android.widget.TextView, android.view.View
    public Parcelable onSaveInstanceState() {
        b bVar = new b(super.onSaveInstanceState());
        bVar.f14338n = this.f14336y;
        return bVar;
    }

    @Override // q.C1468e, android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
        super.onTextChanged(charSequence, i7, i8, i9);
        k(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.view.View
    public boolean performClick() {
        if (this.f14326o.q()) {
            toggle();
        }
        return super.performClick();
    }

    @Override // android.view.View
    public void refreshDrawableState() {
        super.refreshDrawableState();
        if (this.f14331t != null) {
            if (this.f14331t.setState(getDrawableState())) {
                invalidate();
            }
        }
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i7) {
        if (h()) {
            this.f14326o.s(i7);
        } else {
            super.setBackgroundColor(i7);
        }
    }

    @Override // q.C1468e, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (!h()) {
            super.setBackgroundDrawable(drawable);
        } else {
            if (drawable == getBackground()) {
                getBackground().setState(drawable.getState());
                return;
            }
            Log.w("MaterialButton", "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled");
            this.f14326o.t();
            super.setBackgroundDrawable(drawable);
        }
    }

    @Override // q.C1468e, android.view.View
    public void setBackgroundResource(int i7) {
        setBackgroundDrawable(i7 != 0 ? AbstractC1244a.b(getContext(), i7) : null);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z7) {
        if (h()) {
            this.f14326o.u(z7);
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z7) {
        if (c() && isEnabled() && this.f14336y != z7) {
            this.f14336y = z7;
            refreshDrawableState();
            if (getParent() instanceof MaterialButtonToggleGroup) {
                ((MaterialButtonToggleGroup) getParent()).m(this, this.f14336y);
            }
            if (this.f14337z) {
                return;
            }
            this.f14337z = true;
            Iterator it = this.f14327p.iterator();
            if (it.hasNext()) {
                android.support.v4.media.session.b.a(it.next());
                throw null;
            }
            this.f14337z = false;
        }
    }

    public void setCornerRadius(int i7) {
        if (h()) {
            this.f14326o.v(i7);
        }
    }

    public void setCornerRadiusResource(int i7) {
        if (h()) {
            setCornerRadius(getResources().getDimensionPixelSize(i7));
        }
    }

    @Override // android.view.View
    public void setElevation(float f7) {
        super.setElevation(f7);
        if (h()) {
            this.f14326o.f().T(f7);
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.f14331t != drawable) {
            this.f14331t = drawable;
            j(true);
            k(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconGravity(int i7) {
        if (this.f14325A != i7) {
            this.f14325A = i7;
            k(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconPadding(int i7) {
        if (this.f14335x != i7) {
            this.f14335x = i7;
            setCompoundDrawablePadding(i7);
        }
    }

    public void setIconResource(int i7) {
        setIcon(i7 != 0 ? AbstractC1244a.b(getContext(), i7) : null);
    }

    public void setIconSize(int i7) {
        if (i7 < 0) {
            throw new IllegalArgumentException("iconSize cannot be less than 0");
        }
        if (this.f14332u != i7) {
            this.f14332u = i7;
            j(true);
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.f14330s != colorStateList) {
            this.f14330s = colorStateList;
            j(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.f14329r != mode) {
            this.f14329r = mode;
            j(false);
        }
    }

    public void setIconTintResource(int i7) {
        setIconTint(AbstractC1244a.a(getContext(), i7));
    }

    public void setInsetBottom(int i7) {
        this.f14326o.w(i7);
    }

    public void setInsetTop(int i7) {
        this.f14326o.x(i7);
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOnPressedChangeListenerInternal(a aVar) {
        this.f14328q = aVar;
    }

    @Override // android.view.View
    public void setPressed(boolean z7) {
        a aVar = this.f14328q;
        if (aVar != null) {
            aVar.a(this, z7);
        }
        super.setPressed(z7);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (h()) {
            this.f14326o.y(colorStateList);
        }
    }

    public void setRippleColorResource(int i7) {
        if (h()) {
            setRippleColor(AbstractC1244a.a(getContext(), i7));
        }
    }

    @Override // f3.n
    public void setShapeAppearanceModel(k kVar) {
        if (!h()) {
            throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
        }
        this.f14326o.z(kVar);
    }

    public void setShouldDrawSurfaceColorStroke(boolean z7) {
        if (h()) {
            this.f14326o.A(z7);
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (h()) {
            this.f14326o.B(colorStateList);
        }
    }

    public void setStrokeColorResource(int i7) {
        if (h()) {
            setStrokeColor(AbstractC1244a.a(getContext(), i7));
        }
    }

    public void setStrokeWidth(int i7) {
        if (h()) {
            this.f14326o.C(i7);
        }
    }

    public void setStrokeWidthResource(int i7) {
        if (h()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i7));
        }
    }

    @Override // q.C1468e
    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (h()) {
            this.f14326o.D(colorStateList);
        } else {
            super.setSupportBackgroundTintList(colorStateList);
        }
    }

    @Override // q.C1468e
    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (h()) {
            this.f14326o.E(mode);
        } else {
            super.setSupportBackgroundTintMode(mode);
        }
    }

    @Override // android.view.View
    public void setTextAlignment(int i7) {
        super.setTextAlignment(i7);
        k(getMeasuredWidth(), getMeasuredHeight());
    }

    public void setToggleCheckedStateOnClick(boolean z7) {
        this.f14326o.F(z7);
    }

    @Override // android.widget.Checkable
    public void toggle() {
        setChecked(!this.f14336y);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public MaterialButton(Context context, AttributeSet attributeSet, int i7) {
        int i8 = f14324D;
        super(AbstractC1152a.c(context, attributeSet, i7, i8), attributeSet, i7);
        this.f14327p = new LinkedHashSet();
        this.f14336y = false;
        this.f14337z = false;
        Context context2 = getContext();
        TypedArray typedArrayI = a3.k.i(context2, attributeSet, j.f7063V1, i7, i8, new int[0]);
        this.f14335x = typedArrayI.getDimensionPixelSize(j.f7163i2, 0);
        this.f14329r = l.f(typedArrayI.getInt(j.f7187l2, -1), PorterDuff.Mode.SRC_IN);
        this.f14330s = AbstractC0903c.a(getContext(), typedArrayI, j.f7179k2);
        this.f14331t = AbstractC0903c.d(getContext(), typedArrayI, j.f7147g2);
        this.f14325A = typedArrayI.getInteger(j.f7155h2, 1);
        this.f14332u = typedArrayI.getDimensionPixelSize(j.f7171j2, 0);
        R2.a aVar = new R2.a(this, k.e(context2, attributeSet, i7, i8).m());
        this.f14326o = aVar;
        aVar.r(typedArrayI);
        typedArrayI.recycle();
        setCompoundDrawablePadding(this.f14335x);
        j(this.f14331t != null);
    }
}
