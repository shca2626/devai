package com.google.android.material.textfield;

import O2.e;
import O2.h;
import Z.AbstractC0721y;
import Z.W;
import a0.AbstractC0746c;
import a3.j;
import a3.l;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import c0.AbstractC0896h;
import c3.AbstractC0903c;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.textfield.TextInputLayout;
import g3.C1108f;
import g3.g;
import g3.q;
import g3.s;
import g3.t;
import g3.w;
import g3.y;
import java.util.Iterator;
import java.util.LinkedHashSet;
import k.AbstractC1244a;
import q.C;
import q.d0;

/* loaded from: classes.dex */
public class a extends LinearLayout {

    /* renamed from: A, reason: collision with root package name */
    public boolean f14708A;

    /* renamed from: B, reason: collision with root package name */
    public EditText f14709B;

    /* renamed from: C, reason: collision with root package name */
    public final AccessibilityManager f14710C;

    /* renamed from: D, reason: collision with root package name */
    public AbstractC0746c.a f14711D;

    /* renamed from: E, reason: collision with root package name */
    public final TextWatcher f14712E;

    /* renamed from: F, reason: collision with root package name */
    public final TextInputLayout.g f14713F;

    /* renamed from: l, reason: collision with root package name */
    public final TextInputLayout f14714l;

    /* renamed from: m, reason: collision with root package name */
    public final FrameLayout f14715m;

    /* renamed from: n, reason: collision with root package name */
    public final CheckableImageButton f14716n;

    /* renamed from: o, reason: collision with root package name */
    public ColorStateList f14717o;

    /* renamed from: p, reason: collision with root package name */
    public PorterDuff.Mode f14718p;

    /* renamed from: q, reason: collision with root package name */
    public View.OnLongClickListener f14719q;

    /* renamed from: r, reason: collision with root package name */
    public final CheckableImageButton f14720r;

    /* renamed from: s, reason: collision with root package name */
    public final d f14721s;

    /* renamed from: t, reason: collision with root package name */
    public int f14722t;

    /* renamed from: u, reason: collision with root package name */
    public final LinkedHashSet f14723u;

    /* renamed from: v, reason: collision with root package name */
    public ColorStateList f14724v;

    /* renamed from: w, reason: collision with root package name */
    public PorterDuff.Mode f14725w;

    /* renamed from: x, reason: collision with root package name */
    public View.OnLongClickListener f14726x;

    /* renamed from: y, reason: collision with root package name */
    public CharSequence f14727y;

    /* renamed from: z, reason: collision with root package name */
    public final TextView f14728z;

    /* renamed from: com.google.android.material.textfield.a$a, reason: collision with other inner class name */
    public class C0146a extends j {
        public C0146a() {
        }

        @Override // a3.j, android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            a.this.m().a(editable);
        }

        @Override // a3.j, android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
            a.this.m().b(charSequence, i7, i8, i9);
        }
    }

    public class b implements TextInputLayout.g {
        public b() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.g
        public void a(TextInputLayout textInputLayout) {
            if (a.this.f14709B == textInputLayout.getEditText()) {
                return;
            }
            if (a.this.f14709B != null) {
                a.this.f14709B.removeTextChangedListener(a.this.f14712E);
                if (a.this.f14709B.getOnFocusChangeListener() == a.this.m().e()) {
                    a.this.f14709B.setOnFocusChangeListener(null);
                }
            }
            a.this.f14709B = textInputLayout.getEditText();
            if (a.this.f14709B != null) {
                a.this.f14709B.addTextChangedListener(a.this.f14712E);
            }
            a.this.m().n(a.this.f14709B);
            a aVar = a.this;
            aVar.c0(aVar.m());
        }
    }

    public class c implements View.OnAttachStateChangeListener {
        public c() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            a.this.g();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            a.this.J();
        }
    }

    public static class d {

        /* renamed from: a, reason: collision with root package name */
        public final SparseArray f14732a = new SparseArray();

        /* renamed from: b, reason: collision with root package name */
        public final a f14733b;

        /* renamed from: c, reason: collision with root package name */
        public final int f14734c;

        /* renamed from: d, reason: collision with root package name */
        public final int f14735d;

        public d(a aVar, d0 d0Var) {
            this.f14733b = aVar;
            this.f14734c = d0Var.n(O2.j.f7254t5, 0);
            this.f14735d = d0Var.n(O2.j.f7018O5, 0);
        }

        public final s b(int i7) {
            if (i7 == -1) {
                return new g(this.f14733b);
            }
            if (i7 == 0) {
                return new w(this.f14733b);
            }
            if (i7 == 1) {
                return new y(this.f14733b, this.f14735d);
            }
            if (i7 == 2) {
                return new C1108f(this.f14733b);
            }
            if (i7 == 3) {
                return new q(this.f14733b);
            }
            throw new IllegalArgumentException("Invalid end icon mode: " + i7);
        }

        public s c(int i7) {
            s sVar = (s) this.f14732a.get(i7);
            if (sVar != null) {
                return sVar;
            }
            s sVarB = b(i7);
            this.f14732a.append(i7, sVarB);
            return sVarB;
        }
    }

    public a(TextInputLayout textInputLayout, d0 d0Var) {
        super(textInputLayout.getContext());
        this.f14722t = 0;
        this.f14723u = new LinkedHashSet();
        this.f14712E = new C0146a();
        b bVar = new b();
        this.f14713F = bVar;
        this.f14710C = (AccessibilityManager) getContext().getSystemService("accessibility");
        this.f14714l = textInputLayout;
        setVisibility(8);
        setOrientation(0);
        setLayoutParams(new FrameLayout.LayoutParams(-2, -1, 8388613));
        FrameLayout frameLayout = new FrameLayout(getContext());
        this.f14715m = frameLayout;
        frameLayout.setVisibility(8);
        frameLayout.setLayoutParams(new LinearLayout.LayoutParams(-2, -1));
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(getContext());
        CheckableImageButton checkableImageButtonI = i(this, layoutInflaterFrom, e.f6829I);
        this.f14716n = checkableImageButtonI;
        CheckableImageButton checkableImageButtonI2 = i(frameLayout, layoutInflaterFrom, e.f6828H);
        this.f14720r = checkableImageButtonI2;
        this.f14721s = new d(this, d0Var);
        C c7 = new C(getContext());
        this.f14728z = c7;
        z(d0Var);
        y(d0Var);
        A(d0Var);
        frameLayout.addView(checkableImageButtonI2);
        addView(c7);
        addView(frameLayout);
        addView(checkableImageButtonI);
        textInputLayout.h(bVar);
        addOnAttachStateChangeListener(new c());
    }

    public final void A(d0 d0Var) {
        this.f14728z.setVisibility(8);
        this.f14728z.setId(e.f6835O);
        this.f14728z.setLayoutParams(new LinearLayout.LayoutParams(-2, -2, 80.0f));
        W.n0(this.f14728z, 1);
        l0(d0Var.n(O2.j.f7135e6, 0));
        if (d0Var.s(O2.j.f7143f6)) {
            m0(d0Var.c(O2.j.f7143f6));
        }
        k0(d0Var.p(O2.j.f7127d6));
    }

    public boolean B() {
        return x() && this.f14720r.isChecked();
    }

    public boolean C() {
        return this.f14715m.getVisibility() == 0 && this.f14720r.getVisibility() == 0;
    }

    public boolean D() {
        return this.f14716n.getVisibility() == 0;
    }

    public void E(boolean z7) {
        this.f14708A = z7;
        t0();
    }

    public void F() {
        r0();
        H();
        G();
        if (m().t()) {
            p0(this.f14714l.a0());
        }
    }

    public void G() {
        t.c(this.f14714l, this.f14720r, this.f14724v);
    }

    public void H() {
        t.c(this.f14714l, this.f14716n, this.f14717o);
    }

    public void I(boolean z7) {
        boolean z8;
        boolean zIsActivated;
        boolean zIsChecked;
        s sVarM = m();
        boolean z9 = true;
        if (!sVarM.l() || (zIsChecked = this.f14720r.isChecked()) == sVarM.m()) {
            z8 = false;
        } else {
            this.f14720r.setChecked(!zIsChecked);
            z8 = true;
        }
        if (!sVarM.j() || (zIsActivated = this.f14720r.isActivated()) == sVarM.k()) {
            z9 = z8;
        } else {
            K(!zIsActivated);
        }
        if (z7 || z9) {
            G();
        }
    }

    public final void J() {
        AccessibilityManager accessibilityManager;
        AbstractC0746c.a aVar = this.f14711D;
        if (aVar == null || (accessibilityManager = this.f14710C) == null) {
            return;
        }
        AbstractC0746c.b(accessibilityManager, aVar);
    }

    public void K(boolean z7) {
        this.f14720r.setActivated(z7);
    }

    public void L(boolean z7) {
        this.f14720r.setCheckable(z7);
    }

    public void M(int i7) {
        N(i7 != 0 ? getResources().getText(i7) : null);
    }

    public void N(CharSequence charSequence) {
        if (l() != charSequence) {
            this.f14720r.setContentDescription(charSequence);
        }
    }

    public void O(int i7) {
        P(i7 != 0 ? AbstractC1244a.b(getContext(), i7) : null);
    }

    public void P(Drawable drawable) {
        this.f14720r.setImageDrawable(drawable);
        if (drawable != null) {
            t.a(this.f14714l, this.f14720r, this.f14724v, this.f14725w);
            G();
        }
    }

    public void Q(int i7) {
        if (this.f14722t == i7) {
            return;
        }
        o0(m());
        int i8 = this.f14722t;
        this.f14722t = i7;
        j(i8);
        V(i7 != 0);
        s sVarM = m();
        O(r(sVarM));
        M(sVarM.c());
        L(sVarM.l());
        if (!sVarM.i(this.f14714l.getBoxBackgroundMode())) {
            throw new IllegalStateException("The current box background mode " + this.f14714l.getBoxBackgroundMode() + " is not supported by the end icon mode " + i7);
        }
        n0(sVarM);
        R(sVarM.f());
        EditText editText = this.f14709B;
        if (editText != null) {
            sVarM.n(editText);
            c0(sVarM);
        }
        t.a(this.f14714l, this.f14720r, this.f14724v, this.f14725w);
        I(true);
    }

    public void R(View.OnClickListener onClickListener) {
        t.f(this.f14720r, onClickListener, this.f14726x);
    }

    public void S(View.OnLongClickListener onLongClickListener) {
        this.f14726x = onLongClickListener;
        t.g(this.f14720r, onLongClickListener);
    }

    public void T(ColorStateList colorStateList) {
        if (this.f14724v != colorStateList) {
            this.f14724v = colorStateList;
            t.a(this.f14714l, this.f14720r, colorStateList, this.f14725w);
        }
    }

    public void U(PorterDuff.Mode mode) {
        if (this.f14725w != mode) {
            this.f14725w = mode;
            t.a(this.f14714l, this.f14720r, this.f14724v, mode);
        }
    }

    public void V(boolean z7) {
        if (C() != z7) {
            this.f14720r.setVisibility(z7 ? 0 : 8);
            q0();
            s0();
            this.f14714l.k0();
        }
    }

    public void W(int i7) {
        X(i7 != 0 ? AbstractC1244a.b(getContext(), i7) : null);
        H();
    }

    public void X(Drawable drawable) {
        this.f14716n.setImageDrawable(drawable);
        r0();
        t.a(this.f14714l, this.f14716n, this.f14717o, this.f14718p);
    }

    public void Y(View.OnClickListener onClickListener) {
        t.f(this.f14716n, onClickListener, this.f14719q);
    }

    public void Z(View.OnLongClickListener onLongClickListener) {
        this.f14719q = onLongClickListener;
        t.g(this.f14716n, onLongClickListener);
    }

    public void a0(ColorStateList colorStateList) {
        if (this.f14717o != colorStateList) {
            this.f14717o = colorStateList;
            t.a(this.f14714l, this.f14716n, colorStateList, this.f14718p);
        }
    }

    public void b0(PorterDuff.Mode mode) {
        if (this.f14718p != mode) {
            this.f14718p = mode;
            t.a(this.f14714l, this.f14716n, this.f14717o, mode);
        }
    }

    public final void c0(s sVar) {
        if (this.f14709B == null) {
            return;
        }
        if (sVar.e() != null) {
            this.f14709B.setOnFocusChangeListener(sVar.e());
        }
        if (sVar.g() != null) {
            this.f14720r.setOnFocusChangeListener(sVar.g());
        }
    }

    public void d0(int i7) {
        e0(i7 != 0 ? getResources().getText(i7) : null);
    }

    public void e0(CharSequence charSequence) {
        this.f14720r.setContentDescription(charSequence);
    }

    public void f0(int i7) {
        g0(i7 != 0 ? AbstractC1244a.b(getContext(), i7) : null);
    }

    public final void g() {
        if (this.f14711D == null || this.f14710C == null || !W.P(this)) {
            return;
        }
        AbstractC0746c.a(this.f14710C, this.f14711D);
    }

    public void g0(Drawable drawable) {
        this.f14720r.setImageDrawable(drawable);
    }

    public void h() {
        this.f14720r.performClick();
        this.f14720r.jumpDrawablesToCurrentState();
    }

    public void h0(boolean z7) {
        if (z7 && this.f14722t != 1) {
            Q(1);
        } else {
            if (z7) {
                return;
            }
            Q(0);
        }
    }

    public final CheckableImageButton i(ViewGroup viewGroup, LayoutInflater layoutInflater, int i7) {
        CheckableImageButton checkableImageButton = (CheckableImageButton) layoutInflater.inflate(O2.g.f6865b, viewGroup, false);
        checkableImageButton.setId(i7);
        t.d(checkableImageButton);
        if (AbstractC0903c.g(getContext())) {
            AbstractC0721y.d((ViewGroup.MarginLayoutParams) checkableImageButton.getLayoutParams(), 0);
        }
        return checkableImageButton;
    }

    public void i0(ColorStateList colorStateList) {
        this.f14724v = colorStateList;
        t.a(this.f14714l, this.f14720r, colorStateList, this.f14725w);
    }

    public final void j(int i7) {
        Iterator it = this.f14723u.iterator();
        if (it.hasNext()) {
            android.support.v4.media.session.b.a(it.next());
            throw null;
        }
    }

    public void j0(PorterDuff.Mode mode) {
        this.f14725w = mode;
        t.a(this.f14714l, this.f14720r, this.f14724v, mode);
    }

    public CheckableImageButton k() {
        if (D()) {
            return this.f14716n;
        }
        if (x() && C()) {
            return this.f14720r;
        }
        return null;
    }

    public void k0(CharSequence charSequence) {
        this.f14727y = TextUtils.isEmpty(charSequence) ? null : charSequence;
        this.f14728z.setText(charSequence);
        t0();
    }

    public CharSequence l() {
        return this.f14720r.getContentDescription();
    }

    public void l0(int i7) {
        AbstractC0896h.n(this.f14728z, i7);
    }

    public s m() {
        return this.f14721s.c(this.f14722t);
    }

    public void m0(ColorStateList colorStateList) {
        this.f14728z.setTextColor(colorStateList);
    }

    public Drawable n() {
        return this.f14720r.getDrawable();
    }

    public final void n0(s sVar) {
        sVar.s();
        this.f14711D = sVar.h();
        g();
    }

    public int o() {
        return this.f14722t;
    }

    public final void o0(s sVar) {
        J();
        this.f14711D = null;
        sVar.u();
    }

    public CheckableImageButton p() {
        return this.f14720r;
    }

    public final void p0(boolean z7) {
        if (!z7 || n() == null) {
            t.a(this.f14714l, this.f14720r, this.f14724v, this.f14725w);
            return;
        }
        Drawable drawableMutate = P.a.r(n()).mutate();
        P.a.n(drawableMutate, this.f14714l.getErrorCurrentTextColors());
        this.f14720r.setImageDrawable(drawableMutate);
    }

    public Drawable q() {
        return this.f14716n.getDrawable();
    }

    public final void q0() {
        this.f14715m.setVisibility((this.f14720r.getVisibility() != 0 || D()) ? 8 : 0);
        setVisibility((C() || D() || !((this.f14727y == null || this.f14708A) ? 8 : false)) ? 0 : 8);
    }

    public final int r(s sVar) {
        int i7 = this.f14721s.f14734c;
        return i7 == 0 ? sVar.d() : i7;
    }

    public final void r0() {
        this.f14716n.setVisibility(q() != null && this.f14714l.M() && this.f14714l.a0() ? 0 : 8);
        q0();
        s0();
        if (x()) {
            return;
        }
        this.f14714l.k0();
    }

    public CharSequence s() {
        return this.f14720r.getContentDescription();
    }

    public void s0() {
        if (this.f14714l.f14677o == null) {
            return;
        }
        W.A0(this.f14728z, getContext().getResources().getDimensionPixelSize(O2.c.f6803s), this.f14714l.f14677o.getPaddingTop(), (C() || D()) ? 0 : W.E(this.f14714l.f14677o), this.f14714l.f14677o.getPaddingBottom());
    }

    public Drawable t() {
        return this.f14720r.getDrawable();
    }

    public final void t0() {
        int visibility = this.f14728z.getVisibility();
        int i7 = (this.f14727y == null || this.f14708A) ? 8 : 0;
        if (visibility != i7) {
            m().q(i7 == 0);
        }
        q0();
        this.f14728z.setVisibility(i7);
        this.f14714l.k0();
    }

    public CharSequence u() {
        return this.f14727y;
    }

    public ColorStateList v() {
        return this.f14728z.getTextColors();
    }

    public TextView w() {
        return this.f14728z;
    }

    public boolean x() {
        return this.f14722t != 0;
    }

    public final void y(d0 d0Var) {
        if (!d0Var.s(O2.j.f7025P5)) {
            if (d0Var.s(O2.j.f7268v5)) {
                this.f14724v = AbstractC0903c.b(getContext(), d0Var, O2.j.f7268v5);
            }
            if (d0Var.s(O2.j.f7275w5)) {
                this.f14725w = l.f(d0Var.k(O2.j.f7275w5, -1), null);
            }
        }
        if (d0Var.s(O2.j.f7261u5)) {
            Q(d0Var.k(O2.j.f7261u5, 0));
            if (d0Var.s(O2.j.f7246s5)) {
                N(d0Var.p(O2.j.f7246s5));
            }
            L(d0Var.a(O2.j.f7238r5, true));
            return;
        }
        if (d0Var.s(O2.j.f7025P5)) {
            if (d0Var.s(O2.j.f7032Q5)) {
                this.f14724v = AbstractC0903c.b(getContext(), d0Var, O2.j.f7032Q5);
            }
            if (d0Var.s(O2.j.f7039R5)) {
                this.f14725w = l.f(d0Var.k(O2.j.f7039R5, -1), null);
            }
            Q(d0Var.a(O2.j.f7025P5, false) ? 1 : 0);
            N(d0Var.p(O2.j.f7011N5));
        }
    }

    public final void z(d0 d0Var) {
        if (d0Var.s(O2.j.f6920A5)) {
            this.f14717o = AbstractC0903c.b(getContext(), d0Var, O2.j.f6920A5);
        }
        if (d0Var.s(O2.j.f6927B5)) {
            this.f14718p = l.f(d0Var.k(O2.j.f6927B5, -1), null);
        }
        if (d0Var.s(O2.j.f7296z5)) {
            X(d0Var.g(O2.j.f7296z5));
        }
        this.f14716n.setContentDescription(getResources().getText(h.f6887f));
        W.v0(this.f14716n, 2);
        this.f14716n.setClickable(false);
        this.f14716n.setPressable(false);
        this.f14716n.setFocusable(false);
    }
}
