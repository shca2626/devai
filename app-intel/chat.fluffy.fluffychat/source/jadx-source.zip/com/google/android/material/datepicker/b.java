package com.google.android.material.datepicker;

import Z.W;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.widget.TextView;
import c3.AbstractC0903c;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final Rect f14465a;

    /* renamed from: b, reason: collision with root package name */
    public final ColorStateList f14466b;

    /* renamed from: c, reason: collision with root package name */
    public final ColorStateList f14467c;

    /* renamed from: d, reason: collision with root package name */
    public final ColorStateList f14468d;

    /* renamed from: e, reason: collision with root package name */
    public final int f14469e;

    /* renamed from: f, reason: collision with root package name */
    public final f3.k f14470f;

    public b(ColorStateList colorStateList, ColorStateList colorStateList2, ColorStateList colorStateList3, int i7, f3.k kVar, Rect rect) {
        Y.h.g(rect.left);
        Y.h.g(rect.top);
        Y.h.g(rect.right);
        Y.h.g(rect.bottom);
        this.f14465a = rect;
        this.f14466b = colorStateList2;
        this.f14467c = colorStateList;
        this.f14468d = colorStateList3;
        this.f14469e = i7;
        this.f14470f = kVar;
    }

    public static b a(Context context, int i7) throws Resources.NotFoundException {
        Y.h.a(i7 != 0, "Cannot create a CalendarItemStyle with a styleResId of 0");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i7, O2.j.f6938D2);
        Rect rect = new Rect(typedArrayObtainStyledAttributes.getDimensionPixelOffset(O2.j.f6945E2, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(O2.j.f6959G2, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(O2.j.f6952F2, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(O2.j.f6966H2, 0));
        ColorStateList colorStateListA = AbstractC0903c.a(context, typedArrayObtainStyledAttributes, O2.j.f6973I2);
        ColorStateList colorStateListA2 = AbstractC0903c.a(context, typedArrayObtainStyledAttributes, O2.j.f7008N2);
        ColorStateList colorStateListA3 = AbstractC0903c.a(context, typedArrayObtainStyledAttributes, O2.j.f6994L2);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(O2.j.f7001M2, 0);
        f3.k kVarM = f3.k.b(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f6980J2, 0), typedArrayObtainStyledAttributes.getResourceId(O2.j.f6987K2, 0)).m();
        typedArrayObtainStyledAttributes.recycle();
        return new b(colorStateListA, colorStateListA2, colorStateListA3, dimensionPixelSize, kVarM, rect);
    }

    public void b(TextView textView) {
        f3.g gVar = new f3.g();
        f3.g gVar2 = new f3.g();
        gVar.setShapeAppearanceModel(this.f14470f);
        gVar2.setShapeAppearanceModel(this.f14470f);
        gVar.U(this.f14467c);
        gVar.Z(this.f14469e, this.f14468d);
        textView.setTextColor(this.f14466b);
        RippleDrawable rippleDrawable = new RippleDrawable(this.f14466b.withAlpha(30), gVar, gVar2);
        Rect rect = this.f14465a;
        W.p0(textView, new InsetDrawable((Drawable) rippleDrawable, rect.left, rect.top, rect.right, rect.bottom));
    }
}
