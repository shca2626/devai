package com.google.android.material.datepicker;

import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class j<S> extends o {

    /* renamed from: r0, reason: collision with root package name */
    public int f14548r0;

    /* renamed from: s0, reason: collision with root package name */
    public com.google.android.material.datepicker.a f14549s0;

    public class a extends n {
        public a() {
        }
    }

    public static j j2(d dVar, int i7, com.google.android.material.datepicker.a aVar) {
        j jVar = new j();
        Bundle bundle = new Bundle();
        bundle.putInt("THEME_RES_ID_KEY", i7);
        bundle.putParcelable("DATE_SELECTOR_KEY", dVar);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", aVar);
        jVar.Y1(bundle);
        return jVar;
    }

    @Override // r0.ComponentCallbacksC1549q
    public void Q0(Bundle bundle) {
        super.Q0(bundle);
        if (bundle == null) {
            bundle = V();
        }
        this.f14548r0 = bundle.getInt("THEME_RES_ID_KEY");
        android.support.v4.media.session.b.a(bundle.getParcelable("DATE_SELECTOR_KEY"));
        this.f14549s0 = (com.google.android.material.datepicker.a) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
    }

    @Override // r0.ComponentCallbacksC1549q
    public View U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater.cloneInContext(new ContextThemeWrapper(getContext(), this.f14548r0));
        new a();
        throw null;
    }

    @Override // r0.ComponentCallbacksC1549q
    public void m1(Bundle bundle) {
        super.m1(bundle);
        bundle.putInt("THEME_RES_ID_KEY", this.f14548r0);
        bundle.putParcelable("DATE_SELECTOR_KEY", null);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", this.f14549s0);
    }
}
