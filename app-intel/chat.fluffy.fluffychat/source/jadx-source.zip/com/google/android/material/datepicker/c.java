package com.google.android.material.datepicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import c3.AbstractC0903c;
import c3.C0902b;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final b f14471a;

    /* renamed from: b, reason: collision with root package name */
    public final b f14472b;

    /* renamed from: c, reason: collision with root package name */
    public final b f14473c;

    /* renamed from: d, reason: collision with root package name */
    public final b f14474d;

    /* renamed from: e, reason: collision with root package name */
    public final b f14475e;

    /* renamed from: f, reason: collision with root package name */
    public final b f14476f;

    /* renamed from: g, reason: collision with root package name */
    public final b f14477g;

    /* renamed from: h, reason: collision with root package name */
    public final Paint f14478h;

    public c(Context context) throws Resources.NotFoundException {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(C0902b.c(context, O2.a.f6758u, h.class.getCanonicalName()), O2.j.f7258u2);
        this.f14471a = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f7279x2, 0));
        this.f14477g = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f7265v2, 0));
        this.f14472b = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f7272w2, 0));
        this.f14473c = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f7286y2, 0));
        ColorStateList colorStateListA = AbstractC0903c.a(context, typedArrayObtainStyledAttributes, O2.j.f7293z2);
        this.f14474d = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f6924B2, 0));
        this.f14475e = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f6917A2, 0));
        this.f14476f = b.a(context, typedArrayObtainStyledAttributes.getResourceId(O2.j.f6931C2, 0));
        Paint paint = new Paint();
        this.f14478h = paint;
        paint.setColor(colorStateListA.getDefaultColor());
        typedArrayObtainStyledAttributes.recycle();
    }
}
