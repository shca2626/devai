package com.google.android.material.timepicker;

import O2.j;
import Z.W;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import f3.g;
import f3.i;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.dex */
public abstract class c extends ConstraintLayout {

    /* renamed from: J, reason: collision with root package name */
    public final Runnable f14788J;

    /* renamed from: K, reason: collision with root package name */
    public int f14789K;

    /* renamed from: L, reason: collision with root package name */
    public g f14790L;

    public c(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        LayoutInflater.from(context).inflate(O2.g.f6869f, this);
        W.p0(this, t());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.f6995L3, i7, 0);
        this.f14789K = typedArrayObtainStyledAttributes.getDimensionPixelSize(j.f7002M3, 0);
        this.f14788J = new Runnable() { // from class: com.google.android.material.timepicker.b
            @Override // java.lang.Runnable
            public final void run() throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
                this.f14787l.x();
            }
        };
        typedArrayObtainStyledAttributes.recycle();
    }

    public static boolean w(View view) {
        return "skip".equals(view.getTag());
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public void addView(View view, int i7, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i7, layoutParams);
        if (view.getId() == -1) {
            view.setId(W.k());
        }
        y();
    }

    @Override // android.view.View
    public void onFinishInflate() throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        super.onFinishInflate();
        x();
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        y();
    }

    @Override // android.view.View
    public void setBackgroundColor(int i7) {
        this.f14790L.U(ColorStateList.valueOf(i7));
    }

    public final Drawable t() {
        g gVar = new g();
        this.f14790L = gVar;
        gVar.S(new i(0.5f));
        this.f14790L.U(ColorStateList.valueOf(-1));
        return this.f14790L;
    }

    public int u() {
        return this.f14789K;
    }

    public void v(int i7) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        this.f14789K = i7;
        x();
    }

    public void x() throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        int childCount = getChildCount();
        int i7 = 1;
        for (int i8 = 0; i8 < childCount; i8++) {
            if (w(getChildAt(i8))) {
                i7++;
            }
        }
        androidx.constraintlayout.widget.c cVar = new androidx.constraintlayout.widget.c();
        cVar.g(this);
        float f7 = 0.0f;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getId() != O2.e.f6839c && !w(childAt)) {
                cVar.h(childAt.getId(), O2.e.f6839c, this.f14789K, f7);
                f7 += 360.0f / (childCount - i7);
            }
        }
        cVar.c(this);
    }

    public final void y() {
        Handler handler = getHandler();
        if (handler != null) {
            handler.removeCallbacks(this.f14788J);
            handler.post(this.f14788J);
        }
    }
}
