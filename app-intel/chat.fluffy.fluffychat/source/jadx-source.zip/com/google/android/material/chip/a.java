package com.google.android.material.chip;

import O.AbstractC0562a;
import O2.j;
import P2.c;
import V2.b;
import a3.i;
import a3.k;
import a3.l;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.text.TextUtils;
import android.util.AttributeSet;
import c3.AbstractC0903c;
import c3.C0904d;
import d3.AbstractC0990b;
import f3.g;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import k.AbstractC1244a;

/* loaded from: classes.dex */
public class a extends g implements Drawable.Callback, i.b {

    /* renamed from: U0, reason: collision with root package name */
    public static final int[] f14384U0 = {R.attr.state_enabled};

    /* renamed from: V0, reason: collision with root package name */
    public static final ShapeDrawable f14385V0 = new ShapeDrawable(new OvalShape());

    /* renamed from: A0, reason: collision with root package name */
    public int f14386A0;

    /* renamed from: B0, reason: collision with root package name */
    public int f14387B0;

    /* renamed from: C0, reason: collision with root package name */
    public int f14388C0;

    /* renamed from: D0, reason: collision with root package name */
    public int f14389D0;

    /* renamed from: E0, reason: collision with root package name */
    public int f14390E0;

    /* renamed from: F0, reason: collision with root package name */
    public boolean f14391F0;

    /* renamed from: G0, reason: collision with root package name */
    public int f14392G0;

    /* renamed from: H0, reason: collision with root package name */
    public int f14393H0;

    /* renamed from: I0, reason: collision with root package name */
    public ColorFilter f14394I0;

    /* renamed from: J0, reason: collision with root package name */
    public PorterDuffColorFilter f14395J0;

    /* renamed from: K, reason: collision with root package name */
    public ColorStateList f14396K;

    /* renamed from: K0, reason: collision with root package name */
    public ColorStateList f14397K0;

    /* renamed from: L, reason: collision with root package name */
    public ColorStateList f14398L;

    /* renamed from: L0, reason: collision with root package name */
    public PorterDuff.Mode f14399L0;

    /* renamed from: M, reason: collision with root package name */
    public float f14400M;

    /* renamed from: M0, reason: collision with root package name */
    public int[] f14401M0;

    /* renamed from: N, reason: collision with root package name */
    public float f14402N;

    /* renamed from: N0, reason: collision with root package name */
    public boolean f14403N0;

    /* renamed from: O, reason: collision with root package name */
    public ColorStateList f14404O;

    /* renamed from: O0, reason: collision with root package name */
    public ColorStateList f14405O0;

    /* renamed from: P, reason: collision with root package name */
    public float f14406P;

    /* renamed from: P0, reason: collision with root package name */
    public WeakReference f14407P0;

    /* renamed from: Q, reason: collision with root package name */
    public ColorStateList f14408Q;

    /* renamed from: Q0, reason: collision with root package name */
    public TextUtils.TruncateAt f14409Q0;

    /* renamed from: R, reason: collision with root package name */
    public CharSequence f14410R;

    /* renamed from: R0, reason: collision with root package name */
    public boolean f14411R0;

    /* renamed from: S, reason: collision with root package name */
    public boolean f14412S;

    /* renamed from: S0, reason: collision with root package name */
    public int f14413S0;

    /* renamed from: T, reason: collision with root package name */
    public Drawable f14414T;

    /* renamed from: T0, reason: collision with root package name */
    public boolean f14415T0;

    /* renamed from: U, reason: collision with root package name */
    public ColorStateList f14416U;

    /* renamed from: V, reason: collision with root package name */
    public float f14417V;

    /* renamed from: W, reason: collision with root package name */
    public boolean f14418W;

    /* renamed from: X, reason: collision with root package name */
    public boolean f14419X;

    /* renamed from: Y, reason: collision with root package name */
    public Drawable f14420Y;

    /* renamed from: Z, reason: collision with root package name */
    public Drawable f14421Z;

    /* renamed from: a0, reason: collision with root package name */
    public ColorStateList f14422a0;

    /* renamed from: b0, reason: collision with root package name */
    public float f14423b0;

    /* renamed from: c0, reason: collision with root package name */
    public CharSequence f14424c0;

    /* renamed from: d0, reason: collision with root package name */
    public boolean f14425d0;

    /* renamed from: e0, reason: collision with root package name */
    public boolean f14426e0;

    /* renamed from: f0, reason: collision with root package name */
    public Drawable f14427f0;

    /* renamed from: g0, reason: collision with root package name */
    public ColorStateList f14428g0;

    /* renamed from: h0, reason: collision with root package name */
    public c f14429h0;

    /* renamed from: i0, reason: collision with root package name */
    public c f14430i0;

    /* renamed from: j0, reason: collision with root package name */
    public float f14431j0;

    /* renamed from: k0, reason: collision with root package name */
    public float f14432k0;

    /* renamed from: l0, reason: collision with root package name */
    public float f14433l0;

    /* renamed from: m0, reason: collision with root package name */
    public float f14434m0;

    /* renamed from: n0, reason: collision with root package name */
    public float f14435n0;

    /* renamed from: o0, reason: collision with root package name */
    public float f14436o0;

    /* renamed from: p0, reason: collision with root package name */
    public float f14437p0;

    /* renamed from: q0, reason: collision with root package name */
    public float f14438q0;

    /* renamed from: r0, reason: collision with root package name */
    public final Context f14439r0;

    /* renamed from: s0, reason: collision with root package name */
    public final Paint f14440s0;

    /* renamed from: t0, reason: collision with root package name */
    public final Paint f14441t0;

    /* renamed from: u0, reason: collision with root package name */
    public final Paint.FontMetrics f14442u0;

    /* renamed from: v0, reason: collision with root package name */
    public final RectF f14443v0;

    /* renamed from: w0, reason: collision with root package name */
    public final PointF f14444w0;

    /* renamed from: x0, reason: collision with root package name */
    public final Path f14445x0;

    /* renamed from: y0, reason: collision with root package name */
    public final i f14446y0;

    /* renamed from: z0, reason: collision with root package name */
    public int f14447z0;

    /* renamed from: com.google.android.material.chip.a$a, reason: collision with other inner class name */
    public interface InterfaceC0142a {
        void a();
    }

    public a(Context context, AttributeSet attributeSet, int i7, int i8) {
        super(context, attributeSet, i7, i8);
        this.f14402N = -1.0f;
        this.f14440s0 = new Paint(1);
        this.f14442u0 = new Paint.FontMetrics();
        this.f14443v0 = new RectF();
        this.f14444w0 = new PointF();
        this.f14445x0 = new Path();
        this.f14393H0 = 255;
        this.f14399L0 = PorterDuff.Mode.SRC_IN;
        this.f14407P0 = new WeakReference(null);
        K(context);
        this.f14439r0 = context;
        i iVar = new i(this);
        this.f14446y0 = iVar;
        this.f14410R = "";
        iVar.e().density = context.getResources().getDisplayMetrics().density;
        this.f14441t0 = null;
        int[] iArr = f14384U0;
        setState(iArr);
        g2(iArr);
        this.f14411R0 = true;
        if (AbstractC0990b.f15163a) {
            f14385V0.setTint(-1);
        }
    }

    public static boolean i1(int[] iArr, int i7) {
        if (iArr == null) {
            return false;
        }
        for (int i8 : iArr) {
            if (i8 == i7) {
                return true;
            }
        }
        return false;
    }

    public static boolean m1(ColorStateList colorStateList) {
        return colorStateList != null && colorStateList.isStateful();
    }

    public static boolean n1(Drawable drawable) {
        return drawable != null && drawable.isStateful();
    }

    public static boolean o1(C0904d c0904d) {
        return (c0904d == null || c0904d.i() == null || !c0904d.i().isStateful()) ? false : true;
    }

    public static a q0(Context context, AttributeSet attributeSet, int i7, int i8) {
        a aVar = new a(context, attributeSet, i7, i8);
        aVar.p1(attributeSet, i7, i8);
        return aVar;
    }

    public Drawable A0() {
        return this.f14427f0;
    }

    public void A1(ColorStateList colorStateList) {
        if (this.f14398L != colorStateList) {
            this.f14398L = colorStateList;
            onStateChange(getState());
        }
    }

    public void A2(int i7) {
        z2(new C0904d(this.f14439r0, i7));
    }

    public ColorStateList B0() {
        return this.f14428g0;
    }

    public void B1(int i7) {
        A1(AbstractC1244a.a(this.f14439r0, i7));
    }

    public void B2(float f7) {
        if (this.f14435n0 != f7) {
            this.f14435n0 = f7;
            invalidateSelf();
            q1();
        }
    }

    public ColorStateList C0() {
        return this.f14398L;
    }

    public void C1(float f7) {
        if (this.f14402N != f7) {
            this.f14402N = f7;
            setShapeAppearanceModel(B().w(f7));
        }
    }

    public void C2(int i7) {
        B2(this.f14439r0.getResources().getDimension(i7));
    }

    public float D0() {
        return this.f14415T0 ? D() : this.f14402N;
    }

    public void D1(int i7) {
        C1(this.f14439r0.getResources().getDimension(i7));
    }

    public void D2(float f7) {
        C0904d c0904dD1 = d1();
        if (c0904dD1 != null) {
            c0904dD1.l(f7);
            this.f14446y0.e().setTextSize(f7);
            a();
        }
    }

    public float E0() {
        return this.f14438q0;
    }

    public void E1(float f7) {
        if (this.f14438q0 != f7) {
            this.f14438q0 = f7;
            invalidateSelf();
            q1();
        }
    }

    public void E2(float f7) {
        if (this.f14434m0 != f7) {
            this.f14434m0 = f7;
            invalidateSelf();
            q1();
        }
    }

    public Drawable F0() {
        Drawable drawable = this.f14414T;
        if (drawable != null) {
            return P.a.q(drawable);
        }
        return null;
    }

    public void F1(int i7) {
        E1(this.f14439r0.getResources().getDimension(i7));
    }

    public void F2(int i7) {
        E2(this.f14439r0.getResources().getDimension(i7));
    }

    public float G0() {
        return this.f14417V;
    }

    public void G1(Drawable drawable) {
        Drawable drawableF0 = F0();
        if (drawableF0 != drawable) {
            float fH0 = h0();
            this.f14414T = drawable != null ? P.a.r(drawable).mutate() : null;
            float fH02 = h0();
            L2(drawableF0);
            if (J2()) {
                f0(this.f14414T);
            }
            invalidateSelf();
            if (fH0 != fH02) {
                q1();
            }
        }
    }

    public void G2(boolean z7) {
        if (this.f14403N0 != z7) {
            this.f14403N0 = z7;
            M2();
            onStateChange(getState());
        }
    }

    public ColorStateList H0() {
        return this.f14416U;
    }

    public void H1(int i7) {
        G1(AbstractC1244a.b(this.f14439r0, i7));
    }

    public boolean H2() {
        return this.f14411R0;
    }

    public float I0() {
        return this.f14400M;
    }

    public void I1(float f7) {
        if (this.f14417V != f7) {
            float fH0 = h0();
            this.f14417V = f7;
            float fH02 = h0();
            invalidateSelf();
            if (fH0 != fH02) {
                q1();
            }
        }
    }

    public final boolean I2() {
        return this.f14426e0 && this.f14427f0 != null && this.f14391F0;
    }

    public float J0() {
        return this.f14431j0;
    }

    public void J1(int i7) {
        I1(this.f14439r0.getResources().getDimension(i7));
    }

    public final boolean J2() {
        return this.f14412S && this.f14414T != null;
    }

    public ColorStateList K0() {
        return this.f14404O;
    }

    public void K1(ColorStateList colorStateList) {
        this.f14418W = true;
        if (this.f14416U != colorStateList) {
            this.f14416U = colorStateList;
            if (J2()) {
                P.a.o(this.f14414T, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public final boolean K2() {
        return this.f14419X && this.f14420Y != null;
    }

    public float L0() {
        return this.f14406P;
    }

    public void L1(int i7) {
        K1(AbstractC1244a.a(this.f14439r0, i7));
    }

    public final void L2(Drawable drawable) {
        if (drawable != null) {
            drawable.setCallback(null);
        }
    }

    public Drawable M0() {
        Drawable drawable = this.f14420Y;
        if (drawable != null) {
            return P.a.q(drawable);
        }
        return null;
    }

    public void M1(int i7) {
        N1(this.f14439r0.getResources().getBoolean(i7));
    }

    public final void M2() {
        this.f14405O0 = this.f14403N0 ? AbstractC0990b.a(this.f14408Q) : null;
    }

    public CharSequence N0() {
        return this.f14424c0;
    }

    public void N1(boolean z7) {
        if (this.f14412S != z7) {
            boolean zJ2 = J2();
            this.f14412S = z7;
            boolean zJ22 = J2();
            if (zJ2 != zJ22) {
                if (zJ22) {
                    f0(this.f14414T);
                } else {
                    L2(this.f14414T);
                }
                invalidateSelf();
                q1();
            }
        }
    }

    public final void N2() {
        this.f14421Z = new RippleDrawable(AbstractC0990b.a(a1()), this.f14420Y, f14385V0);
    }

    public float O0() {
        return this.f14437p0;
    }

    public void O1(float f7) {
        if (this.f14400M != f7) {
            this.f14400M = f7;
            invalidateSelf();
            q1();
        }
    }

    public float P0() {
        return this.f14423b0;
    }

    public void P1(int i7) {
        O1(this.f14439r0.getResources().getDimension(i7));
    }

    public float Q0() {
        return this.f14436o0;
    }

    public void Q1(float f7) {
        if (this.f14431j0 != f7) {
            this.f14431j0 = f7;
            invalidateSelf();
            q1();
        }
    }

    public int[] R0() {
        return this.f14401M0;
    }

    public void R1(int i7) {
        Q1(this.f14439r0.getResources().getDimension(i7));
    }

    public ColorStateList S0() {
        return this.f14422a0;
    }

    public void S1(ColorStateList colorStateList) {
        if (this.f14404O != colorStateList) {
            this.f14404O = colorStateList;
            if (this.f14415T0) {
                a0(colorStateList);
            }
            onStateChange(getState());
        }
    }

    public void T0(RectF rectF) {
        k0(getBounds(), rectF);
    }

    public void T1(int i7) {
        S1(AbstractC1244a.a(this.f14439r0, i7));
    }

    public final float U0() {
        Drawable drawable = this.f14391F0 ? this.f14427f0 : this.f14414T;
        float fCeil = this.f14417V;
        if (fCeil <= 0.0f && drawable != null) {
            fCeil = (float) Math.ceil(l.b(this.f14439r0, 24));
            if (drawable.getIntrinsicHeight() <= fCeil) {
                return drawable.getIntrinsicHeight();
            }
        }
        return fCeil;
    }

    public void U1(float f7) {
        if (this.f14406P != f7) {
            this.f14406P = f7;
            this.f14440s0.setStrokeWidth(f7);
            if (this.f14415T0) {
                super.b0(f7);
            }
            invalidateSelf();
        }
    }

    public final float V0() {
        Drawable drawable = this.f14391F0 ? this.f14427f0 : this.f14414T;
        float f7 = this.f14417V;
        return (f7 > 0.0f || drawable == null) ? f7 : drawable.getIntrinsicWidth();
    }

    public void V1(int i7) {
        U1(this.f14439r0.getResources().getDimension(i7));
    }

    public TextUtils.TruncateAt W0() {
        return this.f14409Q0;
    }

    public final void W1(ColorStateList colorStateList) {
        if (this.f14396K != colorStateList) {
            this.f14396K = colorStateList;
            onStateChange(getState());
        }
    }

    public c X0() {
        return this.f14430i0;
    }

    public void X1(Drawable drawable) {
        Drawable drawableM0 = M0();
        if (drawableM0 != drawable) {
            float fL0 = l0();
            this.f14420Y = drawable != null ? P.a.r(drawable).mutate() : null;
            if (AbstractC0990b.f15163a) {
                N2();
            }
            float fL02 = l0();
            L2(drawableM0);
            if (K2()) {
                f0(this.f14420Y);
            }
            invalidateSelf();
            if (fL0 != fL02) {
                q1();
            }
        }
    }

    public float Y0() {
        return this.f14433l0;
    }

    public void Y1(CharSequence charSequence) {
        if (this.f14424c0 != charSequence) {
            this.f14424c0 = X.a.c().h(charSequence);
            invalidateSelf();
        }
    }

    public float Z0() {
        return this.f14432k0;
    }

    public void Z1(float f7) {
        if (this.f14437p0 != f7) {
            this.f14437p0 = f7;
            invalidateSelf();
            if (K2()) {
                q1();
            }
        }
    }

    @Override // a3.i.b
    public void a() {
        q1();
        invalidateSelf();
    }

    public ColorStateList a1() {
        return this.f14408Q;
    }

    public void a2(int i7) {
        Z1(this.f14439r0.getResources().getDimension(i7));
    }

    public c b1() {
        return this.f14429h0;
    }

    public void b2(int i7) {
        X1(AbstractC1244a.b(this.f14439r0, i7));
    }

    public CharSequence c1() {
        return this.f14410R;
    }

    public void c2(float f7) {
        if (this.f14423b0 != f7) {
            this.f14423b0 = f7;
            invalidateSelf();
            if (K2()) {
                q1();
            }
        }
    }

    public C0904d d1() {
        return this.f14446y0.d();
    }

    public void d2(int i7) {
        c2(this.f14439r0.getResources().getDimension(i7));
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Canvas canvas2;
        int iA;
        Rect bounds = getBounds();
        if (bounds.isEmpty() || getAlpha() == 0) {
            return;
        }
        int i7 = this.f14393H0;
        if (i7 < 255) {
            canvas2 = canvas;
            iA = S2.a.a(canvas2, bounds.left, bounds.top, bounds.right, bounds.bottom, i7);
        } else {
            canvas2 = canvas;
            iA = 0;
        }
        v0(canvas2, bounds);
        s0(canvas2, bounds);
        if (this.f14415T0) {
            super.draw(canvas2);
        }
        u0(canvas2, bounds);
        x0(canvas2, bounds);
        t0(canvas2, bounds);
        r0(canvas2, bounds);
        if (this.f14411R0) {
            z0(canvas2, bounds);
        }
        w0(canvas2, bounds);
        y0(canvas2, bounds);
        if (this.f14393H0 < 255) {
            canvas2.restoreToCount(iA);
        }
    }

    public float e1() {
        return this.f14435n0;
    }

    public void e2(float f7) {
        if (this.f14436o0 != f7) {
            this.f14436o0 = f7;
            invalidateSelf();
            if (K2()) {
                q1();
            }
        }
    }

    public final void f0(Drawable drawable) {
        if (drawable == null) {
            return;
        }
        drawable.setCallback(this);
        P.a.m(drawable, P.a.f(this));
        drawable.setLevel(getLevel());
        drawable.setVisible(isVisible(), false);
        if (drawable == this.f14420Y) {
            if (drawable.isStateful()) {
                drawable.setState(R0());
            }
            P.a.o(drawable, this.f14422a0);
            return;
        }
        Drawable drawable2 = this.f14414T;
        if (drawable == drawable2 && this.f14418W) {
            P.a.o(drawable2, this.f14416U);
        }
        if (drawable.isStateful()) {
            drawable.setState(getState());
        }
    }

    public float f1() {
        return this.f14434m0;
    }

    public void f2(int i7) {
        e2(this.f14439r0.getResources().getDimension(i7));
    }

    public final void g0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (J2() || I2()) {
            float f7 = this.f14431j0 + this.f14432k0;
            float fV0 = V0();
            if (P.a.f(this) == 0) {
                float f8 = rect.left + f7;
                rectF.left = f8;
                rectF.right = f8 + fV0;
            } else {
                float f9 = rect.right - f7;
                rectF.right = f9;
                rectF.left = f9 - fV0;
            }
            float fU0 = U0();
            float fExactCenterY = rect.exactCenterY() - (fU0 / 2.0f);
            rectF.top = fExactCenterY;
            rectF.bottom = fExactCenterY + fU0;
        }
    }

    public final ColorFilter g1() {
        ColorFilter colorFilter = this.f14394I0;
        return colorFilter != null ? colorFilter : this.f14395J0;
    }

    public boolean g2(int[] iArr) {
        if (Arrays.equals(this.f14401M0, iArr)) {
            return false;
        }
        this.f14401M0 = iArr;
        if (K2()) {
            return r1(getState(), iArr);
        }
        return false;
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.f14393H0;
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        return this.f14394I0;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return (int) this.f14400M;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return Math.min(Math.round(this.f14431j0 + h0() + this.f14434m0 + this.f14446y0.f(c1().toString()) + this.f14435n0 + l0() + this.f14438q0), this.f14413S0);
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public void getOutline(Outline outline) {
        Outline outline2;
        if (this.f14415T0) {
            super.getOutline(outline);
            return;
        }
        Rect bounds = getBounds();
        if (bounds.isEmpty()) {
            outline2 = outline;
            outline2.setRoundRect(0, 0, getIntrinsicWidth(), getIntrinsicHeight(), this.f14402N);
        } else {
            outline.setRoundRect(bounds, this.f14402N);
            outline2 = outline;
        }
        outline2.setAlpha(getAlpha() / 255.0f);
    }

    public float h0() {
        if (J2() || I2()) {
            return this.f14432k0 + V0() + this.f14433l0;
        }
        return 0.0f;
    }

    public boolean h1() {
        return this.f14403N0;
    }

    public void h2(ColorStateList colorStateList) {
        if (this.f14422a0 != colorStateList) {
            this.f14422a0 = colorStateList;
            if (K2()) {
                P.a.o(this.f14420Y, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public final void i0(Rect rect, RectF rectF) {
        rectF.set(rect);
        if (K2()) {
            float f7 = this.f14438q0 + this.f14437p0 + this.f14423b0 + this.f14436o0 + this.f14435n0;
            if (P.a.f(this) == 0) {
                rectF.right = rect.right - f7;
            } else {
                rectF.left = rect.left + f7;
            }
        }
    }

    public void i2(int i7) {
        h2(AbstractC1244a.a(this.f14439r0, i7));
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void invalidateDrawable(Drawable drawable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public boolean isStateful() {
        if (m1(this.f14396K) || m1(this.f14398L) || m1(this.f14404O)) {
            return true;
        }
        return (this.f14403N0 && m1(this.f14405O0)) || o1(this.f14446y0.d()) || p0() || n1(this.f14414T) || n1(this.f14427f0) || m1(this.f14397K0);
    }

    public final void j0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (K2()) {
            float f7 = this.f14438q0 + this.f14437p0;
            if (P.a.f(this) == 0) {
                float f8 = rect.right - f7;
                rectF.right = f8;
                rectF.left = f8 - this.f14423b0;
            } else {
                float f9 = rect.left + f7;
                rectF.left = f9;
                rectF.right = f9 + this.f14423b0;
            }
            float fExactCenterY = rect.exactCenterY();
            float f10 = this.f14423b0;
            float f11 = fExactCenterY - (f10 / 2.0f);
            rectF.top = f11;
            rectF.bottom = f11 + f10;
        }
    }

    public boolean j1() {
        return this.f14425d0;
    }

    public void j2(boolean z7) {
        if (this.f14419X != z7) {
            boolean zK2 = K2();
            this.f14419X = z7;
            boolean zK22 = K2();
            if (zK2 != zK22) {
                if (zK22) {
                    f0(this.f14420Y);
                } else {
                    L2(this.f14420Y);
                }
                invalidateSelf();
                q1();
            }
        }
    }

    public final void k0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (K2()) {
            float f7 = this.f14438q0 + this.f14437p0 + this.f14423b0 + this.f14436o0 + this.f14435n0;
            if (P.a.f(this) == 0) {
                float f8 = rect.right;
                rectF.right = f8;
                rectF.left = f8 - f7;
            } else {
                int i7 = rect.left;
                rectF.left = i7;
                rectF.right = i7 + f7;
            }
            rectF.top = rect.top;
            rectF.bottom = rect.bottom;
        }
    }

    public boolean k1() {
        return n1(this.f14420Y);
    }

    public void k2(InterfaceC0142a interfaceC0142a) {
        this.f14407P0 = new WeakReference(interfaceC0142a);
    }

    public float l0() {
        if (K2()) {
            return this.f14436o0 + this.f14423b0 + this.f14437p0;
        }
        return 0.0f;
    }

    public boolean l1() {
        return this.f14419X;
    }

    public void l2(TextUtils.TruncateAt truncateAt) {
        this.f14409Q0 = truncateAt;
    }

    public final void m0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (this.f14410R != null) {
            float fH0 = this.f14431j0 + h0() + this.f14434m0;
            float fL0 = this.f14438q0 + l0() + this.f14435n0;
            if (P.a.f(this) == 0) {
                rectF.left = rect.left + fH0;
                rectF.right = rect.right - fL0;
            } else {
                rectF.left = rect.left + fL0;
                rectF.right = rect.right - fH0;
            }
            rectF.top = rect.top;
            rectF.bottom = rect.bottom;
        }
    }

    public void m2(c cVar) {
        this.f14430i0 = cVar;
    }

    public final float n0() {
        this.f14446y0.e().getFontMetrics(this.f14442u0);
        Paint.FontMetrics fontMetrics = this.f14442u0;
        return (fontMetrics.descent + fontMetrics.ascent) / 2.0f;
    }

    public void n2(int i7) {
        m2(c.c(this.f14439r0, i7));
    }

    public Paint.Align o0(Rect rect, PointF pointF) {
        pointF.set(0.0f, 0.0f);
        Paint.Align align = Paint.Align.LEFT;
        if (this.f14410R != null) {
            float fH0 = this.f14431j0 + h0() + this.f14434m0;
            if (P.a.f(this) == 0) {
                pointF.x = rect.left + fH0;
            } else {
                pointF.x = rect.right - fH0;
                align = Paint.Align.RIGHT;
            }
            pointF.y = rect.centerY() - n0();
        }
        return align;
    }

    public void o2(float f7) {
        if (this.f14433l0 != f7) {
            float fH0 = h0();
            this.f14433l0 = f7;
            float fH02 = h0();
            invalidateSelf();
            if (fH0 != fH02) {
                q1();
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLayoutDirectionChanged(int i7) {
        boolean zOnLayoutDirectionChanged = super.onLayoutDirectionChanged(i7);
        if (J2()) {
            zOnLayoutDirectionChanged |= P.a.m(this.f14414T, i7);
        }
        if (I2()) {
            zOnLayoutDirectionChanged |= P.a.m(this.f14427f0, i7);
        }
        if (K2()) {
            zOnLayoutDirectionChanged |= P.a.m(this.f14420Y, i7);
        }
        if (!zOnLayoutDirectionChanged) {
            return true;
        }
        invalidateSelf();
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLevelChange(int i7) {
        boolean zOnLevelChange = super.onLevelChange(i7);
        if (J2()) {
            zOnLevelChange |= this.f14414T.setLevel(i7);
        }
        if (I2()) {
            zOnLevelChange |= this.f14427f0.setLevel(i7);
        }
        if (K2()) {
            zOnLevelChange |= this.f14420Y.setLevel(i7);
        }
        if (zOnLevelChange) {
            invalidateSelf();
        }
        return zOnLevelChange;
    }

    @Override // f3.g, android.graphics.drawable.Drawable, a3.i.b
    public boolean onStateChange(int[] iArr) {
        if (this.f14415T0) {
            super.onStateChange(iArr);
        }
        return r1(iArr, R0());
    }

    public final boolean p0() {
        return this.f14426e0 && this.f14427f0 != null && this.f14425d0;
    }

    public final void p1(AttributeSet attributeSet, int i7, int i8) {
        TypedArray typedArrayI = k.i(this.f14439r0, attributeSet, j.f7075X, i7, i8, new int[0]);
        this.f14415T0 = typedArrayI.hasValue(j.f6971I0);
        W1(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f7263v0));
        A1(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f7161i0));
        O1(typedArrayI.getDimension(j.f7225q0, 0.0f));
        if (typedArrayI.hasValue(j.f7169j0)) {
            C1(typedArrayI.getDimension(j.f7169j0, 0.0f));
        }
        S1(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f7249t0));
        U1(typedArrayI.getDimension(j.f7256u0, 0.0f));
        t2(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f6964H0));
        y2(typedArrayI.getText(j.f7113c0));
        C0904d c0904dF = AbstractC0903c.f(this.f14439r0, typedArrayI, j.f7082Y);
        c0904dF.l(typedArrayI.getDimension(j.f7089Z, c0904dF.j()));
        z2(c0904dF);
        int i9 = typedArrayI.getInt(j.f7097a0, 0);
        if (i9 == 1) {
            l2(TextUtils.TruncateAt.START);
        } else if (i9 == 2) {
            l2(TextUtils.TruncateAt.MIDDLE);
        } else if (i9 == 3) {
            l2(TextUtils.TruncateAt.END);
        }
        N1(typedArrayI.getBoolean(j.f7217p0, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconVisible") == null) {
            N1(typedArrayI.getBoolean(j.f7193m0, false));
        }
        G1(AbstractC0903c.d(this.f14439r0, typedArrayI, j.f7185l0));
        if (typedArrayI.hasValue(j.f7209o0)) {
            K1(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f7209o0));
        }
        I1(typedArrayI.getDimension(j.f7201n0, -1.0f));
        j2(typedArrayI.getBoolean(j.f6929C0, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconVisible") == null) {
            j2(typedArrayI.getBoolean(j.f7277x0, false));
        }
        X1(AbstractC0903c.d(this.f14439r0, typedArrayI, j.f7270w0));
        h2(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f6922B0));
        c2(typedArrayI.getDimension(j.f7291z0, 0.0f));
        s1(typedArrayI.getBoolean(j.f7121d0, false));
        z1(typedArrayI.getBoolean(j.f7153h0, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconVisible") == null) {
            z1(typedArrayI.getBoolean(j.f7137f0, false));
        }
        u1(AbstractC0903c.d(this.f14439r0, typedArrayI, j.f7129e0));
        if (typedArrayI.hasValue(j.f7145g0)) {
            w1(AbstractC0903c.a(this.f14439r0, typedArrayI, j.f7145g0));
        }
        w2(c.b(this.f14439r0, typedArrayI, j.f6978J0));
        m2(c.b(this.f14439r0, typedArrayI, j.f6943E0));
        Q1(typedArrayI.getDimension(j.f7241s0, 0.0f));
        q2(typedArrayI.getDimension(j.f6957G0, 0.0f));
        o2(typedArrayI.getDimension(j.f6950F0, 0.0f));
        E2(typedArrayI.getDimension(j.f6992L0, 0.0f));
        B2(typedArrayI.getDimension(j.f6985K0, 0.0f));
        e2(typedArrayI.getDimension(j.f6915A0, 0.0f));
        Z1(typedArrayI.getDimension(j.f7284y0, 0.0f));
        E1(typedArrayI.getDimension(j.f7177k0, 0.0f));
        s2(typedArrayI.getDimensionPixelSize(j.f7105b0, Integer.MAX_VALUE));
        typedArrayI.recycle();
    }

    public void p2(int i7) {
        o2(this.f14439r0.getResources().getDimension(i7));
    }

    public void q1() {
        InterfaceC0142a interfaceC0142a = (InterfaceC0142a) this.f14407P0.get();
        if (interfaceC0142a != null) {
            interfaceC0142a.a();
        }
    }

    public void q2(float f7) {
        if (this.f14432k0 != f7) {
            float fH0 = h0();
            this.f14432k0 = f7;
            float fH02 = h0();
            invalidateSelf();
            if (fH0 != fH02) {
                q1();
            }
        }
    }

    public final void r0(Canvas canvas, Rect rect) {
        if (I2()) {
            g0(rect, this.f14443v0);
            RectF rectF = this.f14443v0;
            float f7 = rectF.left;
            float f8 = rectF.top;
            canvas.translate(f7, f8);
            this.f14427f0.setBounds(0, 0, (int) this.f14443v0.width(), (int) this.f14443v0.height());
            this.f14427f0.draw(canvas);
            canvas.translate(-f7, -f8);
        }
    }

    public final boolean r1(int[] iArr, int[] iArr2) {
        boolean z7;
        boolean zOnStateChange = super.onStateChange(iArr);
        ColorStateList colorStateList = this.f14396K;
        int iL = l(colorStateList != null ? colorStateList.getColorForState(iArr, this.f14447z0) : 0);
        boolean state = true;
        if (this.f14447z0 != iL) {
            this.f14447z0 = iL;
            zOnStateChange = true;
        }
        ColorStateList colorStateList2 = this.f14398L;
        int iL2 = l(colorStateList2 != null ? colorStateList2.getColorForState(iArr, this.f14386A0) : 0);
        if (this.f14386A0 != iL2) {
            this.f14386A0 = iL2;
            zOnStateChange = true;
        }
        int iG = b.g(iL, iL2);
        if ((this.f14387B0 != iG) | (x() == null)) {
            this.f14387B0 = iG;
            U(ColorStateList.valueOf(iG));
            zOnStateChange = true;
        }
        ColorStateList colorStateList3 = this.f14404O;
        int colorForState = colorStateList3 != null ? colorStateList3.getColorForState(iArr, this.f14388C0) : 0;
        if (this.f14388C0 != colorForState) {
            this.f14388C0 = colorForState;
            zOnStateChange = true;
        }
        int colorForState2 = (this.f14405O0 == null || !AbstractC0990b.b(iArr)) ? 0 : this.f14405O0.getColorForState(iArr, this.f14389D0);
        if (this.f14389D0 != colorForState2) {
            this.f14389D0 = colorForState2;
            if (this.f14403N0) {
                zOnStateChange = true;
            }
        }
        int colorForState3 = (this.f14446y0.d() == null || this.f14446y0.d().i() == null) ? 0 : this.f14446y0.d().i().getColorForState(iArr, this.f14390E0);
        if (this.f14390E0 != colorForState3) {
            this.f14390E0 = colorForState3;
            zOnStateChange = true;
        }
        boolean z8 = i1(getState(), R.attr.state_checked) && this.f14425d0;
        if (this.f14391F0 == z8 || this.f14427f0 == null) {
            z7 = false;
        } else {
            float fH0 = h0();
            this.f14391F0 = z8;
            if (fH0 != h0()) {
                zOnStateChange = true;
                z7 = true;
            } else {
                z7 = false;
                zOnStateChange = true;
            }
        }
        ColorStateList colorStateList4 = this.f14397K0;
        int colorForState4 = colorStateList4 != null ? colorStateList4.getColorForState(iArr, this.f14392G0) : 0;
        if (this.f14392G0 != colorForState4) {
            this.f14392G0 = colorForState4;
            this.f14395J0 = X2.a.e(this, this.f14397K0, this.f14399L0);
        } else {
            state = zOnStateChange;
        }
        if (n1(this.f14414T)) {
            state |= this.f14414T.setState(iArr);
        }
        if (n1(this.f14427f0)) {
            state |= this.f14427f0.setState(iArr);
        }
        if (n1(this.f14420Y)) {
            int[] iArr3 = new int[iArr.length + iArr2.length];
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            System.arraycopy(iArr2, 0, iArr3, iArr.length, iArr2.length);
            state |= this.f14420Y.setState(iArr3);
        }
        if (AbstractC0990b.f15163a && n1(this.f14421Z)) {
            state |= this.f14421Z.setState(iArr2);
        }
        if (state) {
            invalidateSelf();
        }
        if (z7) {
            q1();
        }
        return state;
    }

    public void r2(int i7) {
        q2(this.f14439r0.getResources().getDimension(i7));
    }

    public final void s0(Canvas canvas, Rect rect) {
        if (this.f14415T0) {
            return;
        }
        this.f14440s0.setColor(this.f14386A0);
        this.f14440s0.setStyle(Paint.Style.FILL);
        this.f14440s0.setColorFilter(g1());
        this.f14443v0.set(rect);
        canvas.drawRoundRect(this.f14443v0, D0(), D0(), this.f14440s0);
    }

    public void s1(boolean z7) {
        if (this.f14425d0 != z7) {
            this.f14425d0 = z7;
            float fH0 = h0();
            if (!z7 && this.f14391F0) {
                this.f14391F0 = false;
            }
            float fH02 = h0();
            invalidateSelf();
            if (fH0 != fH02) {
                q1();
            }
        }
    }

    public void s2(int i7) {
        this.f14413S0 = i7;
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j7) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, runnable, j7);
        }
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public void setAlpha(int i7) {
        if (this.f14393H0 != i7) {
            this.f14393H0 = i7;
            invalidateSelf();
        }
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        if (this.f14394I0 != colorFilter) {
            this.f14394I0 = colorFilter;
            invalidateSelf();
        }
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        if (this.f14397K0 != colorStateList) {
            this.f14397K0 = colorStateList;
            onStateChange(getState());
        }
    }

    @Override // f3.g, android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        if (this.f14399L0 != mode) {
            this.f14399L0 = mode;
            this.f14395J0 = X2.a.e(this, this.f14397K0, mode);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z7, boolean z8) {
        boolean visible = super.setVisible(z7, z8);
        if (J2()) {
            visible |= this.f14414T.setVisible(z7, z8);
        }
        if (I2()) {
            visible |= this.f14427f0.setVisible(z7, z8);
        }
        if (K2()) {
            visible |= this.f14420Y.setVisible(z7, z8);
        }
        if (visible) {
            invalidateSelf();
        }
        return visible;
    }

    public final void t0(Canvas canvas, Rect rect) {
        if (J2()) {
            g0(rect, this.f14443v0);
            RectF rectF = this.f14443v0;
            float f7 = rectF.left;
            float f8 = rectF.top;
            canvas.translate(f7, f8);
            this.f14414T.setBounds(0, 0, (int) this.f14443v0.width(), (int) this.f14443v0.height());
            this.f14414T.draw(canvas);
            canvas.translate(-f7, -f8);
        }
    }

    public void t1(int i7) {
        s1(this.f14439r0.getResources().getBoolean(i7));
    }

    public void t2(ColorStateList colorStateList) {
        if (this.f14408Q != colorStateList) {
            this.f14408Q = colorStateList;
            M2();
            onStateChange(getState());
        }
    }

    public final void u0(Canvas canvas, Rect rect) {
        if (this.f14406P <= 0.0f || this.f14415T0) {
            return;
        }
        this.f14440s0.setColor(this.f14388C0);
        this.f14440s0.setStyle(Paint.Style.STROKE);
        if (!this.f14415T0) {
            this.f14440s0.setColorFilter(g1());
        }
        RectF rectF = this.f14443v0;
        float f7 = rect.left;
        float f8 = this.f14406P;
        rectF.set(f7 + (f8 / 2.0f), rect.top + (f8 / 2.0f), rect.right - (f8 / 2.0f), rect.bottom - (f8 / 2.0f));
        float f9 = this.f14402N - (this.f14406P / 2.0f);
        canvas.drawRoundRect(this.f14443v0, f9, f9, this.f14440s0);
    }

    public void u1(Drawable drawable) {
        if (this.f14427f0 != drawable) {
            float fH0 = h0();
            this.f14427f0 = drawable;
            float fH02 = h0();
            L2(this.f14427f0);
            f0(this.f14427f0);
            invalidateSelf();
            if (fH0 != fH02) {
                q1();
            }
        }
    }

    public void u2(int i7) {
        t2(AbstractC1244a.a(this.f14439r0, i7));
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, runnable);
        }
    }

    public final void v0(Canvas canvas, Rect rect) {
        if (this.f14415T0) {
            return;
        }
        this.f14440s0.setColor(this.f14447z0);
        this.f14440s0.setStyle(Paint.Style.FILL);
        this.f14443v0.set(rect);
        canvas.drawRoundRect(this.f14443v0, D0(), D0(), this.f14440s0);
    }

    public void v1(int i7) {
        u1(AbstractC1244a.b(this.f14439r0, i7));
    }

    public void v2(boolean z7) {
        this.f14411R0 = z7;
    }

    public final void w0(Canvas canvas, Rect rect) {
        if (K2()) {
            j0(rect, this.f14443v0);
            RectF rectF = this.f14443v0;
            float f7 = rectF.left;
            float f8 = rectF.top;
            canvas.translate(f7, f8);
            this.f14420Y.setBounds(0, 0, (int) this.f14443v0.width(), (int) this.f14443v0.height());
            if (AbstractC0990b.f15163a) {
                this.f14421Z.setBounds(this.f14420Y.getBounds());
                this.f14421Z.jumpToCurrentState();
                this.f14421Z.draw(canvas);
            } else {
                this.f14420Y.draw(canvas);
            }
            canvas.translate(-f7, -f8);
        }
    }

    public void w1(ColorStateList colorStateList) {
        if (this.f14428g0 != colorStateList) {
            this.f14428g0 = colorStateList;
            if (p0()) {
                P.a.o(this.f14427f0, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public void w2(c cVar) {
        this.f14429h0 = cVar;
    }

    public final void x0(Canvas canvas, Rect rect) {
        this.f14440s0.setColor(this.f14389D0);
        this.f14440s0.setStyle(Paint.Style.FILL);
        this.f14443v0.set(rect);
        if (!this.f14415T0) {
            canvas.drawRoundRect(this.f14443v0, D0(), D0(), this.f14440s0);
        } else {
            h(new RectF(rect), this.f14445x0);
            super.p(canvas, this.f14440s0, this.f14445x0, u());
        }
    }

    public void x1(int i7) {
        w1(AbstractC1244a.a(this.f14439r0, i7));
    }

    public void x2(int i7) {
        w2(c.c(this.f14439r0, i7));
    }

    public final void y0(Canvas canvas, Rect rect) {
        Canvas canvas2;
        Paint paint = this.f14441t0;
        if (paint != null) {
            paint.setColor(AbstractC0562a.j(-16777216, 127));
            canvas.drawRect(rect, this.f14441t0);
            if (J2() || I2()) {
                g0(rect, this.f14443v0);
                canvas.drawRect(this.f14443v0, this.f14441t0);
            }
            if (this.f14410R != null) {
                canvas2 = canvas;
                canvas2.drawLine(rect.left, rect.exactCenterY(), rect.right, rect.exactCenterY(), this.f14441t0);
            } else {
                canvas2 = canvas;
            }
            if (K2()) {
                j0(rect, this.f14443v0);
                canvas2.drawRect(this.f14443v0, this.f14441t0);
            }
            this.f14441t0.setColor(AbstractC0562a.j(-65536, 127));
            i0(rect, this.f14443v0);
            canvas2.drawRect(this.f14443v0, this.f14441t0);
            this.f14441t0.setColor(AbstractC0562a.j(-16711936, 127));
            k0(rect, this.f14443v0);
            canvas2.drawRect(this.f14443v0, this.f14441t0);
        }
    }

    public void y1(int i7) {
        z1(this.f14439r0.getResources().getBoolean(i7));
    }

    public void y2(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = "";
        }
        if (TextUtils.equals(this.f14410R, charSequence)) {
            return;
        }
        this.f14410R = charSequence;
        this.f14446y0.i(true);
        invalidateSelf();
        q1();
    }

    public final void z0(Canvas canvas, Rect rect) {
        if (this.f14410R != null) {
            Paint.Align alignO0 = o0(rect, this.f14444w0);
            m0(rect, this.f14443v0);
            if (this.f14446y0.d() != null) {
                this.f14446y0.e().drawableState = getState();
                this.f14446y0.j(this.f14439r0);
            }
            this.f14446y0.e().setTextAlign(alignO0);
            int iSave = 0;
            boolean z7 = Math.round(this.f14446y0.f(c1().toString())) > Math.round(this.f14443v0.width());
            if (z7) {
                iSave = canvas.save();
                canvas.clipRect(this.f14443v0);
            }
            CharSequence charSequenceEllipsize = this.f14410R;
            if (z7 && this.f14409Q0 != null) {
                charSequenceEllipsize = TextUtils.ellipsize(charSequenceEllipsize, this.f14446y0.e(), this.f14443v0.width(), this.f14409Q0);
            }
            CharSequence charSequence = charSequenceEllipsize;
            int length = charSequence.length();
            PointF pointF = this.f14444w0;
            canvas.drawText(charSequence, 0, length, pointF.x, pointF.y, this.f14446y0.e());
            if (z7) {
                canvas.restoreToCount(iSave);
            }
        }
    }

    public void z1(boolean z7) {
        if (this.f14426e0 != z7) {
            boolean zI2 = I2();
            this.f14426e0 = z7;
            boolean zI22 = I2();
            if (zI2 != zI22) {
                if (zI22) {
                    f0(this.f14427f0);
                } else {
                    L2(this.f14427f0);
                }
                invalidateSelf();
                q1();
            }
        }
    }

    public void z2(C0904d c0904d) {
        this.f14446y0.h(c0904d, this.f14439r0);
    }
}
