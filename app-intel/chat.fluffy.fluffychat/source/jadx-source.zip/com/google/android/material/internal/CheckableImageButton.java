package com.google.android.material.internal;

import Z.C0682a;
import Z.W;
import a0.x;
import android.R;
import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;
import e0.AbstractC1008a;
import i.AbstractC1145a;
import q.C1478o;

/* loaded from: classes.dex */
public class CheckableImageButton extends C1478o implements Checkable {

    /* renamed from: r, reason: collision with root package name */
    public static final int[] f14583r = {R.attr.state_checked};

    /* renamed from: o, reason: collision with root package name */
    public boolean f14584o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f14585p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f14586q;

    public class a extends C0682a {
        public a() {
        }

        @Override // Z.C0682a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            accessibilityEvent.setChecked(CheckableImageButton.this.isChecked());
        }

        @Override // Z.C0682a
        public void g(View view, x xVar) {
            super.g(view, xVar);
            xVar.n0(CheckableImageButton.this.a());
            xVar.o0(CheckableImageButton.this.isChecked());
        }
    }

    public static class b extends AbstractC1008a {
        public static final Parcelable.Creator<b> CREATOR = new a();

        /* renamed from: n, reason: collision with root package name */
        public boolean f14588n;

        public class a implements Parcelable.ClassLoaderCreator {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public b createFromParcel(Parcel parcel) {
                return new b(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public b createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new b(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public b[] newArray(int i7) {
                return new b[i7];
            }
        }

        public b(Parcelable parcelable) {
            super(parcelable);
        }

        private void c(Parcel parcel) {
            this.f14588n = parcel.readInt() == 1;
        }

        @Override // e0.AbstractC1008a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i7) {
            super.writeToParcel(parcel, i7);
            parcel.writeInt(this.f14588n ? 1 : 0);
        }

        public b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            c(parcel);
        }
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, AbstractC1145a.f16955z);
    }

    public boolean a() {
        return this.f14585p;
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.f14584o;
    }

    @Override // android.widget.ImageView, android.view.View
    public int[] onCreateDrawableState(int i7) {
        if (!this.f14584o) {
            return super.onCreateDrawableState(i7);
        }
        int[] iArr = f14583r;
        return View.mergeDrawableStates(super.onCreateDrawableState(i7 + iArr.length), iArr);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b bVar = (b) parcelable;
        super.onRestoreInstanceState(bVar.b());
        setChecked(bVar.f14588n);
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        b bVar = new b(super.onSaveInstanceState());
        bVar.f14588n = this.f14584o;
        return bVar;
    }

    public void setCheckable(boolean z7) {
        if (this.f14585p != z7) {
            this.f14585p = z7;
            sendAccessibilityEvent(0);
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z7) {
        if (!this.f14585p || this.f14584o == z7) {
            return;
        }
        this.f14584o = z7;
        refreshDrawableState();
        sendAccessibilityEvent(2048);
    }

    public void setPressable(boolean z7) {
        this.f14586q = z7;
    }

    @Override // android.view.View
    public void setPressed(boolean z7) {
        if (this.f14586q) {
            super.setPressed(z7);
        }
    }

    @Override // android.widget.Checkable
    public void toggle() {
        setChecked(!this.f14584o);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        this.f14585p = true;
        this.f14586q = true;
        W.l0(this, new a());
    }
}
