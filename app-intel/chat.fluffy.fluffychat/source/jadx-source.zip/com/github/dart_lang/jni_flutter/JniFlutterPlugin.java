package com.github.dart_lang.jni_flutter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import c5.InterfaceC0910a;
import d5.InterfaceC0998a;
import d5.InterfaceC1000c;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public class JniFlutterPlugin implements InterfaceC0910a, InterfaceC0998a {

    @SuppressLint({"StaticFieldLeak"})
    private static Context context;
    private static final ConcurrentHashMap<Long, JniFlutterPlugin> pluginMap = new ConcurrentHashMap<>();
    private volatile Activity activity;
    private long engineId;

    public static Activity getActivity(long j7) {
        JniFlutterPlugin jniFlutterPlugin = pluginMap.get(Long.valueOf(j7));
        Objects.requireNonNull(jniFlutterPlugin);
        return jniFlutterPlugin.activity;
    }

    public static Context getApplicationContext() {
        return context;
    }

    private void setActivity(Activity activity) {
        this.activity = activity;
    }

    @Override // d5.InterfaceC0998a
    public void onAttachedToActivity(InterfaceC1000c interfaceC1000c) {
        setActivity(interfaceC1000c.getActivity());
    }

    @Override // c5.InterfaceC0910a
    public void onAttachedToEngine(InterfaceC0910a.b bVar) {
        this.engineId = bVar.c().m();
        context = bVar.a();
        pluginMap.put(Long.valueOf(this.engineId), this);
    }

    @Override // d5.InterfaceC0998a
    public void onDetachedFromActivity() {
        setActivity(null);
    }

    @Override // d5.InterfaceC0998a
    public void onDetachedFromActivityForConfigChanges() {
        setActivity(null);
    }

    @Override // c5.InterfaceC0910a
    public void onDetachedFromEngine(InterfaceC0910a.b bVar) {
        this.activity = null;
        pluginMap.remove(Long.valueOf(this.engineId));
    }

    @Override // d5.InterfaceC0998a
    public void onReattachedToActivityForConfigChanges(InterfaceC1000c interfaceC1000c) {
        setActivity(interfaceC1000c.getActivity());
    }
}
