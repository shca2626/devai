package g;

import M5.m;
import android.content.Context;
import android.content.Intent;
import g.AbstractC1065a;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import y5.AbstractC1817l;
import y5.C1813h;
import z5.C1862F;
import z5.C1863G;
import z5.C1878l;
import z5.C1889w;

/* loaded from: classes.dex */
public final class k extends AbstractC1065a {

    /* renamed from: a, reason: collision with root package name */
    public static final a f15922a = new a(null);

    public static final class a {
        public /* synthetic */ a(M5.g gVar) {
            this();
        }

        public final Intent a(String[] strArr) {
            m.e(strArr, "input");
            Intent intentPutExtra = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr);
            m.d(intentPutExtra, "putExtra(...)");
            return intentPutExtra;
        }

        public a() {
        }
    }

    @Override // g.AbstractC1065a
    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public Intent a(Context context, String[] strArr) {
        m.e(context, "context");
        m.e(strArr, "input");
        return f15922a.a(strArr);
    }

    @Override // g.AbstractC1065a
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public AbstractC1065a.C0168a b(Context context, String[] strArr) {
        m.e(context, "context");
        m.e(strArr, "input");
        if (strArr.length == 0) {
            return new AbstractC1065a.C0168a(C1863G.h());
        }
        for (String str : strArr) {
            if (L.b.a(context, str) != 0) {
                return null;
            }
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(S5.e.b(C1862F.e(strArr.length), 16));
        for (String str2 : strArr) {
            C1813h c1813hA = AbstractC1817l.a(str2, Boolean.TRUE);
            linkedHashMap.put(c1813hA.c(), c1813hA.d());
        }
        return new AbstractC1065a.C0168a(linkedHashMap);
    }

    @Override // g.AbstractC1065a
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public Map c(int i7, Intent intent) {
        if (i7 != -1) {
            return C1863G.h();
        }
        if (intent == null) {
            return C1863G.h();
        }
        String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
        if (intArrayExtra == null || stringArrayExtra == null) {
            return C1863G.h();
        }
        ArrayList arrayList = new ArrayList(intArrayExtra.length);
        for (int i8 : intArrayExtra) {
            arrayList.add(Boolean.valueOf(i8 == 0));
        }
        return C1863G.q(C1889w.c0(C1878l.s(stringArrayExtra), arrayList));
    }
}
