package q;

/* loaded from: classes.dex */
public abstract /* synthetic */ class L {
}
