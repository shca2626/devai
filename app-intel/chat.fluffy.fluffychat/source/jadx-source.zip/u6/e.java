package u6;

import java.security.cert.X509Certificate;

/* loaded from: classes3.dex */
public interface e {
    X509Certificate a(X509Certificate x509Certificate);
}
