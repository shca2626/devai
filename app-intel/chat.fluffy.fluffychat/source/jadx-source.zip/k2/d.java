package k2;

/* loaded from: classes.dex */
public abstract /* synthetic */ class d {
}
