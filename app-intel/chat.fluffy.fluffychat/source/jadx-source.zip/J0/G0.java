package J0;

/* loaded from: classes.dex */
public abstract /* synthetic */ class G0 {
}
