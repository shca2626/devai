package j$.time.temporal;

/* loaded from: classes2.dex */
public abstract class l {

    /* renamed from: a, reason: collision with root package name */
    public static final k f18394a = k.MODIFIED_JULIAN_DAY;
}
