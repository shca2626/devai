package M;

/* loaded from: classes.dex */
public abstract /* synthetic */ class a0 {
}
