package M;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Y {
}
