package s2;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import p2.InterfaceC1439a;
import s2.g;

/* loaded from: classes.dex */
public final class d implements g {

    /* renamed from: a, reason: collision with root package name */
    public final r2.i f22388a;

    public d(r2.i iVar) {
        M5.m.e(iVar, "drawableDecoder");
        this.f22388a = iVar;
    }

    @Override // s2.g
    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public Object b(InterfaceC1439a interfaceC1439a, Drawable drawable, y2.h hVar, r2.m mVar, C5.e eVar) {
        boolean zK = C2.e.k(drawable);
        if (zK) {
            Bitmap bitmapA = this.f22388a.a(drawable, mVar.d(), hVar, mVar.j(), mVar.a());
            Resources resources = mVar.e().getResources();
            M5.m.d(resources, "context.resources");
            drawable = new BitmapDrawable(resources, bitmapA);
        }
        return new e(drawable, zK, r2.e.MEMORY);
    }

    @Override // s2.g
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public boolean a(Drawable drawable) {
        return g.a.a(this, drawable);
    }

    @Override // s2.g
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public String c(Drawable drawable) {
        M5.m.e(drawable, "data");
        return null;
    }
}
