package s2;

import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import p2.InterfaceC1439a;
import v6.o;
import z5.C1889w;

/* renamed from: s2.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1603a implements g {

    /* renamed from: b, reason: collision with root package name */
    public static final C0267a f22385b = new C0267a(null);

    /* renamed from: a, reason: collision with root package name */
    public final Context f22386a;

    /* renamed from: s2.a$a, reason: collision with other inner class name */
    public static final class C0267a {
        public /* synthetic */ C0267a(M5.g gVar) {
            this();
        }

        public C0267a() {
        }
    }

    public C1603a(Context context) {
        M5.m.e(context, "context");
        this.f22386a = context;
    }

    @Override // s2.g
    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public Object b(InterfaceC1439a interfaceC1439a, Uri uri, y2.h hVar, r2.m mVar, C5.e eVar) throws IOException {
        List<String> pathSegments = uri.getPathSegments();
        M5.m.d(pathSegments, "data.pathSegments");
        String strL = C1889w.L(C1889w.C(pathSegments, 1), "/", null, null, 0, null, null, 62, null);
        InputStream inputStreamOpen = this.f22386a.getAssets().open(strL);
        M5.m.d(inputStreamOpen, "context.assets.open(path)");
        v6.g gVarD = o.d(o.l(inputStreamOpen));
        MimeTypeMap singleton = MimeTypeMap.getSingleton();
        M5.m.d(singleton, "getSingleton()");
        return new m(gVarD, C2.e.e(singleton, strL), r2.e.DISK);
    }

    @Override // s2.g
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public boolean a(Uri uri) {
        M5.m.e(uri, "data");
        return M5.m.a(uri.getScheme(), "file") && M5.m.a(C2.e.c(uri), "android_asset");
    }

    @Override // s2.g
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public String c(Uri uri) {
        M5.m.e(uri, "data");
        String string = uri.toString();
        M5.m.d(string, "data.toString()");
        return string;
    }
}
