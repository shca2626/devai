package s2;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import java.io.FileNotFoundException;
import java.io.InputStream;
import p2.InterfaceC1439a;
import v6.o;

/* loaded from: classes.dex */
public final class c implements g {

    /* renamed from: a, reason: collision with root package name */
    public final Context f22387a;

    public c(Context context) {
        M5.m.e(context, "context");
        this.f22387a = context;
    }

    @Override // s2.g
    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public Object b(InterfaceC1439a interfaceC1439a, Uri uri, y2.h hVar, r2.m mVar, C5.e eVar) throws FileNotFoundException {
        InputStream inputStreamOpenInputStream;
        if (f(uri)) {
            AssetFileDescriptor assetFileDescriptorOpenAssetFileDescriptor = this.f22387a.getContentResolver().openAssetFileDescriptor(uri, "r");
            inputStreamOpenInputStream = assetFileDescriptorOpenAssetFileDescriptor == null ? null : assetFileDescriptorOpenAssetFileDescriptor.createInputStream();
            if (inputStreamOpenInputStream == null) {
                throw new IllegalStateException(("Unable to find a contact photo associated with '" + uri + "'.").toString());
            }
        } else {
            inputStreamOpenInputStream = this.f22387a.getContentResolver().openInputStream(uri);
            if (inputStreamOpenInputStream == null) {
                throw new IllegalStateException(("Unable to open '" + uri + "'.").toString());
            }
        }
        return new m(o.d(o.l(inputStreamOpenInputStream)), this.f22387a.getContentResolver().getType(uri), r2.e.DISK);
    }

    @Override // s2.g
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public boolean a(Uri uri) {
        M5.m.e(uri, "data");
        return M5.m.a(uri.getScheme(), "content");
    }

    public final boolean f(Uri uri) {
        M5.m.e(uri, "data");
        return M5.m.a(uri.getAuthority(), "com.android.contacts") && M5.m.a(uri.getLastPathSegment(), "display_photo");
    }

    @Override // s2.g
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public String c(Uri uri) {
        M5.m.e(uri, "data");
        String string = uri.toString();
        M5.m.d(string, "data.toString()");
        return string;
    }
}
