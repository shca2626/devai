package s2;

import k6.e;
import k6.s;

/* loaded from: classes.dex */
public final class k extends i {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(e.a aVar) {
        super(aVar);
        M5.m.e(aVar, "callFactory");
    }

    @Override // s2.g
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public String c(s sVar) {
        M5.m.e(sVar, "data");
        String string = sVar.toString();
        M5.m.d(string, "data.toString()");
        return string;
    }

    @Override // s2.i
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public s f(s sVar) {
        M5.m.e(sVar, "<this>");
        return sVar;
    }
}
