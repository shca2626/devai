package s2;

import android.net.Uri;
import k6.e;
import k6.s;

/* loaded from: classes.dex */
public final class j extends i {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(e.a aVar) {
        super(aVar);
        M5.m.e(aVar, "callFactory");
    }

    @Override // s2.i, s2.g
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public boolean a(Uri uri) {
        M5.m.e(uri, "data");
        return M5.m.a(uri.getScheme(), "http") || M5.m.a(uri.getScheme(), "https");
    }

    @Override // s2.g
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public String c(Uri uri) {
        M5.m.e(uri, "data");
        String string = uri.toString();
        M5.m.d(string, "data.toString()");
        return string;
    }

    @Override // s2.i
    /* renamed from: i, reason: merged with bridge method [inline-methods] */
    public s f(Uri uri) {
        M5.m.e(uri, "<this>");
        s sVarK = s.k(uri.toString());
        M5.m.d(sVarK, "get(toString())");
        return sVarK;
    }
}
