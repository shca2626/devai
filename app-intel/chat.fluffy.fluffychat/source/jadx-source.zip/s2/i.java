package s2;

import V5.w;
import V5.y;
import android.webkit.MimeTypeMap;
import k6.B;
import k6.C1290d;
import k6.e;
import k6.s;
import k6.u;
import p2.InterfaceC1439a;
import s2.g;

/* loaded from: classes.dex */
public abstract class i implements g {

    /* renamed from: b, reason: collision with root package name */
    public static final a f22393b = new a(null);

    /* renamed from: c, reason: collision with root package name */
    public static final C1290d f22394c = new C1290d.a().c().d().a();

    /* renamed from: d, reason: collision with root package name */
    public static final C1290d f22395d = new C1290d.a().c().e().a();

    /* renamed from: a, reason: collision with root package name */
    public final e.a f22396a;

    public static final class a {
        public /* synthetic */ a(M5.g gVar) {
            this();
        }

        public a() {
        }
    }

    public static final class b extends E5.d {

        /* renamed from: o, reason: collision with root package name */
        public Object f22397o;

        /* renamed from: p, reason: collision with root package name */
        public Object f22398p;

        /* renamed from: q, reason: collision with root package name */
        public Object f22399q;

        /* renamed from: r, reason: collision with root package name */
        public /* synthetic */ Object f22400r;

        /* renamed from: t, reason: collision with root package name */
        public int f22402t;

        public b(C5.e eVar) {
            super(eVar);
        }

        @Override // E5.a
        public final Object q(Object obj) {
            this.f22400r = obj;
            this.f22402t |= Integer.MIN_VALUE;
            return i.d(i.this, null, null, null, null, this);
        }
    }

    public i(e.a aVar) {
        M5.m.e(aVar, "callFactory");
        this.f22396a = aVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0116  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static /* synthetic */ java.lang.Object d(s2.i r3, p2.InterfaceC1439a r4, java.lang.Object r5, y2.h r6, r2.m r7, C5.e r8) throws java.lang.Throwable {
        /*
            Method dump skipped, instructions count: 322
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: s2.i.d(s2.i, p2.a, java.lang.Object, y2.h, r2.m, C5.e):java.lang.Object");
    }

    @Override // s2.g
    public boolean a(Object obj) {
        return g.a.a(this, obj);
    }

    @Override // s2.g
    public Object b(InterfaceC1439a interfaceC1439a, Object obj, y2.h hVar, r2.m mVar, C5.e eVar) {
        return d(this, interfaceC1439a, obj, hVar, mVar, eVar);
    }

    public final String e(s sVar, B b7) {
        M5.m.e(sVar, "data");
        M5.m.e(b7, "body");
        u uVarD = b7.d();
        String string = uVarD == null ? null : uVarD.toString();
        if (string == null || w.y(string, "text/plain", false, 2, null)) {
            MimeTypeMap singleton = MimeTypeMap.getSingleton();
            M5.m.d(singleton, "getSingleton()");
            String strE = C2.e.e(singleton, sVar.toString());
            if (strE != null) {
                return strE;
            }
        }
        if (string == null) {
            return null;
        }
        return y.n0(string, ';', null, 2, null);
    }

    public abstract s f(Object obj);
}
