package s2;

import android.webkit.MimeTypeMap;
import java.io.File;
import p2.InterfaceC1439a;
import s2.g;
import v6.o;

/* loaded from: classes.dex */
public final class h implements g {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f22392a;

    public h(boolean z7) {
        this.f22392a = z7;
    }

    @Override // s2.g
    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public Object b(InterfaceC1439a interfaceC1439a, File file, y2.h hVar, r2.m mVar, C5.e eVar) {
        return new m(o.d(o.k(file)), MimeTypeMap.getSingleton().getMimeTypeFromExtension(J5.i.c(file)), r2.e.DISK);
    }

    @Override // s2.g
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public boolean a(File file) {
        return g.a.a(this, file);
    }

    @Override // s2.g
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public String c(File file) {
        M5.m.e(file, "data");
        if (!this.f22392a) {
            String path = file.getPath();
            M5.m.d(path, "data.path");
            return path;
        }
        StringBuilder sb = new StringBuilder();
        sb.append((Object) file.getPath());
        sb.append(':');
        sb.append(file.lastModified());
        return sb.toString();
    }
}
