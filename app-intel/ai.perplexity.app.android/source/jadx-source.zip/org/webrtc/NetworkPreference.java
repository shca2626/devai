package org.webrtc;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
@Retention(RetentionPolicy.SOURCE)
/* loaded from: classes4.dex */
public @interface NetworkPreference {
    public static final int NEUTRAL = 0;
    public static final int NOT_PREFERRED = -1;
}
