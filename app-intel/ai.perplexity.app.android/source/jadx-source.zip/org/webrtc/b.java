package org.webrtc;

import org.webrtc.Camera1Session;
import org.webrtc.TextureBufferImpl;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes4.dex */
public final /* synthetic */ class b implements Runnable {
    public final /* synthetic */ byte w;
    public final /* synthetic */ Object x;
    public final /* synthetic */ Object y;

    public /* synthetic */ b(Object obj, Object obj2, byte b) {
        this.w = b;
        this.x = obj;
        this.y = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        byte b = this.w;
        Object obj = this.y;
        Object obj2 = this.x;
        switch (b) {
            case 0:
                ((Camera1Session.AnonymousClass2) obj2).lambda$onPreviewFrame$1((byte[]) obj);
                break;
            case 1:
                ((Camera1Session.AnonymousClass2) obj2).lambda$onPreviewFrame$0((byte[]) obj);
                break;
            default:
                ((TextureBufferImpl) obj2).lambda$new$0((TextureBufferImpl.RefCountMonitor) obj);
                break;
        }
    }
}
