package org.webrtc;

import com.singular.sdk.BuildConfig;
import defpackage.ri8;
import java.nio.ByteBuffer;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes4.dex */
public class DataChannel {
    private long nativeDataChannel;
    private long nativeObserver;

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static class Buffer {
        public final boolean binary;
        public final ByteBuffer data;

        public Buffer(ByteBuffer byteBuffer, boolean z) {
            this.data = byteBuffer;
            this.binary = z;
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static class Init {
        public boolean negotiated;
        public boolean ordered = true;
        public int maxRetransmitTimeMs = -1;
        public int maxRetransmits = -1;
        public String protocol = BuildConfig.FLAVOR;
        public int id = -1;

        public int getId() {
            return this.id;
        }

        public int getMaxRetransmitTimeMs() {
            return this.maxRetransmitTimeMs;
        }

        public int getMaxRetransmits() {
            return this.maxRetransmits;
        }

        public boolean getNegotiated() {
            return this.negotiated;
        }

        public boolean getOrdered() {
            return this.ordered;
        }

        public String getProtocol() {
            return this.protocol;
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public interface Observer {
        void onBufferedAmountChange(long j);

        void onMessage(Buffer buffer);

        void onStateChange();
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public enum State {
        CONNECTING,
        OPEN,
        CLOSING,
        CLOSED;

        public static State fromNativeIndex(int i) {
            return values()[i];
        }
    }

    public DataChannel(long j) {
        this.nativeDataChannel = j;
    }

    private void checkDataChannelExists() {
        if (this.nativeDataChannel != 0) {
            return;
        }
        ri8.q("DataChannel has been disposed.");
    }

    private native long nativeBufferedAmount();

    private native void nativeClose();

    private native int nativeId();

    private native String nativeLabel();

    private native long nativeRegisterObserver(Observer observer);

    private native boolean nativeSend(byte[] bArr, boolean z);

    private native State nativeState();

    private native void nativeUnregisterObserver(long j);

    public long bufferedAmount() {
        checkDataChannelExists();
        return nativeBufferedAmount();
    }

    public void close() {
        checkDataChannelExists();
        nativeClose();
    }

    public void dispose() {
        checkDataChannelExists();
        JniCommon.nativeReleaseRef(this.nativeDataChannel);
        this.nativeDataChannel = 0L;
    }

    public long getNativeDataChannel() {
        return this.nativeDataChannel;
    }

    public int id() {
        checkDataChannelExists();
        return nativeId();
    }

    public String label() {
        checkDataChannelExists();
        return nativeLabel();
    }

    public void registerObserver(Observer observer) {
        checkDataChannelExists();
        long j = this.nativeObserver;
        if (j != 0) {
            nativeUnregisterObserver(j);
        }
        this.nativeObserver = nativeRegisterObserver(observer);
    }

    public boolean send(Buffer buffer) {
        checkDataChannelExists();
        byte[] bArr = new byte[buffer.data.remaining()];
        buffer.data.get(bArr);
        return nativeSend(bArr, buffer.binary);
    }

    public State state() {
        checkDataChannelExists();
        return nativeState();
    }

    public void unregisterObserver() {
        checkDataChannelExists();
        nativeUnregisterObserver(this.nativeObserver);
        this.nativeObserver = 0L;
    }
}
