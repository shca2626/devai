package org.scilab.forge.jlatexmath;

import defpackage.etb;
import defpackage.wc6;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes4.dex */
public class XMLResourceParseException extends ResourceParseException {
    /* JADX WARN: Illegal instructions before constructor call */
    public XMLResourceParseException(String str, String str2, String str3, String str4) {
        StringBuilder sbR = wc6.r(str, ": invalid <", str2, ">-element found: attribute '", str3);
        sbR.append("' ");
        sbR.append(str4 == null ? "is required!" : str4);
        super(sbR.toString());
    }

    public XMLResourceParseException(String str) {
        super(etb.l("DefaultTeXFont.xml: the required <", str, ">-element is not found!"));
    }
}
