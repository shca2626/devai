package org.chromium.support_lib_boundary;

import android.os.CancellationSignal;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ServiceWorkerController;
import android.webkit.WebStorage;
import java.lang.reflect.InvocationHandler;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public interface ProfileBoundaryInterface {
    void addOriginMatchedHeader(String str, String str2, Set<String> set);

    void addQuicHints(Set<String> set);

    void clearAllOriginMatchedHeaders();

    void clearMaxPrefetches();

    void clearMaxPrerenders();

    @Deprecated
    void clearOriginMatchedHeader(String str);

    void clearOriginMatchedHeader(String str, String str2);

    void clearPrefetch(String str, Executor executor, InvocationHandler invocationHandler);

    void clearPrefetchTtl();

    void enqueuePreconnect(String str);

    CookieManager getCookieManager();

    GeolocationPermissions getGeoLocationPermissions();

    InvocationHandler getHttpCache();

    int getMaxPrefetches();

    int getMaxPrerenders();

    String getName();

    List<InvocationHandler> getOriginMatchedHeaders(String str, String str2);

    int getPrefetchTtlSeconds();

    ServiceWorkerController getServiceWorkerController();

    WebStorage getWebStorage();

    boolean hasOriginMatchedHeader(String str);

    void preconnect(String str);

    void prefetchUrl(String str, CancellationSignal cancellationSignal, Executor executor, InvocationHandler invocationHandler);

    void prefetchUrl(String str, CancellationSignal cancellationSignal, Executor executor, InvocationHandler invocationHandler, InvocationHandler invocationHandler2);

    void setMaxPrefetches(int i);

    void setMaxPrefetches(Integer num);

    void setMaxPrerenders(int i);

    void setMaxPrerenders(Integer num);

    @Deprecated
    void setOriginMatchedHeader(String str, String str2, Set<String> set);

    void setPrefetchTtlSeconds(int i);

    void setPrefetchTtlSeconds(Integer num);

    void setSpeculativeLoadingConfig(InvocationHandler invocationHandler);

    void warmUpRendererProcess();
}
