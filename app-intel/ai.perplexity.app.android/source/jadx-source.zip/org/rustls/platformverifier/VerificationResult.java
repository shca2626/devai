package org.rustls.platformverifier;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
final class VerificationResult {
    private final int code;
    private final String message;

    public VerificationResult(StatusCode statusCode, String str) {
        statusCode.getClass();
        this.message = str;
        this.code = statusCode.getValue();
    }

    public final String getMessage() {
        return this.message;
    }

    public /* synthetic */ VerificationResult(StatusCode statusCode, String str, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(statusCode, (i & 2) != 0 ? null : str);
    }
}
