package org.rustls.platformverifier;

import defpackage.mms;
import kotlin.enums.EnumEntries;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
final class StatusCode {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ StatusCode[] $VALUES;
    private final int value;
    public static final StatusCode Ok = new StatusCode("Ok", 0, 0);
    public static final StatusCode Unavailable = new StatusCode("Unavailable", 1, 1);
    public static final StatusCode Expired = new StatusCode("Expired", 2, 2);
    public static final StatusCode UnknownCert = new StatusCode("UnknownCert", 3, 3);
    public static final StatusCode Revoked = new StatusCode("Revoked", 4, 4);
    public static final StatusCode InvalidEncoding = new StatusCode("InvalidEncoding", 5, 5);
    public static final StatusCode InvalidExtension = new StatusCode("InvalidExtension", 6, 6);

    private static final /* synthetic */ StatusCode[] $values() {
        return new StatusCode[]{Ok, Unavailable, Expired, UnknownCert, Revoked, InvalidEncoding, InvalidExtension};
    }

    static {
        StatusCode[] statusCodeArr$values = $values();
        $VALUES = statusCodeArr$values;
        $ENTRIES = mms.R(statusCodeArr$values);
    }

    private StatusCode(String str, int i, int i2) {
        this.value = i2;
    }

    public static EnumEntries getEntries() {
        return $ENTRIES;
    }

    public static StatusCode valueOf(String str) {
        return (StatusCode) Enum.valueOf(StatusCode.class, str);
    }

    public static StatusCode[] values() {
        return (StatusCode[]) $VALUES.clone();
    }

    public final int getValue() {
        return this.value;
    }
}
