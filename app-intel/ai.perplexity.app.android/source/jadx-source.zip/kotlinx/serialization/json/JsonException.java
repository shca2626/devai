package kotlinx.serialization.json;

import kotlinx.serialization.SerializationException;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public abstract class JsonException extends SerializationException {
    public final String w;

    public JsonException(String str) {
        super(str);
        this.w = str;
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.w;
    }
}
