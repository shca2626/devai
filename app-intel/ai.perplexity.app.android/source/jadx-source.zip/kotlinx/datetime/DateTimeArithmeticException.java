package kotlinx.datetime;

import java.time.DateTimeException;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes4.dex */
public final class DateTimeArithmeticException extends RuntimeException {
    public DateTimeArithmeticException(DateTimeException dateTimeException) {
        super(dateTimeException);
    }

    public DateTimeArithmeticException(String str, Exception exc) {
        super(str, exc);
    }
}
