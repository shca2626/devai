package kotlinx.coroutines.internal;

import defpackage.vb6;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class DiagnosticCoroutineContextException extends RuntimeException {
    public final transient vb6 w;

    public DiagnosticCoroutineContextException(vb6 vb6Var) {
        this.w = vb6Var;
    }

    @Override // java.lang.Throwable
    public final Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }

    @Override // java.lang.Throwable
    public final String getLocalizedMessage() {
        return String.valueOf(this.w);
    }
}
