package ai.perplexity.multimodal.audio;

import kotlin.jvm.functions.Function0;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public interface AudioSessionBackend {
    void abandonAssistantFocus();

    boolean configureCommunication();

    boolean requestAssistantFocus(Function0 function0);

    void restoreCommunication();
}
