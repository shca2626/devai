package ai.perplexity.multimodal.audio;

import defpackage.wf6;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class MicrophoneConfig {
    private final boolean muted;

    public /* synthetic */ MicrophoneConfig(boolean z, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? false : z);
    }

    public static /* synthetic */ MicrophoneConfig copy$default(MicrophoneConfig microphoneConfig, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = microphoneConfig.muted;
        }
        return microphoneConfig.copy(z);
    }

    public final boolean component1() {
        return this.muted;
    }

    public final MicrophoneConfig copy(boolean z) {
        return new MicrophoneConfig(z);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof MicrophoneConfig) && this.muted == ((MicrophoneConfig) obj).muted;
    }

    public final boolean getMuted() {
        return this.muted;
    }

    public int hashCode() {
        return Boolean.hashCode(this.muted);
    }

    public String toString() {
        return wf6.l("MicrophoneConfig(muted=", ")", this.muted);
    }

    public MicrophoneConfig(boolean z) {
        this.muted = z;
    }

    public MicrophoneConfig() {
        this(false, 1, null);
    }
}
