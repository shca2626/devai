package ai.perplexity.multimodal.audio;

import defpackage.wc6;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class MicLevel {
    private final float peak;
    private final float rms;

    public MicLevel(float f, float f2) {
        this.rms = f;
        this.peak = f2;
    }

    public static /* synthetic */ MicLevel copy$default(MicLevel micLevel, float f, float f2, int i, Object obj) {
        if ((i & 1) != 0) {
            f = micLevel.rms;
        }
        if ((i & 2) != 0) {
            f2 = micLevel.peak;
        }
        return micLevel.copy(f, f2);
    }

    public final float component1() {
        return this.rms;
    }

    public final float component2() {
        return this.peak;
    }

    public final MicLevel copy(float f, float f2) {
        return new MicLevel(f, f2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MicLevel)) {
            return false;
        }
        MicLevel micLevel = (MicLevel) obj;
        return Float.compare(this.rms, micLevel.rms) == 0 && Float.compare(this.peak, micLevel.peak) == 0;
    }

    public final float getPeak() {
        return this.peak;
    }

    public final float getRms() {
        return this.rms;
    }

    public int hashCode() {
        return Float.hashCode(this.peak) + (Float.hashCode(this.rms) * 31);
    }

    public String toString() {
        return wc6.n("MicLevel(rms=", this.rms, ", peak=", this.peak, ")");
    }
}
