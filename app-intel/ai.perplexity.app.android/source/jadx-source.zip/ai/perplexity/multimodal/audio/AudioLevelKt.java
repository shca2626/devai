package ai.perplexity.multimodal.audio;

import uniffi.multimodal_uniffi.FfiAudioLevel;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class AudioLevelKt {
    public static final AudioLevel toPublic(FfiAudioLevel ffiAudioLevel) {
        ffiAudioLevel.getClass();
        return new AudioLevel(ffiAudioLevel.getRms(), ffiAudioLevel.getPeak());
    }
}
