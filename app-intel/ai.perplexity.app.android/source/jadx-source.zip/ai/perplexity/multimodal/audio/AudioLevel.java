package ai.perplexity.multimodal.audio;

import defpackage.wc6;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class AudioLevel {
    public static final Companion Companion = new Companion(null);
    private static final AudioLevel ZERO = new AudioLevel(0.0f, 0.0f);
    private final float peak;
    private final float rms;

    public AudioLevel(float f, float f2) {
        this.rms = f;
        this.peak = f2;
    }

    public static /* synthetic */ AudioLevel copy$default(AudioLevel audioLevel, float f, float f2, int i, Object obj) {
        if ((i & 1) != 0) {
            f = audioLevel.rms;
        }
        if ((i & 2) != 0) {
            f2 = audioLevel.peak;
        }
        return audioLevel.copy(f, f2);
    }

    public final float component1() {
        return this.rms;
    }

    public final float component2() {
        return this.peak;
    }

    public final AudioLevel copy(float f, float f2) {
        return new AudioLevel(f, f2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AudioLevel)) {
            return false;
        }
        AudioLevel audioLevel = (AudioLevel) obj;
        return Float.compare(this.rms, audioLevel.rms) == 0 && Float.compare(this.peak, audioLevel.peak) == 0;
    }

    public final float getPeak() {
        return this.peak;
    }

    public final float getRms() {
        return this.rms;
    }

    public int hashCode() {
        return Float.hashCode(this.peak) + (Float.hashCode(this.rms) * 31);
    }

    public String toString() {
        return wc6.n("AudioLevel(rms=", this.rms, ", peak=", this.peak, ")");
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final AudioLevel getZERO() {
            return AudioLevel.ZERO;
        }

        private Companion() {
        }
    }
}
