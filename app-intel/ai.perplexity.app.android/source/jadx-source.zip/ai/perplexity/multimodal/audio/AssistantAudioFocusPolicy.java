package ai.perplexity.multimodal.audio;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class AssistantAudioFocusPolicy {
    public static final int CONTENT_TYPE = 1;
    public static final int GAIN = 4;
    public static final AssistantAudioFocusPolicy INSTANCE = new AssistantAudioFocusPolicy();
    public static final int USAGE = 16;

    private AssistantAudioFocusPolicy() {
    }
}
