package ai.perplexity.multimodal.util;

import defpackage.jll;
import java.util.concurrent.CancellationException;
import kotlin.jvm.functions.Function0;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class ResultOfKt {
    public static final <R> Object resultOf(Function0 function0) {
        function0.getClass();
        try {
            return function0.invoke();
        } catch (CancellationException e) {
            throw e;
        } catch (Throwable th) {
            return new jll(th);
        }
    }
}
