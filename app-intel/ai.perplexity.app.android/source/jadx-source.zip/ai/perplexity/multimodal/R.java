package ai.perplexity.multimodal;

/* loaded from: classes2.dex */
public final class R {
    private R() {
    }
}
