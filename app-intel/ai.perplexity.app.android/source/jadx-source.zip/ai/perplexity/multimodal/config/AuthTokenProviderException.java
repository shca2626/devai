package ai.perplexity.multimodal.config;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public abstract class AuthTokenProviderException extends Exception {

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    /* loaded from: classes2.dex */
    public static final class NetworkError extends AuthTokenProviderException {
        private final String detail;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public NetworkError(String str) {
            super(str, null);
            str.getClass();
            this.detail = str;
        }

        public final String getDetail() {
            return this.detail;
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    /* loaded from: classes2.dex */
    public static final class NotAuthenticated extends AuthTokenProviderException {
        public NotAuthenticated() {
            super("Not authenticated", null);
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    /* loaded from: classes2.dex */
    public static final class Other extends AuthTokenProviderException {
        private final String code;
        private final String detail;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Other(String str, String str2) {
            super(str2, null);
            str.getClass();
            str2.getClass();
            this.code = str;
            this.detail = str2;
        }

        public final String getCode() {
            return this.code;
        }

        public final String getDetail() {
            return this.detail;
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    /* loaded from: classes2.dex */
    public static final class RefreshFailed extends AuthTokenProviderException {
        private final String detail;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public RefreshFailed(String str) {
            super(str, null);
            str.getClass();
            this.detail = str;
        }

        public final String getDetail() {
            return this.detail;
        }
    }

    public /* synthetic */ AuthTokenProviderException(String str, DefaultConstructorMarker defaultConstructorMarker) {
        this(str);
    }

    private AuthTokenProviderException(String str) {
        super(str);
    }
}
