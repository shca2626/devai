package ai.perplexity.multimodal.config;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public interface FeatureFlagProvider {
    /* renamed from: getBooleanFlag-s8GSzPY, reason: not valid java name */
    boolean mo35getBooleanFlags8GSzPY(String str);

    /* renamed from: getIntFlag-s8GSzPY, reason: not valid java name */
    long mo36getIntFlags8GSzPY(String str);

    /* renamed from: getJsonFlag-s8GSzPY, reason: not valid java name */
    String mo37getJsonFlags8GSzPY(String str);

    /* renamed from: getStringFlag-s8GSzPY, reason: not valid java name */
    String mo38getStringFlags8GSzPY(String str);
}
