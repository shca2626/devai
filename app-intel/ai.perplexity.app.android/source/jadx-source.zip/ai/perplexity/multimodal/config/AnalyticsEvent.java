package ai.perplexity.multimodal.config;

import defpackage.n6b;
import java.util.Map;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class AnalyticsEvent {
    private final Map<String, Object> data;
    private final String name;

    public AnalyticsEvent(String str, Map<String, ? extends Object> map) {
        str.getClass();
        map.getClass();
        this.name = str;
        this.data = map;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ AnalyticsEvent copy$default(AnalyticsEvent analyticsEvent, String str, Map map, int i, Object obj) {
        if ((i & 1) != 0) {
            str = analyticsEvent.name;
        }
        if ((i & 2) != 0) {
            map = analyticsEvent.data;
        }
        return analyticsEvent.copy(str, map);
    }

    public final String component1() {
        return this.name;
    }

    public final Map<String, Object> component2() {
        return this.data;
    }

    public final AnalyticsEvent copy(String str, Map<String, ? extends Object> map) {
        str.getClass();
        map.getClass();
        return new AnalyticsEvent(str, map);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AnalyticsEvent)) {
            return false;
        }
        AnalyticsEvent analyticsEvent = (AnalyticsEvent) obj;
        return n6b.k(this.name, analyticsEvent.name) && n6b.k(this.data, analyticsEvent.data);
    }

    public final Map<String, Object> getData() {
        return this.data;
    }

    public final String getName() {
        return this.name;
    }

    public int hashCode() {
        return this.data.hashCode() + (this.name.hashCode() * 31);
    }

    public String toString() {
        return "AnalyticsEvent(name=" + this.name + ", data=" + this.data + ")";
    }
}
