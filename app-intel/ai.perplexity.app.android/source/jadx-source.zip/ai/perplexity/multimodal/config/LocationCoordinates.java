package ai.perplexity.multimodal.config;

import defpackage.w5h;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes4.dex */
public final class LocationCoordinates {
    private final double latitude;
    private final double longitude;

    public LocationCoordinates(double d, double d2) {
        this.latitude = d;
        this.longitude = d2;
    }

    public static /* synthetic */ LocationCoordinates copy$default(LocationCoordinates locationCoordinates, double d, double d2, int i, Object obj) {
        if ((i & 1) != 0) {
            d = locationCoordinates.latitude;
        }
        if ((i & 2) != 0) {
            d2 = locationCoordinates.longitude;
        }
        return locationCoordinates.copy(d, d2);
    }

    public final double component1() {
        return this.latitude;
    }

    public final double component2() {
        return this.longitude;
    }

    public final LocationCoordinates copy(double d, double d2) {
        return new LocationCoordinates(d, d2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LocationCoordinates)) {
            return false;
        }
        LocationCoordinates locationCoordinates = (LocationCoordinates) obj;
        return Double.compare(this.latitude, locationCoordinates.latitude) == 0 && Double.compare(this.longitude, locationCoordinates.longitude) == 0;
    }

    public final double getLatitude() {
        return this.latitude;
    }

    public final double getLongitude() {
        return this.longitude;
    }

    public int hashCode() {
        return Double.hashCode(this.longitude) + (Double.hashCode(this.latitude) * 31);
    }

    public String toString() {
        double d = this.latitude;
        double d2 = this.longitude;
        StringBuilder sbT = w5h.t("LocationCoordinates(latitude=", ", longitude=", d);
        sbT.append(d2);
        sbT.append(")");
        return sbT.toString();
    }
}
