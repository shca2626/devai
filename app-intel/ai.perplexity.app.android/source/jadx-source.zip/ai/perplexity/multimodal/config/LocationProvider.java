package ai.perplexity.multimodal.config;

import defpackage.m16;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public interface LocationProvider {
    Object location(m16<? super LocationCoordinates> m16Var);
}
