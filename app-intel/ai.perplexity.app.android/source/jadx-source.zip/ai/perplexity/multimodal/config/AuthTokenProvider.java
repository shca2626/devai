package ai.perplexity.multimodal.config;

import defpackage.m16;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public interface AuthTokenProvider {
    /* renamed from: activeAccount-rjeIlyo, reason: not valid java name */
    Object mo26activeAccountrjeIlyo(m16<? super AccountId> m16Var);

    /* renamed from: token-wbCbz2k, reason: not valid java name */
    Object mo27tokenwbCbz2k(String str, m16<? super String> m16Var);
}
