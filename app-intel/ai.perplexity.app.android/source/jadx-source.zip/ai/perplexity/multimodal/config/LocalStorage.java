package ai.perplexity.multimodal.config;

import defpackage.hmq;
import defpackage.m16;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public interface LocalStorage {
    Object delete(String str, m16<? super hmq> m16Var);

    Object get(String str, m16<? super String> m16Var);

    Object set(String str, String str2, m16<? super hmq> m16Var);
}
