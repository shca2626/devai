package ai.perplexity.multimodal.config;

import defpackage.etb;
import defpackage.n6b;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public final class AccountId {
    public static final Companion Companion = new Companion(null);
    private final String value;

    private /* synthetic */ AccountId(String str) {
        this.value = str;
    }

    /* renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ AccountId m18boximpl(String str) {
        return new AccountId(str);
    }

    /* renamed from: equals-impl, reason: not valid java name */
    public static boolean m20equalsimpl(String str, Object obj) {
        return (obj instanceof AccountId) && n6b.k(str, ((AccountId) obj).m24unboximpl());
    }

    /* renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m21equalsimpl0(String str, String str2) {
        return n6b.k(str, str2);
    }

    /* renamed from: hashCode-impl, reason: not valid java name */
    public static int m22hashCodeimpl(String str) {
        return str.hashCode();
    }

    /* renamed from: toString-impl, reason: not valid java name */
    public static String m23toStringimpl(String str) {
        return etb.l("AccountId(value=", str, ")");
    }

    public boolean equals(Object obj) {
        return m20equalsimpl(this.value, obj);
    }

    public final String getValue() {
        return this.value;
    }

    public int hashCode() {
        return m22hashCodeimpl(this.value);
    }

    public String toString() {
        return m23toStringimpl(this.value);
    }

    /* renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ String m24unboximpl() {
        return this.value;
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    /* loaded from: classes2.dex */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* renamed from: create-rjeIlyo, reason: not valid java name */
        public final String m25createrjeIlyo(String str) {
            str.getClass();
            if (str.length() == 0) {
                return null;
            }
            return AccountId.m19constructorimpl(str);
        }

        private Companion() {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: constructor-impl, reason: not valid java name */
    public static String m19constructorimpl(String str) {
        return str;
    }
}
