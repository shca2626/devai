package ai.perplexity.multimodal.ondevice.api;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public abstract class OnDeviceException extends Exception {

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class InvalidSpec extends OnDeviceException {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public InvalidSpec(String str) {
            super(str, null);
            str.getClass();
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Io extends OnDeviceException {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Io(String str) {
            super(str, null);
            str.getClass();
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class MissingProvider extends OnDeviceException {
        private final String provider;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public MissingProvider(String str) {
            super("Missing provider: ".concat(str), null);
            str.getClass();
            this.provider = str;
        }

        public final String getProvider() {
            return this.provider;
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Network extends OnDeviceException {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Network(String str) {
            super(str, null);
            str.getClass();
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Other extends OnDeviceException {
        private final String code;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Other(String str, String str2) {
            super(str2, null);
            str.getClass();
            str2.getClass();
            this.code = str;
        }

        public final String getCode() {
            return this.code;
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Provider extends OnDeviceException {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Provider(String str) {
            super(str, null);
            str.getClass();
        }
    }

    public /* synthetic */ OnDeviceException(String str, DefaultConstructorMarker defaultConstructorMarker) {
        this(str);
    }

    private OnDeviceException(String str) {
        super(str);
    }
}
