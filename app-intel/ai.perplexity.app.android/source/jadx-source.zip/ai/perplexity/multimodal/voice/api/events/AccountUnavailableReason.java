package ai.perplexity.multimodal.voice.api.events;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public interface AccountUnavailableReason {

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class InvalidAccountId implements AccountUnavailableReason {
        public static final InvalidAccountId INSTANCE = new InvalidAccountId();

        private InvalidAccountId() {
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof InvalidAccountId);
        }

        public int hashCode() {
            return 949512455;
        }

        public String toString() {
            return "InvalidAccountId";
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class LookupFailed implements AccountUnavailableReason {
        public static final LookupFailed INSTANCE = new LookupFailed();

        private LookupFailed() {
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof LookupFailed);
        }

        public int hashCode() {
            return 1582422637;
        }

        public String toString() {
            return "LookupFailed";
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class NoActiveAccount implements AccountUnavailableReason {
        public static final NoActiveAccount INSTANCE = new NoActiveAccount();

        private NoActiveAccount() {
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof NoActiveAccount);
        }

        public int hashCode() {
            return -2013241296;
        }

        public String toString() {
            return "NoActiveAccount";
        }
    }
}
