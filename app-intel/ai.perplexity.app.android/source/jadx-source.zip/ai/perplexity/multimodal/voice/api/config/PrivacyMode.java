package ai.perplexity.multimodal.voice.api.config;

import defpackage.mms;
import kotlin.enums.EnumEntries;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class PrivacyMode {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ PrivacyMode[] $VALUES;
    public static final PrivacyMode Tracked = new PrivacyMode("Tracked", 0);
    public static final PrivacyMode Incognito = new PrivacyMode("Incognito", 1);

    private static final /* synthetic */ PrivacyMode[] $values() {
        return new PrivacyMode[]{Tracked, Incognito};
    }

    static {
        PrivacyMode[] privacyModeArr$values = $values();
        $VALUES = privacyModeArr$values;
        $ENTRIES = mms.R(privacyModeArr$values);
    }

    private PrivacyMode(String str, int i) {
    }

    public static EnumEntries getEntries() {
        return $ENTRIES;
    }

    public static PrivacyMode valueOf(String str) {
        return (PrivacyMode) Enum.valueOf(PrivacyMode.class, str);
    }

    public static PrivacyMode[] values() {
        return (PrivacyMode[]) $VALUES.clone();
    }
}
