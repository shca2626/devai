package ai.perplexity.multimodal.voice.api;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class ToolContext {
    private final String account;
    private final String sessionId;

    private ToolContext(String str, String str2) {
        str.getClass();
        str2.getClass();
        this.sessionId = str;
        this.account = str2;
    }

    /* renamed from: getAccount-nEyPBB8, reason: not valid java name */
    public final String m188getAccountnEyPBB8() {
        return this.account;
    }

    public final String getSessionId() {
        return this.sessionId;
    }

    public /* synthetic */ ToolContext(String str, String str2, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2);
    }
}
