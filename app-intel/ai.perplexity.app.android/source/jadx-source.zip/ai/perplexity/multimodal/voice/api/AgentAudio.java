package ai.perplexity.multimodal.voice.api;

import defpackage.i6o;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public interface AgentAudio {
    i6o getState();

    void mute(boolean z);

    void toggleMute();
}
