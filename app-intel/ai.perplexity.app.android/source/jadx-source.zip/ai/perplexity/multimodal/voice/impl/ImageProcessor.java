package ai.perplexity.multimodal.voice.impl;

import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class ImageProcessor {
    public static final ImageProcessor INSTANCE = new ImageProcessor();
    private static final int JPEG_QUALITY = 85;
    private static final int MAX_DIMENSION = 1024;

    private ImageProcessor() {
    }

    private final byte[] compressToJPEG(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        byteArray.getClass();
        return byteArray;
    }

    private final Bitmap resizeIfNeeded(Bitmap bitmap) {
        int iMax = Math.max(bitmap.getWidth(), bitmap.getHeight());
        if (iMax <= MAX_DIMENSION) {
            return bitmap;
        }
        float f = 1024.0f / iMax;
        Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmap, (int) (bitmap.getWidth() * f), (int) (bitmap.getHeight() * f), true);
        bitmapCreateScaledBitmap.getClass();
        return bitmapCreateScaledBitmap;
    }

    public final byte[] processForContext(Bitmap bitmap) {
        bitmap.getClass();
        Bitmap bitmapResizeIfNeeded = resizeIfNeeded(bitmap);
        byte[] bArrCompressToJPEG = compressToJPEG(bitmapResizeIfNeeded);
        if (bitmapResizeIfNeeded != bitmap) {
            bitmapResizeIfNeeded.recycle();
        }
        return bArrCompressToJPEG;
    }
}
