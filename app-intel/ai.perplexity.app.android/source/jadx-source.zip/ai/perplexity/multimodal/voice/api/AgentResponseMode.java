package ai.perplexity.multimodal.voice.api;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public interface AgentResponseMode {

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Allow implements AgentResponseMode {
        public static final Allow INSTANCE = new Allow();

        private Allow() {
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof Allow);
        }

        public int hashCode() {
            return 1352270048;
        }

        public String toString() {
            return "Allow";
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Deny implements AgentResponseMode {
        public static final Deny INSTANCE = new Deny();

        private Deny() {
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof Deny);
        }

        public int hashCode() {
            return 459346325;
        }

        public String toString() {
            return "Deny";
        }
    }
}
