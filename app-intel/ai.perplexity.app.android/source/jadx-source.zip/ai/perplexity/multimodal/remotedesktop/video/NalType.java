package ai.perplexity.multimodal.remotedesktop.video;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class NalType {
    public static final NalType INSTANCE = new NalType();
    public static final int PPS = 8;
    public static final int SPS = 7;

    private NalType() {
    }
}
