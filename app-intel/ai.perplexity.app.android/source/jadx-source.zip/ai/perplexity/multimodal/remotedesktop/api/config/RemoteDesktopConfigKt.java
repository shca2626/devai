package ai.perplexity.multimodal.remotedesktop.api.config;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class RemoteDesktopConfigKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean isUnicodeWhiteSpace(char c) {
        if (('\t' <= c && c < 14) || c == ' ' || c == 133 || c == 160 || c == 5760) {
            return true;
        }
        return (8192 <= c && c < 8203) || c == 8232 || c == 8233 || c == 8239 || c == 8287 || c == 12288;
    }
}
