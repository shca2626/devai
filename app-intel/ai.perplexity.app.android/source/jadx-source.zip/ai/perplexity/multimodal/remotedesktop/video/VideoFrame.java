package ai.perplexity.multimodal.remotedesktop.video;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class VideoFrame {
    private final byte[] data;
    private final boolean isFull;

    public VideoFrame(byte[] bArr, boolean z) {
        bArr.getClass();
        this.data = bArr;
        this.isFull = z;
    }

    public final byte[] getData() {
        return this.data;
    }

    public final boolean isFull() {
        return this.isFull;
    }
}
