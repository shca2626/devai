package ai.perplexity.multimodal.remotedesktop.api.input;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public abstract class RemoteDesktopInputError extends Exception {

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class Busy extends RemoteDesktopInputError {
        public static final Busy INSTANCE = new Busy();

        private Busy() {
            super("Remote desktop input queue is full", null);
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof Busy);
        }

        public int hashCode() {
            return -414049065;
        }

        @Override // java.lang.Throwable
        public String toString() {
            return "Busy";
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class NotConnected extends RemoteDesktopInputError {
        public static final NotConnected INSTANCE = new NotConnected();

        private NotConnected() {
            super("Remote desktop is not connected", null);
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof NotConnected);
        }

        public int hashCode() {
            return -1966869932;
        }

        @Override // java.lang.Throwable
        public String toString() {
            return "NotConnected";
        }
    }

    /* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
    public static final class NotControlling extends RemoteDesktopInputError {
        public static final NotControlling INSTANCE = new NotControlling();

        private NotControlling() {
            super("Remote desktop control is not held", null);
        }

        public boolean equals(Object obj) {
            return this == obj || (obj instanceof NotControlling);
        }

        public int hashCode() {
            return 479557470;
        }

        @Override // java.lang.Throwable
        public String toString() {
            return "NotControlling";
        }
    }

    public /* synthetic */ RemoteDesktopInputError(String str, DefaultConstructorMarker defaultConstructorMarker) {
        this(str);
    }

    private RemoteDesktopInputError(String str) {
        super(str);
    }
}
