package ai.perplexity.multimodal.remotedesktop.video;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class NalUnit {
    private final int end;
    private final int start;
    private final int type;

    public NalUnit(int i, int i2, int i3) {
        this.start = i;
        this.end = i2;
        this.type = i3;
    }

    public final int getEnd() {
        return this.end;
    }

    public final int getStart() {
        return this.start;
    }

    public final int getType() {
        return this.type;
    }
}
