package ai.perplexity.app.android.authorization.impl.exception;

import ai.perplexity.app.android.R;
import ai.perplexity.shared.common.util.user.UserFacingException;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class SignInMustUseSsoException extends UserFacingException.ResourceUserFacingException {
    public final String X;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SignInMustUseSsoException(String str, String str2) {
        super(R.string.message_signin_must_use_sso, str2, null, false, null, 28);
        str.getClass();
        this.X = str;
    }
}
