package ai.perplexity.app.android.dictation.api.speech;

import defpackage.gqe;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class MultimodalSpeechRecognitionUnavailableException extends RuntimeException {
    public final gqe w;

    public MultimodalSpeechRecognitionUnavailableException() {
        super("MultimodalSDK is not initialized yet.", null);
        this.w = gqe.w;
    }

    public MultimodalSpeechRecognitionUnavailableException(gqe gqeVar, String str, Throwable th) {
        super(str, th);
        this.w = gqeVar;
    }
}
