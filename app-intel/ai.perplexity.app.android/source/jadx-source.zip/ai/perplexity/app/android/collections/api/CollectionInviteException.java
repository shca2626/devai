package ai.perplexity.app.android.collections.api;

import defpackage.f84;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes2.dex */
public final class CollectionInviteException extends Exception {
    public final f84 w;

    public CollectionInviteException(f84 f84Var, String str) {
        super(str);
        this.w = f84Var;
    }
}
