package ai.perplexity.app.android.common.util;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.os.StrictMode;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class PhoenixActivityCopy extends Activity {
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int intExtra = getIntent().getIntExtra("phoenix_main_process_pid", -1);
        ArrayList parcelableArrayListExtra = getIntent().getParcelableArrayListExtra("phoenix_restart_intents");
        if (intExtra > 0 && parcelableArrayListExtra != null && !parcelableArrayListExtra.isEmpty()) {
            if (!parcelableArrayListExtra.isEmpty()) {
                Iterator it = parcelableArrayListExtra.iterator();
                while (it.hasNext()) {
                    if (((Intent) it.next()) == null) {
                    }
                }
            }
            Process.killProcess(intExtra);
            if (Build.VERSION.SDK_INT > 31) {
                StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder(StrictMode.getVmPolicy()).permitUnsafeIntentLaunch().build());
            }
            startActivities((Intent[]) parcelableArrayListExtra.toArray(new Intent[0]));
            finish();
            Runtime.getRuntime().exit(0);
            return;
        }
        finish();
    }
}
