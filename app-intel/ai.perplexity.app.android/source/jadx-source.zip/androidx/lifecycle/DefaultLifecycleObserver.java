package androidx.lifecycle;

import defpackage.m8c;
import defpackage.n8c;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public interface DefaultLifecycleObserver extends m8c {
    default void onCreate(n8c n8cVar) {
    }

    default void onDestroy(n8c n8cVar) {
    }

    default void onPause(n8c n8cVar) {
    }

    default void onResume(n8c n8cVar) {
    }

    default void onStart(n8c n8cVar) {
    }

    default void onStop(n8c n8cVar) {
    }
}
