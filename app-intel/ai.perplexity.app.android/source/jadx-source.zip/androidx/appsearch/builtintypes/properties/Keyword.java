package androidx.appsearch.builtintypes.properties;

import com.singular.sdk.BuildConfig;
import java.util.Objects;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class Keyword {
    public String a = BuildConfig.FLAVOR;
    public String b = BuildConfig.FLAVOR;
    public final String c;

    public Keyword(String str) {
        str.getClass();
        this.c = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || Keyword.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.c, ((Keyword) obj).c);
    }

    public final int hashCode() {
        return Objects.hashCode(this.c);
    }
}
