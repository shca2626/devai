package androidx.appsearch.builtintypes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class ImageObject extends Thing {
    public final List l;
    public final String m;
    public final String n;
    public final byte[] o;

    public ImageObject(String str, String str2, int i, long j, long j2, String str3, List list, String str4, String str5, String str6, ArrayList arrayList, ArrayList arrayList2, String str7, String str8, byte[] bArr) {
        super(str, str2, i, j, j2, str3, list, str4, str5, str6, arrayList);
        arrayList2.getClass();
        this.l = arrayList2;
        this.m = str7;
        this.n = str8;
        this.o = bArr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || ImageObject.class != obj.getClass()) {
            return false;
        }
        ImageObject imageObject = (ImageObject) obj;
        return this.l.equals(imageObject.l) && Objects.equals(this.m, imageObject.m) && Objects.equals(this.n, imageObject.n) && Arrays.equals(this.o, imageObject.o);
    }

    public final int hashCode() {
        return Objects.hash(this.l, this.m, this.n, Integer.valueOf(Arrays.hashCode(this.o)));
    }
}
