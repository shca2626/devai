package androidx.appsearch.builtintypes;

import java.util.ArrayList;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class AlarmInstance extends Thing {
    public final String l;
    public final int m;
    public final long n;

    public AlarmInstance(String str, String str2, int i, long j, long j2, String str3, ArrayList arrayList, String str4, String str5, String str6, ArrayList arrayList2, String str7, int i2, long j3) {
        super(str, str2, i, j, j2, str3, arrayList, str4, str5, str6, arrayList2);
        str7.getClass();
        this.l = str7;
        this.m = i2;
        this.n = j3;
    }
}
