package androidx.appsearch.builtintypes;

import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class GlobalSearchApplicationInfo {
    public final String a;
    public final String b;
    public final int c;
    public final List d;

    public GlobalSearchApplicationInfo(int i, String str, String str2, List list) {
        str.getClass();
        this.a = str;
        str2.getClass();
        this.b = str2;
        this.c = i;
        this.d = Collections.unmodifiableList(list);
    }
}
