package androidx.appsearch.builtintypes;

import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class Thing {
    public final String a;
    public final String b;
    public final int c;
    public final long d;
    public final long e;
    public final String f;
    public final List g;
    public final String h;
    public final String i;
    public final String j;
    public final List k;

    public Thing(String str, String str2, int i, long j, long j2, String str3, List list, String str4, String str5, String str6, List list2) {
        str.getClass();
        this.a = str;
        str2.getClass();
        this.b = str2;
        this.c = i;
        this.d = j;
        this.e = j2;
        this.f = str3;
        if (list == null) {
            this.g = Collections.EMPTY_LIST;
        } else {
            this.g = Collections.unmodifiableList(list);
        }
        this.h = str4;
        this.i = str5;
        this.j = str6;
        if (list2 == null) {
            this.k = Collections.EMPTY_LIST;
        } else {
            this.k = Collections.unmodifiableList(list2);
        }
    }

    public List a() {
        return this.g;
    }
}
