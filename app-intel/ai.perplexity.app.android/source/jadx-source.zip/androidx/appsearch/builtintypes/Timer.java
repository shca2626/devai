package androidx.appsearch.builtintypes;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class Timer extends Thing {
    public final long l;
    public final long m;
    public final long n;
    public final long o;
    public final long p;
    public final int q;
    public final long r;
    public final String s;
    public final int t;
    public final boolean u;

    public Timer(String str, String str2, int i, long j, long j2, String str3, List list, String str4, String str5, String str6, ArrayList arrayList, long j3, long j4, long j5, long j6, long j7, int i2, long j8, String str7, int i3, boolean z) {
        super(str, str2, i, j, j2, str3, list, str4, str5, str6, arrayList);
        this.l = j3;
        this.m = j4;
        this.n = j5;
        this.o = j6;
        this.p = j7;
        this.q = i2;
        this.r = j8;
        this.s = str7;
        this.t = i3;
        this.u = z;
    }
}
