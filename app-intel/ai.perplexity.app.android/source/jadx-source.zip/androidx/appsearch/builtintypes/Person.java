package androidx.appsearch.builtintypes;

import defpackage.y9g;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class Person extends Thing {
    public final String l;
    public final String m;
    public final String n;
    public final String o;
    public final String p;
    public final boolean q;
    public final boolean r;
    public final List s;
    public final List t;
    public final List u;
    public final List v;
    public final List w;
    public final List x;
    public final List y;

    public Person(String str, String str2, int i, long j, long j2, String str3, List list, String str4, String str5, String str6, ArrayList arrayList, String str7, String str8, String str9, String str10, String str11, boolean z, boolean z2, List list2, ArrayList arrayList2, List list3, List list4, List list5, ArrayList arrayList3) {
        super(str, str2, i, j, j2, str3, list, str4, str5, str6, arrayList);
        this.l = str7;
        this.m = str8;
        this.n = str9;
        this.o = str10;
        this.p = str11;
        this.q = z;
        this.r = z2;
        this.s = Collections.unmodifiableList(list2);
        List listUnmodifiableList = Collections.unmodifiableList(arrayList2);
        this.t = listUnmodifiableList;
        this.u = Collections.unmodifiableList(list3);
        this.v = Collections.unmodifiableList(list4);
        this.w = Collections.unmodifiableList(list5);
        this.x = Collections.unmodifiableList(arrayList3);
        ArrayList arrayList4 = new ArrayList(listUnmodifiableList.size());
        for (int i2 = 0; i2 < this.t.size(); i2++) {
            arrayList4.add(new y9g(((Long) this.t.get(i2)).intValue(), (String) this.u.get(i2)));
        }
        this.y = Collections.unmodifiableList(arrayList4);
    }
}
