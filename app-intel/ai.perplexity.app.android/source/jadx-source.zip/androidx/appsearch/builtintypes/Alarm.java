package androidx.appsearch.builtintypes;

import java.util.ArrayList;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class Alarm extends Thing {
    public final boolean l;
    public final int[] m;
    public final int n;
    public final int o;
    public final String p;
    public final String q;
    public final String r;
    public final boolean s;
    public final AlarmInstance t;
    public final AlarmInstance u;
    public final int v;

    public Alarm(String str, String str2, int i, long j, long j2, String str3, ArrayList arrayList, String str4, String str5, String str6, ArrayList arrayList2, boolean z, int[] iArr, int i2, int i3, String str7, String str8, String str9, boolean z2, AlarmInstance alarmInstance, AlarmInstance alarmInstance2, int i4) {
        super(str, str2, i, j, j2, str3, arrayList, str4, str5, str6, arrayList2);
        this.l = z;
        this.m = iArr;
        this.n = i2;
        this.o = i3;
        this.p = str7;
        this.q = str8;
        this.r = str9;
        this.s = z2;
        this.t = alarmInstance;
        this.u = alarmInstance2;
        this.v = i4;
    }
}
