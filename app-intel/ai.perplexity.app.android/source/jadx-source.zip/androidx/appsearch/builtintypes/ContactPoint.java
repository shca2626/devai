package androidx.appsearch.builtintypes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class ContactPoint extends Thing {
    public final String l;
    public final List m;
    public final List n;
    public final List o;

    public ContactPoint(String str, String str2, int i, long j, long j2, String str3, ArrayList arrayList, String str4, String str5, String str6, ArrayList arrayList2, String str7, ArrayList arrayList3, ArrayList arrayList4, ArrayList arrayList5) {
        super(str, str2, i, j, j2, str3, arrayList, str4, str5, str6, arrayList2);
        this.l = str7;
        this.m = Collections.unmodifiableList(arrayList3);
        this.n = Collections.unmodifiableList(arrayList4);
        this.o = Collections.unmodifiableList(arrayList5);
    }
}
