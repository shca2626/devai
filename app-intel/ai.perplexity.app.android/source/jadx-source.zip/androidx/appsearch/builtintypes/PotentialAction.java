package androidx.appsearch.builtintypes;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class PotentialAction {
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;

    public PotentialAction(String str, String str2, String str3, String str4, String str5) {
        str.getClass();
        this.a = str;
        str2.getClass();
        this.b = str2;
        this.c = str3;
        this.d = str4;
        this.e = str5;
    }
}
