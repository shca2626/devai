package androidx.appsearch.builtintypes;

import android.net.Uri;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class MobileApplication extends Thing {
    public final String l;
    public final String m;
    public final List n;
    public final Uri o;
    public final byte[] p;
    public final long q;
    public final String r;

    public MobileApplication(String str, String str2, int i, long j, long j2, String str3, List list, String str4, String str5, String str6, ArrayList arrayList, String str7, String str8, Uri uri, byte[] bArr, long j3, String str9) {
        super(str, str2, i, j, j2, str3, list, str4, str5, str6, arrayList);
        str7.getClass();
        this.l = str7;
        this.m = str8;
        if (list == null) {
            this.n = Collections.EMPTY_LIST;
        } else {
            this.n = Collections.unmodifiableList(list);
        }
        this.o = uri;
        bArr.getClass();
        this.p = bArr;
        this.q = j3;
        this.r = str9;
    }

    @Override // androidx.appsearch.builtintypes.Thing
    public final List a() {
        return this.n;
    }
}
