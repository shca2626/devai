package androidx.appsearch.usagereporting;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public abstract class TakenAction {
    public final String a;
    public final String b;
    public final long c;
    public final long d;
    public final int e;

    public TakenAction(int i, long j, long j2, String str, String str2) {
        str.getClass();
        this.a = str;
        str2.getClass();
        this.b = str2;
        this.c = j;
        this.d = j2;
        this.e = i;
    }
}
