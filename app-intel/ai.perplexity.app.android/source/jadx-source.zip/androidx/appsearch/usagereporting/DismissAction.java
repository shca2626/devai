package androidx.appsearch.usagereporting;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class DismissAction extends TakenAction {
    public final String f;
    public final String g;
    public final int h;
    public final int i;

    public DismissAction(String str, String str2, long j, long j2, int i, String str3, String str4, int i2, int i3) {
        super(i, j, j2, str, str2);
        this.f = str3;
        this.g = str4;
        this.h = i2;
        this.i = i3;
    }
}
