package androidx.compose.material;

import androidx.compose.material.internal.PlatformOptimizedCancellationException;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class AnchoredDragFinishedSignal extends PlatformOptimizedCancellationException {
    public AnchoredDragFinishedSignal() {
        super("Anchored drag finished");
    }
}
