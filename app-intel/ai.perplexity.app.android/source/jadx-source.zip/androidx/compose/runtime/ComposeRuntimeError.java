package androidx.compose.runtime;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class ComposeRuntimeError extends IllegalStateException {
    public final String w;

    public ComposeRuntimeError(String str) {
        this.w = str;
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.w;
    }
}
