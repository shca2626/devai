package androidx.compose.ui.input.pointer;

import defpackage.e3h;
import defpackage.hmq;
import defpackage.m16;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public interface PointerInputEventHandler {
    Object invoke(e3h e3hVar, m16<? super hmq> m16Var);
}
