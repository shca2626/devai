package androidx.media3.muxer;

import defpackage.c3e;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class MuxerException extends Exception {
    static {
        c3e.a("media3.muxer");
    }
}
