package androidx.media3.exoplayer.mediacodec;

import android.media.MediaCodec;
import androidx.media3.decoder.DecoderException;
import defpackage.tyd;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class MediaCodecDecoderException extends DecoderException {
    public final int w;

    public MediaCodecDecoderException(IllegalStateException illegalStateException, tyd tydVar) {
        StringBuilder sb = new StringBuilder("Decoder failed: ");
        sb.append(tydVar == null ? null : tydVar.a);
        super(sb.toString(), illegalStateException);
        boolean z = illegalStateException instanceof MediaCodec.CodecException;
        if (z) {
            ((MediaCodec.CodecException) illegalStateException).getDiagnosticInfo();
        }
        this.w = z ? ((MediaCodec.CodecException) illegalStateException).getErrorCode() : 0;
    }
}
