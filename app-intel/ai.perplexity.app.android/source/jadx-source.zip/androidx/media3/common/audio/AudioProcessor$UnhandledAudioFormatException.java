package androidx.media3.common.audio;

import defpackage.ev1;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class AudioProcessor$UnhandledAudioFormatException extends Exception {
    public AudioProcessor$UnhandledAudioFormatException(String str, ev1 ev1Var) {
        super(str + " " + ev1Var);
    }

    public AudioProcessor$UnhandledAudioFormatException(ev1 ev1Var) {
        this("Unhandled input format:", ev1Var);
    }
}
