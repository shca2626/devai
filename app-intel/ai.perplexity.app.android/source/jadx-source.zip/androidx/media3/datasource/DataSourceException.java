package androidx.media3.datasource;

import java.io.IOException;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class DataSourceException extends IOException {
    public final int w;

    public DataSourceException(int i) {
        this.w = i;
    }

    public DataSourceException(int i, Throwable th) {
        super(th);
        this.w = i;
    }

    public DataSourceException(String str, Exception exc, int i) {
        super(str, exc);
        this.w = i;
    }
}
