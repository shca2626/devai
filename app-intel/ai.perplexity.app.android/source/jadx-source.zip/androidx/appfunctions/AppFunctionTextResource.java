package androidx.appfunctions;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class AppFunctionTextResource {
    public final String a;
    public final String b;

    public AppFunctionTextResource(String str, String str2) {
        this.a = str;
        this.b = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!AppFunctionTextResource.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        obj.getClass();
        AppFunctionTextResource appFunctionTextResource = (AppFunctionTextResource) obj;
        if (this.a.equals(appFunctionTextResource.a)) {
            return this.b.equals(appFunctionTextResource.b);
        }
        return false;
    }

    public final int hashCode() {
        return this.b.hashCode() + (this.a.hashCode() * 31);
    }
}
