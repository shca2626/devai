package androidx.appfunctions;

import android.os.Bundle;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public abstract class AppFunctionException extends Exception {
    public static final /* synthetic */ int x = 0;
    public final String w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppFunctionException(String str, int i, Bundle bundle) {
        super(str);
        bundle.getClass();
        this.w = str;
    }
}
