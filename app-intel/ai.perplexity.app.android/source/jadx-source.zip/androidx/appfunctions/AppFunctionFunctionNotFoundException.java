package androidx.appfunctions;

import android.os.Bundle;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes.dex */
public final class AppFunctionFunctionNotFoundException extends AppFunctionRequestException {
    /* JADX WARN: Illegal instructions before constructor call */
    public AppFunctionFunctionNotFoundException(String str) {
        Bundle bundle = Bundle.EMPTY;
        bundle.getClass();
        super(str, 1003, bundle);
    }
}
