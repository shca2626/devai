package androidx.constraintlayout.core.parser;

import com.singular.sdk.internal.Constants;
import defpackage.rd3;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class CLParsingException extends Exception {
    public final String w;
    public final String x;

    public CLParsingException(String str, rd3 rd3Var) {
        super(str);
        this.w = str;
        if (rd3Var != null) {
            this.x = rd3Var.k();
        } else {
            this.x = Constants.UNKNOWN;
        }
    }

    @Override // java.lang.Throwable
    public final String toString() {
        StringBuilder sb = new StringBuilder("CLParsingException (");
        sb.append(hashCode());
        sb.append(") : ");
        sb.append(this.w + " (" + this.x + " at line 0)");
        return sb.toString();
    }
}
