package androidx.fragment.app.strictmode;

import defpackage.z99;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public abstract class Violation extends RuntimeException {
    public final z99 w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Violation(z99 z99Var, String str) {
        super(str);
        z99Var.getClass();
        this.w = z99Var;
    }
}
