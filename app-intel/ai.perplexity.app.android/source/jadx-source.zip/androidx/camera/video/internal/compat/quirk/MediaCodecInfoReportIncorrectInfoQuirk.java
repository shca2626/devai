package androidx.camera.video.internal.compat.quirk;

import defpackage.b7i;
import java.util.Arrays;
import java.util.List;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class MediaCodecInfoReportIncorrectInfoQuirk implements b7i {
    public static final List a = Arrays.asList("lg-k430", "redmi note 4", "m2003j15sc", "m2004j19c", "rmx3231", "v2117", "sm-a032f", "moto g(20)", "sm-a035m", "v2204", "23078pnd5g", "pht110", "23053rn02l", "rmx3710", "rmx3511", "v2207", "moto e20");
}
