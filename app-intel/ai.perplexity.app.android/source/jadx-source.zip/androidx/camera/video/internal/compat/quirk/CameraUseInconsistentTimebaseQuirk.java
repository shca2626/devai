package androidx.camera.video.internal.compat.quirk;

import defpackage.b7i;
import java.util.Arrays;
import java.util.HashSet;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class CameraUseInconsistentTimebaseQuirk implements b7i {
    public static final HashSet a = new HashSet(Arrays.asList("samsungexynos7570", "samsungexynos7870", "qcom"));
    public static final HashSet b = new HashSet(Arrays.asList("sm4350", "sm6375", "sm7325"));
    public static final HashSet c = new HashSet(Arrays.asList("m2007j20cg", "m2007j20ct"));
}
