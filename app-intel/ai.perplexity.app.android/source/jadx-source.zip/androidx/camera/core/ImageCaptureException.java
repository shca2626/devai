package androidx.camera.core;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class ImageCaptureException extends Exception {
    public final byte w;

    /* JADX WARN: Multi-variable type inference failed */
    public ImageCaptureException(int i, String str, Throwable th) {
        super(str, th);
        this.w = i;
    }
}
