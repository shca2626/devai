package androidx.camera.core.internal.compat.quirk;

import android.util.Pair;
import defpackage.b7i;
import java.util.Collections;
import java.util.HashSet;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class CaptureFailedRetryQuirk implements b7i {
    public static final HashSet a = new HashSet(Collections.singletonList(Pair.create("SAMSUNG", "SM-G981U1")));
}
