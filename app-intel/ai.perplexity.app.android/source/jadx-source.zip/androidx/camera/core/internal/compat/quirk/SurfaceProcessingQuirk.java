package androidx.camera.core.internal.compat.quirk;

import defpackage.b7i;
import defpackage.f7i;
import java.util.Iterator;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public interface SurfaceProcessingQuirk extends b7i {
    static boolean a(f7i f7iVar) {
        Iterator it = f7iVar.c(SurfaceProcessingQuirk.class).iterator();
        while (it.hasNext()) {
            if (((SurfaceProcessingQuirk) it.next()).d()) {
                return true;
            }
        }
        return false;
    }

    default boolean d() {
        return true;
    }
}
