package androidx.appcompat.widget;

import ai.perplexity.app.android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import defpackage.y2m;
import defpackage.y7i;
import defpackage.yb;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public class ActionBarContainer extends FrameLayout {
    public boolean A0;
    public final int B0;
    public boolean w;
    public View x;
    public Drawable x0;
    public View y;
    public Drawable y0;
    public Drawable z;
    public final boolean z0;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        boolean z = false;
        setBackground(new yb(this, (byte) 0));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, y7i.a);
        this.z = typedArrayObtainStyledAttributes.getDrawable(0);
        this.x0 = typedArrayObtainStyledAttributes.getDrawable(2);
        this.B0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.z0 = true;
            this.y0 = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.z0 ? !(this.z != null || this.x0 != null) : this.y0 == null) {
            z = true;
        }
        setWillNotDraw(z);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.z;
        if (drawable != null && drawable.isStateful()) {
            this.z.setState(getDrawableState());
        }
        Drawable drawable2 = this.x0;
        if (drawable2 != null && drawable2.isStateful()) {
            this.x0.setState(getDrawableState());
        }
        Drawable drawable3 = this.y0;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.y0.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.z;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.x0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.y0;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.x = findViewById(R.id.action_bar);
        this.y = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.w || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        boolean z2 = true;
        if (this.z0) {
            Drawable drawable = this.y0;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z2 = false;
            }
        } else {
            if (this.z == null) {
                z2 = false;
            } else if (this.x.getVisibility() == 0) {
                this.z.setBounds(this.x.getLeft(), this.x.getTop(), this.x.getRight(), this.x.getBottom());
            } else {
                View view = this.y;
                if (view == null || view.getVisibility() != 0) {
                    this.z.setBounds(0, 0, 0, 0);
                } else {
                    this.z.setBounds(this.y.getLeft(), this.y.getTop(), this.y.getRight(), this.y.getBottom());
                }
            }
            this.A0 = false;
        }
        if (z2) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        int i3;
        if (this.x == null && View.MeasureSpec.getMode(i2) == Integer.MIN_VALUE && (i3 = this.B0) >= 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(Math.min(i3, View.MeasureSpec.getSize(i2)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i2);
        if (this.x == null) {
            return;
        }
        View.MeasureSpec.getMode(i2);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.z;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.z);
        }
        this.z = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.x;
            if (view != null) {
                this.z.setBounds(view.getLeft(), this.x.getTop(), this.x.getRight(), this.x.getBottom());
            }
        }
        boolean z = false;
        if (!this.z0 ? !(this.z != null || this.x0 != null) : this.y0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.y0;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.y0);
        }
        this.y0 = drawable;
        boolean z = this.z0;
        boolean z2 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z && (drawable2 = this.y0) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z ? !(this.z != null || this.x0 != null) : this.y0 == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.x0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.x0);
        }
        this.x0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.A0 && this.x0 != null) {
                throw null;
            }
        }
        boolean z = false;
        if (!this.z0 ? !(this.z != null || this.x0 != null) : this.y0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setTransitioning(boolean z) {
        this.w = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.z;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.x0;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.y0;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.z;
        boolean z = this.z0;
        if (drawable == drawable2 && !z) {
            return true;
        }
        if (drawable == this.x0 && this.A0) {
            return true;
        }
        return (drawable == this.y0 && z) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public void setTabContainer(y2m y2mVar) {
    }

    public ActionBarContainer(Context context) {
        this(context, null);
    }
}
