package androidx.window.area.reflectionguard;

import android.util.DisplayMetrics;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public interface ExtensionWindowAreaStatusRequirements {
    DisplayMetrics getWindowAreaDisplayMetrics();

    int getWindowAreaStatus();
}
