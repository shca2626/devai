package androidx.window.reflection;

import androidx.window.extensions.core.util.function.Function;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public interface JFunction2<T, U> extends Function<T, U> {
    U apply(T t);
}
