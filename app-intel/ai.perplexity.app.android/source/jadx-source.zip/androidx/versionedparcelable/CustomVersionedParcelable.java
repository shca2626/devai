package androidx.versionedparcelable;

import defpackage.n9r;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public abstract class CustomVersionedParcelable implements n9r {
}
