package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import defpackage.one;
import defpackage.pne;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-d12d633bbe05a97d09a30816bf0e78c12d98373e0b400440ab3f32070139021d */
/* loaded from: classes3.dex */
public final class MultiInstanceInvalidationService extends Service {
    public int w;
    public final LinkedHashMap x = new LinkedHashMap();
    public final pne y = new pne(this);
    public final one z = new one(this);

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        intent.getClass();
        return this.z;
    }
}
