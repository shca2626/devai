package androidx.core.view;

import android.view.View;

/* loaded from: classes7.dex */
public interface n1 {
    void a(View view);

    void b(View view);

    void c(View view);
}
