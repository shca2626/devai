package androidx.core.view;

/* loaded from: classes.dex */
public final /* synthetic */ class v2 {
}
