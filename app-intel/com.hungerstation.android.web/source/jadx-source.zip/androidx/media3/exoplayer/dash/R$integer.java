package androidx.media3.exoplayer.dash;

/* loaded from: classes7.dex */
public final class R$integer {
    public static final int status_bar_notification_info_maxnum = 2131427407;

    private R$integer() {
    }
}
