package androidx.drawerlayout;

/* loaded from: classes7.dex */
public final class R$id {
    public static final int accessibility_action_clickable_span = 2131361834;
    public static final int accessibility_custom_action_0 = 2131361835;
    public static final int accessibility_custom_action_1 = 2131361836;
    public static final int accessibility_custom_action_10 = 2131361837;
    public static final int accessibility_custom_action_11 = 2131361838;
    public static final int accessibility_custom_action_12 = 2131361839;
    public static final int accessibility_custom_action_13 = 2131361840;
    public static final int accessibility_custom_action_14 = 2131361841;
    public static final int accessibility_custom_action_15 = 2131361842;
    public static final int accessibility_custom_action_16 = 2131361843;
    public static final int accessibility_custom_action_17 = 2131361844;
    public static final int accessibility_custom_action_18 = 2131361845;
    public static final int accessibility_custom_action_19 = 2131361846;
    public static final int accessibility_custom_action_2 = 2131361847;
    public static final int accessibility_custom_action_20 = 2131361848;
    public static final int accessibility_custom_action_21 = 2131361849;
    public static final int accessibility_custom_action_22 = 2131361850;
    public static final int accessibility_custom_action_23 = 2131361851;
    public static final int accessibility_custom_action_24 = 2131361852;
    public static final int accessibility_custom_action_25 = 2131361853;
    public static final int accessibility_custom_action_26 = 2131361854;
    public static final int accessibility_custom_action_27 = 2131361855;
    public static final int accessibility_custom_action_28 = 2131361856;
    public static final int accessibility_custom_action_29 = 2131361857;
    public static final int accessibility_custom_action_3 = 2131361858;
    public static final int accessibility_custom_action_30 = 2131361859;
    public static final int accessibility_custom_action_31 = 2131361860;
    public static final int accessibility_custom_action_4 = 2131361861;
    public static final int accessibility_custom_action_5 = 2131361862;
    public static final int accessibility_custom_action_6 = 2131361863;
    public static final int accessibility_custom_action_7 = 2131361864;
    public static final int accessibility_custom_action_8 = 2131361865;
    public static final int accessibility_custom_action_9 = 2131361866;
    public static final int action_container = 2131361898;
    public static final int action_divider = 2131361901;
    public static final int action_image = 2131361910;
    public static final int action_text = 2131361933;
    public static final int actions = 2131361939;
    public static final int async = 2131362041;
    public static final int blocking = 2131362126;
    public static final int chronometer = 2131362441;
    public static final int dialog_button = 2131362818;
    public static final int forever = 2131363145;
    public static final int icon = 2131363405;
    public static final int icon_group = 2131363419;
    public static final int info = 2131363499;
    public static final int italic = 2131363729;
    public static final int line1 = 2131363889;
    public static final int line3 = 2131363890;
    public static final int normal = 2131364241;
    public static final int notification_background = 2131364251;
    public static final int notification_main_column = 2131364252;
    public static final int notification_main_column_container = 2131364253;
    public static final int right_icon = 2131364897;
    public static final int right_side = 2131364898;
    public static final int tag_accessibility_actions = 2131365348;
    public static final int tag_accessibility_clickable_spans = 2131365349;
    public static final int tag_accessibility_heading = 2131365350;
    public static final int tag_accessibility_pane_title = 2131365351;
    public static final int tag_screen_reader_focusable = 2131365356;
    public static final int tag_transition_group = 2131365359;
    public static final int tag_unhandled_key_event_manager = 2131365360;
    public static final int tag_unhandled_key_listeners = 2131365361;
    public static final int text = 2131365381;
    public static final int text2 = 2131365382;
    public static final int time = 2131365500;
    public static final int title = 2131365521;

    private R$id() {
    }
}
