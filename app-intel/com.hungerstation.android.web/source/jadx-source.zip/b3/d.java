package b3;

/* loaded from: classes.dex */
public interface d {
    void a(d dVar);
}
